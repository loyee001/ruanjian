# 等你来 · 3D 打印模型

尺寸单位均为毫米。这里包含已导出的 STL、模型 3MF、Bambu Studio 工程、生成源码和网格检查记录；没有打印用 G-code。

## 先选版本

| 要打印什么 | 打开文件 | 说明 |
| --- | --- | --- |
| **最新加宽外壳 V3 + 匹配后盖** | [V3 通用两件模型](help-button-enclosure-v3-wide-20261031/help-button-enclosure-v3-wide-two-parts.3mf) | 左右各加宽 5 mm，后检修口 80×56 mm；使用同目录的 V3 后盖，不能混用 V2 后盖。 |
| ESP32 托座 + 2 螺丝 + 2 压片 | [托座第 1 盘](help-button-component-holders-20261031/plate-1-esp32.3mf) | 按 52×28 mm 板设计；凹槽 52.6×28.6 mm。 |
| 原尺寸按钮托座 + 2 螺丝 + 2 压片 | [托座第 2 盘](help-button-component-holders-20261031/plate-2-button.3mf) | 按 30×20 mm 板设计；凹槽 30.6×20.6 mm。 |
| **最新加大小底托 + 可调承托柱** | [13 件同盘通用模型](button-support-pillar-rescue-20261031/button-holder-roomier-v2/立柱加大按钮小底托-13件-同一盘.3mf) | 凹槽加至 31.6×21.6 mm；12 件可调支承组件 + 1 件底托。无额外独立螺丝/压片。 |
| 同上，P2S 0.4 mm 工程 | [13 件 Bambu 工程](button-support-pillar-rescue-20261031/button-holder-roomier-v2/立柱加大按钮小底托-13件-Bambu工程.3mf) | 带 P2S 0.4 mm 配置；换机时重新选设备、耗材并切片。 |
| 黑色眼珠两只 | [眼珠模型](help-button-print-reference-20261030/printable-prototype-v1/black-pupils-20261031/黑色眼珠-两只.3mf) | 每只 9.4×13×2.8 mm；平面贴板，小凸台朝上。V3 眼窝形状未变，位置随壳体向外移。 |
| 黑色笑嘴 | [笑嘴模型](help-button-mouth-20261031/黑色笑嘴.3mf) | 约 14.716×4.354×1.55 mm；宽平面贴板，窄定位脊朝上。 |
| 绿色顶部按钮帽 | [按钮帽 STL](help-button-print-reference-20261030/printable-prototype-v1/top-button.stl) | 原接口继续使用；约 43×43×22 mm，帽面贴板、杆朝上。 |
| 此前的 V2 壳/后盖，版本参考 | [V2 两件通用模型](help-button-enclosure-v2-20261031/help-button-enclosure-v2-two-parts.3mf) | 仅在继续使用 V2 主体时选择；不是最新 V3。 |

此前约 33 MB 的 V2 四盘合并工程未上传，避免超过 GitHub 网页单文件限制；其各盘通用模型和复建源码仍完整保留。该工程的错误合并版本、临时保存和重复修正版均未收录。

有两件较大的 STL 使用无损 `.stl.gz` 压缩，以满足网页上传大小限制。正常使用直接打开上表的 3MF；需要这两件 STL 时，在本目录运行 `python3 extract_stl.py` 即可还原，无需安装依赖。原始 STL 哈希见来源核对清单。

## 版本与装配

- **V3 外壳**：名义主壳宽 98 mm；实际含手脚外包围约 119.992×71.999×77 mm。后盖 90×64 mm，四孔间距 78×54 mm，孔径名义 3.4 mm，止口名义单边间隙 0.4 mm。顶部 22 mm 导向孔、绿色帽接口和 20×12 mm 插线缺口保持原结构。
- **V2 外壳参考**：后口 70×56 mm，后盖 80×64 mm，孔距 68×54 mm。目录中保留通用 3MF 与源代码，不重复收录大体积的 V2 STL。需要时可从该 3MF 导出或运行源码。
- **承托柱**：底座 + 顶板最低 10 mm；配主柱及加高节提供 5 mm 一档的 10–60 mm 支承高度，另有 1/2/2 mm 垫片。方榫 8×8 mm、盲槽 8.5×8.5 mm；为定位插接，没有锁扣。不要把用户提到的按钮间隙直接当作柱高。
- **托座螺丝**：自定义名义直径 6 mm、螺距 1.5 mm，杆长 7 mm；不是标准 M6，也不是穿过 PCB 3 mm 孔的 M3 螺丝。压片用于压板边，实物必须避开元件和焊点。
- **眼珠/笑嘴**：少量适合 PLA 的胶固定，不是卡扣。先轻放核对，不能硬压。
- 当前外壳没有扬声器孔或音箱安装座；现有功能由手机提醒，不应据此清单认为已经有桌面扬声器。

所有通用 3MF/STL 都需要按实际打印机、喷嘴和材料重新切片。除明确标出的 P2S 工程外，不预设打印机。黑眼珠文件经过 Bambu 保存，含其保存时的设置，换机仍需重选配置。主壳顶棚/导向结构需要检查支撑；V3 通用工程没有预设支撑，不能直接沿用无支撑打印的假设。

## 检查范围

已保存的 `validation*.json` 检查了相应网格的闭合、绕序、连通、正体积及部分孔道/间隙/排盘。检查记录中的历史本机路径只是生成来源。数字网格检查不等于实物装配成功：PCB 厚度、板下焊点、接头包络、按钮触发高度与回弹、打印收缩、螺纹插合和支承稳定性仍需用真实零件确认。V3 与加大按钮底托的记录明确标注尚未实装、未发送打印。

## 从源码复建

使用 Python 3.12，安装 [requirements-models.txt](requirements-models.txt)。原生成/预览代码使用 macOS 中文字体；macOS 可直接使用，其他系统需在预览脚本中换成本机字体，几何参数不因此改变。

```bash
python3 -m pip install -r requirements-models.txt
python3 rebuild_models.py --list
python3 rebuild_models.py --run
```

`--run` 会在**当前 models 目录**重建文件，请先复制一份。完整复建会先生成未随仓库重复上传的 V1 参考壳/后盖，供旧源码的哈希保护和装配预览使用，再生成现有派生模型。它可能使用较多内存并持续数分钟；不会连接打印机或发送打印。

`build_four_plates.py` 复建的是 V2 四盘几何，随后 `finalize_four_plate_support.py` 恢复主壳专属的自动树状支撑，允许内部支撑；结果不属于最新 V3 全套工程。Bambu 保存产生的原生 13 件工程和眼珠工程还包含 Bambu 生成元数据；源代码重建的通用几何可与其比较，不保证 ZIP 的字节级哈希相同。

[manifest.json](manifest.json) 记录本目录每个交付文件的相对路径、字节数和 SHA-256（清单自身除外）。[source-copy-verification.json](source-copy-verification.json) 记录原始文件与本次副本的核对结果。项目未加入软件、手机数据、打印机账号凭据或 G-code。
