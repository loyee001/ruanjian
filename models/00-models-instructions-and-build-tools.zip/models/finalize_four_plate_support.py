#!/usr/bin/env python3
"""Apply body-only supports to the rebuilt V2 four-plate Bambu project."""
from pathlib import Path
import zipfile
import xml.etree.ElementTree as ET

KIT = Path(__file__).resolve().parent / 'help-button-model-kit-20261031'
SOURCE = KIT / '等你来-四盘完整模型-修正版.3mf'
TARGET = KIT / '等你来-四盘打印工程.3mf'
SUPPORT = {
    'enable_support': '1', 'support_type': 'tree(auto)', 'support_style': 'default',
    'support_on_build_plate_only': '0', 'support_threshold_angle': '30',
    'support_top_z_distance': '0.2', 'support_bottom_z_distance': '0.2',
    'support_interface_top_layers': '2', 'support_object_xy_distance': '0.35',
}


def main():
    with zipfile.ZipFile(SOURCE) as archive:
        entries = {name: archive.read(name) for name in archive.namelist()}
    config = ET.fromstring(entries['Metadata/model_settings.config'])
    body = config.find("object[@id='22']")
    assert body is not None
    assert any(node.attrib.get('value') == 'body-v2' for node in body.findall('metadata'))
    for key, value in SUPPORT.items():
        previous = body.find(f"metadata[@key='{key}']")
        if previous is None:
            ET.SubElement(body, 'metadata', {'key': key, 'value': value})
        else:
            previous.set('value', value)
    entries['Metadata/model_settings.config'] = ET.tostring(config, encoding='utf-8', xml_declaration=True)
    with zipfile.ZipFile(TARGET, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, data in entries.items():
            archive.writestr(name, data)
    print(TARGET)


if __name__ == '__main__':
    main()
