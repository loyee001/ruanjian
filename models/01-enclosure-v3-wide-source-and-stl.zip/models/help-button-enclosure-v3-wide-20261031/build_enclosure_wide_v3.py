#!/usr/bin/env python3
"""Local X widening by 10 mm; preserved head and cable interface; no printer mutation."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import struct
import subprocess
import sys
import time
import zipfile
import numpy as np

HERE = Path(__file__).resolve().parent
V2 = HERE.parent / 'help-button-enclosure-v2-20261031'
V1 = HERE.parent / 'help-button-print-reference-20261030/printable-prototype-v1'
spec = importlib.util.spec_from_file_location('geometry', HERE / 'geometry_v1_snapshot.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)

PARAMS = {
    'units': 'mm', 'mesh_grid_mm': g.STEP,
    'body_nominal_xyz_mm': [98,62,76], 'body_nominal_x_widening_mm': 10,
    'each_side_x_extension_mm': 5, 'shell_nominal_wall_mm': 3,
    'cap_stem_diameter_mm_unchanged': 21.2,
    'eye_recess_centres_x_mm': [-21,21], 'arm_centres_x_mm': [-48,48],
    'foot_centres_x_mm': [-28,28],
    'rear_access_mm': [80, 56], 'rear_access_corner_radius_mm': 12,
    'rear_access_center_xz_mm': [0, 35], 'rear_access_y_interval_mm': [22, 40],
    'rear_mounting_land_mm': [90, 64],
    'screw_hole_centres_xz_mm': [[x, z] for x in [-39, 39] for z in [8, 62]],
    'screw_hole_diameter_mm': 3.4, 'body_bore_y_interval_mm': [14, 40],
    'cover_outer_xy_mm': [90, 64], 'cover_base_thickness_mm': 2.4,
    'cover_lip_outer_xy_mm': [79.2, 55.2], 'cover_lip_outer_radius_mm': 11.6,
    'cover_lip_inner_xy_mm': [74, 50], 'cover_lip_inner_radius_mm': 9,
    'cover_lip_top_z_mm': 5.4, 'nominal_lip_wall_mm': 2.6,
    'nominal_lip_clearance_per_side_mm': 0.4,
    'cable_notch_width_depth_mm': [20, 12],
    'body_cable_cut_xyz_mm': [[-10, 10], [12, 41], [3, 15]],
    'cover_cable_cut_xy_mm': [[-10, 10], [-32, -20]],
    'body_bottom_uncut_z_mm': [0, 3],
    'top_guide_bore_mm_unchanged': 22,
    'hardware_mounting_height_verified': False,
    'physical_fit_verified': False,
}

def body_v3(x, y, z):
    outer = g.rbox(x, y, z, (0, 0, 38), (49, 31, 38), 18)
    for sx in (-1, 1):
        outer = np.minimum(outer, g.ell(x, y, z, (sx*21, -28, 57), (13, 9, 13)))
        outer = np.minimum(outer, g.ell(x, y, z, (sx*48, -10, 30), (12, 10, 13)))
        outer = np.minimum(outer, g.ell(x, y, z, (sx*28, -25, 5), (15, 14, 8)))
    outer = np.minimum(outer, g.slabshape(x, z-35, y, 45, 32, 9, 25, 33))
    outer = np.maximum(outer, -z)
    cavity = g.rbox(x, y, z, (0, 0, 38), (46, 28, 35), 15)
    shell = np.maximum(outer, -cavity)
    # V1 head/hat interface is intentionally byte-for-byte equivalent in formula.
    shell = np.minimum(shell, g.cyl(x, y, z, 15, 65, 77))
    shell = np.minimum(shell, g.cyl(x, y, z, 24, 73, 77))
    port = g.cyl(x, y, z, 11, 61, 81)
    for sx in (-1, 1):
        port = np.minimum(port, g.box(x, y, z, (sx*11.7, 0, 71), (1.2, 2.6, 11)))
    shell = np.maximum(shell, -port)
    # Enlarged access; R12 preserves material around the four existing screws.
    access = g.slabshape(x, z-35, y, 40, 28, 12, 22, 40)
    shell = np.maximum(shell, -access)
    for sx in (-1, 1):
        for sz in (-1, 1):
            bore = np.maximum(np.sqrt((x-sx*39)**2 + (z-(35+sz*27))**2)-1.7,
                              np.maximum(14-y, y-40))
            shell = np.maximum(shell, -bore)
    # Cable opening connects to the cavity while leaving z=0..3 bottom intact.
    cable = g.box(x, y, z, (0, 26.5, 9), (10, 14.5, 6))
    shell = np.maximum(shell, -cable)
    # Eye positions move out by 5 mm; recess shapes and the smile remain unchanged.
    for sx in (-1, 1):
        pupil = g.ell(x, y, z, (sx*21, -36.2, 58), (5.0, 1.4, 6.8))
        shell = np.maximum(shell, -pupil)
    smile = np.full(np.broadcast_shapes(x.shape, y.shape, z.shape), 1e6)
    for a in np.linspace(np.pi*1.12, np.pi*1.88, 19):
        cx, cz = 7*np.cos(a), 42+4.2*np.sin(a)
        smile = np.minimum(smile, g.ell(x, y, z, (cx, -30.7, cz), (1., 1.2, 1.)))
    return np.maximum(shell, -smile)

def cover_v3(x, y, z):
    plate = g.slabshape(x, y, z, 45, 32, 9, 0, 2.4)
    lip = np.maximum(g.slabshape(x, y, z, 39.6, 27.6, 11.6, 2.2, 5.4),
                     -g.slabshape(x, y, z, 37, 25, 9, 2., 6.))
    field = np.minimum(plate, lip)
    for sx in (-1, 1):
        for sy in (-1, 1):
            field = np.maximum(field, -g.cyl(x-sx*39, y-sy*27, z, 1.7, -1, 7))
    # Edge notch extends exactly from local y=-32 to -20, through all thicknesses.
    return np.maximum(field, -g.box(x, y, z, (0, -26, 3), (10, 6, 5)))

def original_hashes():
    names = ['build_prototype.py', 'body.stl', 'rear-cover.stl', 'top-button.stl',
             'black-pupils-20261031/pupil-left.stl', 'black-pupils-20261031/pupil-right.stl']
    return {name: hashlib.sha256((V1/name).read_bytes()).hexdigest() for name in names}

def source_checks():
    # Compare the actual function source with only the authorised local edits.
    import inspect
    oldspec = importlib.util.spec_from_file_location('enclosure_v2_reference', V2/'build_enclosure_v2.py')
    old = importlib.util.module_from_spec(oldspec)
    oldspec.loader.exec_module(old)
    expected = inspect.getsource(old.body_v2) + '\n' + inspect.getsource(old.cover_v2)
    expected = expected.replace('body_v2','body_v3').replace('cover_v2','cover_v3')
    changes = [
        ('(44, 31, 38)','(49, 31, 38)',1),('sx*16','sx*21',2),
        ('sx*43','sx*48',1),('sx*23','sx*28',1),
        ('40, 32, 9, 25, 33','45, 32, 9, 25, 33',1),
        ('(41, 28, 35)','(46, 28, 35)',1),
        ('35, 28, 12, 22, 40','40, 28, 12, 22, 40',1),
        ('sx*34','sx*39',2),('40, 32, 9, 0, 2.4','45, 32, 9, 0, 2.4',1),
        ('34.6, 27.6, 11.6','39.6, 27.6, 11.6',1),
        ('32, 25, 9, 2., 6.','37, 25, 9, 2., 6.',1)]
    for before,after,count in changes:
        assert expected.count(before)==count
        expected=expected.replace(before,after)
    expected=expected.replace('# V1 eyes and smile unchanged; existing glue-in black pupils remain applicable.',
        '# Eye positions move out by 5 mm; recess shapes and the smile remain unchanged.')
    actual=inspect.getsource(body_v3)+'\n'+inspect.getsource(cover_v3)
    assert actual==expected, 'Unexpected geometry source modification'
    theta=np.arange(720)*2*np.pi/720
    ys=np.linspace(13.5,40.5,109)
    holes=[]
    for cx in (-39.,39.):
        for cz in (8.,62.):
            by_radius={}
            for radius in (0.,1.5,1.7):
                xs=cx+radius*np.cos(theta)[:,None]
                zs=cz+radius*np.sin(theta)[:,None]
                xx,yy,zz=np.broadcast_arrays(xs,ys[None,:],zs)
                values=body_v3(xx,yy,zz)
                assert values.min()>=-1e-8
                by_radius[str(radius)]={'minimum_body_field_mm':float(values.min()),
                    'all_samples_outside_solid_or_on_boundary':True}
            cavity=g.rbox(cx+1.7*np.cos(theta),np.full(720,14.),cz+1.7*np.sin(theta),
                          (0,0,38),(46,28,35),15)
            assert cavity.max()<0
            cover_values=cover_v3(cx+1.7*np.cos(theta)[:,None],
                cz-35+1.7*np.sin(theta)[:,None],np.linspace(-.5,6,27)[None,:])
            assert cover_values.min()>=-1e-8
            holes.append({'centre_body_xz_mm':[cx,cz],'centre_cover_xy_mm':[cx,cz-35],
                'radii':by_radius,'angles_per_circle':720,'y_samples':len(ys),
                'body_bore_full_circle_enters_cavity_at_y14':True,
                'cover_hole_full_circle_clear':True,'max_cavity_field_at_y14_mm':float(cavity.max()),
                'nominal_opening_to_hole_edge_material_mm':float(g.roundrect(np.array(cx),np.array(cz-35),40,28,12)-1.7)})
    # The complete guide and its two lug-entry slots remain identical, no X scale.
    x,y,z=np.meshgrid(np.linspace(-15,15,61),np.linspace(-15,15,61),
                       np.linspace(61,81,41),indexing='ij')
    delta=float(np.max(np.abs(body_v3(x,y,z)-old.body_v2(x,y,z))))
    assert delta<1e-10, delta
    # Exact offset CSG construction retains the nominal three-millimetre wall.
    rng=np.random.default_rng(20261031)
    points=rng.uniform([-60,-40,-2],[60,40,79],size=(10000,3))
    outer=g.rbox(*points.T,(0,0,38),(49,31,38),18)
    inner=g.rbox(*points.T,(0,0,38),(46,28,35),15)
    wall_delta=float(np.max(np.abs((inner-outer)-3)))
    assert wall_delta<1e-10
    # Offset rounded rectangles give 0.4 mm everywhere along the insertion lip.
    lip=[]
    for sx in (-1,1):
        for sy in (-1,1):
            a=np.linspace(0,np.pi/2,181)
            lip.extend(np.column_stack((sx*(28+11.6*np.cos(a)),sy*(16+11.6*np.sin(a)))))
    lip=np.asarray(lip)
    clearances=-g.roundrect(lip[:,0],lip[:,1],40,28,12)
    assert np.max(np.abs(clearances-.4))<1e-10
    # Body and cover keep the original cutters, with the same assembly height.
    x,y,z=np.meshgrid(np.linspace(-9.9,9.9,21),np.linspace(12.1,40.9,31),
                       np.linspace(3.1,14.9,19),indexing='ij')
    assert body_v3(x,y,z).min()>0
    x,y,z=np.meshgrid(np.linspace(-9.9,9.9,21),np.linspace(-31.9,-20.1,25),
                       np.linspace(.01,5.39,19),indexing='ij')
    assert cover_v3(x,y,z).min()>0
    assert body_v3(x,35.4-z,35+y).min()>0
    x,y,z=np.meshgrid(np.linspace(-9.9,9.9,21),np.linspace(12,40,31),
                       np.linspace(.2,2.9,10),indexing='ij')
    assert np.array_equal(body_v3(x,y,z)<0,old.body_v2(x,y,z)<0)
    # Dense center-line through both mouths reaches the open cavity, not a recess.
    center_line=body_v3(np.zeros(301),np.linspace(0,40,301),np.full(301,9.))
    assert center_line.min()>0
    return {'only_authorised_source_geometry_edits':True,
        'authorised_replacements':[{'before':a,'after':b,'count':c} for a,b,c in changes],
        'bore_passages':holes,
        'head_interface_unchanged':{'max_absolute_field_delta_mm':delta,'samples':61*61*41,
            'guide_bore_diameter_mm':22,'cap_stem_diameter_mm':21.2},
        'nominal_wall_offset_mm':3,'wall_sample_max_error_mm':wall_delta,
        'lip_clearance_per_side_mm':[float(clearances.min()),float(clearances.max())],
        'body_and_cover_cable_cutters_unchanged':True,'cable_notch_interior_all_air':True,
        'cable_connected_to_cavity':True,'bottom_z_below_3_classification_unchanged':True,
        'eye_recess_shape_and_existing_black_pupil_dimensions_unchanged':True,
        'limit':'Analytic source-field sampling; physical fit and process tolerances are not verified.'}

def stl_v3(path, vertices, faces):
    g.stl(path, vertices, faces)
    with path.open('r+b') as output:
        output.write(b'Help button enclosure V3 wide; mm; physical fit not verified'.ljust(80,b' '))

def write_three_mf(parts):
    lines = ['<?xml version="1.0" encoding="UTF-8"?>',
        '<model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02">',
        '<metadata name="Title">Help button enclosure V3 wide: body and rear cover</metadata><resources>',
        '<basematerials id="100"><base name="Cream PLA reference" displaycolor="#FFF1CF"/></basematerials>']
    placements = [(70,85),(190,170)]
    bounds = []
    for index, ((name,v,f),(px,py)) in enumerate(zip(parts,placements),1):
        lines.append(f'<object id="{index}" name="{name}" type="model" pid="100" pindex="0"><mesh><vertices>')
        lines.extend('<vertex x="%.5f" y="%.5f" z="%.5f"/>'%tuple(p) for p in v)
        lines.append('</vertices><triangles>')
        lines.extend('<triangle v1="%d" v2="%d" v3="%d"/>'%tuple(p) for p in f)
        lines.append('</triangles></mesh></object>')
        bounds.append((np.min(v,axis=0)+[px,py,0],np.max(v,axis=0)+[px,py,0]))
    lines.append('</resources><build>')
    for index,(px,py) in enumerate(placements,1):
        lines.append(f'<item objectid="{index}" transform="1 0 0 0 1 0 0 0 1 {px} {py} 0"/>')
    lines.append('</build></model>')
    path = HERE/'help-button-enclosure-v3-wide-two-parts.3mf'
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('[Content_Types].xml','<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
        archive.writestr('_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
        archive.writestr('3D/3dmodel.model',''.join(lines))
    a,b = bounds
    separation = np.maximum(np.maximum(a[0][:2]-b[1][:2],b[0][:2]-a[1][:2]),0)
    assert np.linalg.norm(separation) > 20
    assert all(np.all(lo>=0) and np.all(hi[:2]<256) for lo,hi in bounds)
    return {'path':path.name,'object_count':2,'reference_colour':'cream',
        'placed_bounds_mm':[[lo.tolist(),hi.tolist()] for lo,hi in bounds],
        'conservative_xy_bbox_clearance_mm':float(np.linalg.norm(separation)),
        'contains_machine_preset':False,'contains_sliced_gcode':False}

def clip_y(poly, bound, keep_above):
    output = []
    for a,b in zip(poly,poly[1:]+poly[:1]):
        inside_a = a[1]>=bound if keep_above else a[1]<=bound
        inside_b = b[1]>=bound if keep_above else b[1]<=bound
        if inside_a: output.append(a)
        if inside_a != inside_b:
            output.append(a+(b-a)*((bound-a[1])/(b[1]-a[1])))
    return output

def projected_min_radius(poly, centre):
    points = np.array(poly)[:,[0,2]]-centre
    segments = np.roll(points,-1,axis=0)-points
    cross = points[:,0]*np.roll(points,-1,axis=0)[:,1]-points[:,1]*np.roll(points,-1,axis=0)[:,0]
    if np.abs(cross.sum())>1e-10 and (np.all(cross>=-1e-10) or np.all(cross<=1e-10)):
        return 0.
    fractions = np.clip(-np.sum(points*segments,axis=1)/np.maximum(np.sum(segments*segments,axis=1),1e-20),0,1)
    return float(np.linalg.norm(points+fractions[:,None]*segments,axis=1).min())

def actual_mesh_hole_checks(vertices, faces):
    triangles = vertices[faces]
    low,high = triangles.min(axis=1),triangles.max(axis=1)
    checks=[]
    for cx,cz in PARAMS['screw_hole_centres_xz_mm']:
        selected = (low[:,1]<=40)&(high[:,1]>=14)&(low[:,0]<=cx+2)&(high[:,0]>=cx-2)&(low[:,2]<=cz+2)&(high[:,2]>=cz-2)
        minimum=float('inf'); count=0
        for triangle in triangles[selected]:
            poly=clip_y(list(triangle),14,True)
            if len(poly)<3: continue
            poly=clip_y(poly,40,False)
            if len(poly)<3: continue
            minimum=min(minimum,projected_min_radius(poly,np.array([cx,cz])))
            count+=1
        assert np.isfinite(minimum) and minimum>1.5, (cx,cz,minimum)
        checks.append({'centre_xz_mm':[cx,cz], 'surface_triangles_examined':count,
                       'min_surface_radius_within_y14_to40_mm':minimum,
                       'virtual_3mm_diameter_cylinder_clear':True,
                       'radial_clearance_to_virtual_m3_mm':minimum-1.5})
    return checks

def main():
    before=original_hashes()
    v2_before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in V2.iterdir() if p.is_file()}
    report={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'parameters':PARAMS,'source_checks':source_checks(),'parts':{},
            'sliced':False,'printer_command_sent':False,
            'electronics_fit_or_button_return_verified':False}
    print('Source-field checks passed',flush=True)
    parts=[]
    for name,field,bounds in [('body-wide-v3',body_v3,[(-64,64),(-41,35),(-2,79)]),
                              ('rear-cover-wide-v3',cover_v3,[(-47,47),(-34,34),(-2,8)])]:
        started=time.time()
        v,f=g.mesh(field,bounds)
        stats=g.validate(v,f)
        assert stats['boundary_edges']==stats['nonmanifold_edges']==0
        assert stats['surface_components']==1 and stats['signed_volume_mm3']>0
        stl_v3(HERE/(name+'.stl'),v,f)
        stats['sha256']=hashlib.sha256((HERE/(name+'.stl')).read_bytes()).hexdigest()
        report['parts'][name]=stats
        if name=='body-wide-v3': report['actual_mesh_hole_checks']=actual_mesh_hole_checks(v,f)
        parts.append((name,v,f))
        print(name,json.dumps(stats),f'{time.time()-started:.1f}s',flush=True)
    report['three_mf']=write_three_mf(parts)
    result=subprocess.run([sys.executable,str(HERE/'validate_meshes.py'),str(HERE/'body-wide-v3.stl'),str(HERE/'rear-cover-wide-v3.stl')],capture_output=True,text=True)
    (HERE/'validation-independent.json').write_text(result.stdout)
    assert result.returncode==0, result.stderr or result.stdout
    report['independent_stl_validation']=json.loads(result.stdout)
    after=original_hashes()
    assert before==after
    v2_after={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in V2.iterdir() if p.is_file()}
    assert v2_before==v2_after
    report['original_v2_files_sha256_unchanged']=v2_after
    report['original_v1_part_sha256_unchanged']=after
    report['notes']=['Two generic 3MF objects, no machine settings or G-code.',
        'Topology and sampled geometric checks do not prove physical fit, bolt fit, structural strength, self-intersection freedom or printability.',
        'Head guide and cap retained; eye centres move out by 5 mm with unchanged pupil recess shapes; no speaker feature added.']
    (HERE/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('Independent STL validation and unchanged V1/V2 hashes passed',flush=True)

if __name__=='__main__': main()
