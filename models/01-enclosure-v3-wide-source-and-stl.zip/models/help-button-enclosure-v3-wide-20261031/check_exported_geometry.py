#!/usr/bin/env python3
"""Re-read exported STL/3MF; check selected real mesh channels and plate layout."""
from pathlib import Path
import importlib.util, json, zipfile
import xml.etree.ElementTree as ET
import numpy as np
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('wide_generator',HERE/'build_enclosure_wide_v3.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
DT=np.dtype([('normal','<f4',3),('vertices','<f4',(3,3)),('attribute','<u2')])
def triangles(name):
    return np.frombuffer((HERE/name).read_bytes(),dtype=DT,offset=84)['vertices'].astype(float)
def line_intersections(t,axis,fixed):
    axes=[i for i in range(3) if i!=axis]
    e1=t[:,1]-t[:,0];e2=t[:,2]-t[:,0]
    a,b=axes
    det=e1[:,a]*e2[:,b]-e1[:,b]*e2[:,a]
    candidate=np.abs(det)>1e-12
    q=np.asarray(fixed)-t[candidate,0][:,axes]
    d=det[candidate];v1=e1[candidate];v2=e2[candidate]
    u=(q[:,0]*v2[:,b]-q[:,1]*v2[:,a])/d
    v=(v1[:,a]*q[:,1]-v1[:,b]*q[:,0])/d
    selected=(u>=-1e-9)&(v>=-1e-9)&(u+v<=1+1e-9)
    hits=t[candidate,0,axis]+u*v1[:,axis]+v*v2[:,axis]
    return np.unique(np.round(hits[selected],5))
def blocked_box(t,lo,hi):
    # AABB rejection followed by the full triangle/box separating-axis test.
    # Sharp mesh corners can overlap a box's bounding ranges without entering it.
    candidates=t[np.all(t.max(axis=1)>lo,axis=1)&np.all(t.min(axis=1)<hi,axis=1)]
    centre=(lo+hi)/2;half=(hi-lo)/2;basis=np.eye(3);blocked=0
    for triangle in candidates-centre:
        edges=np.roll(triangle,-1,axis=0)-triangle
        axes=[*basis,np.cross(edges[0],edges[1]),
              *(np.cross(edge,axis) for edge in edges for axis in basis)]
        separated=False
        for axis in axes:
            if np.dot(axis,axis)<1e-20:continue
            projection=triangle@axis;radius=half@np.abs(axis)
            if projection.min()>radius+1e-9 or projection.max()<-radius-1e-9:
                separated=True;break
        if not separated:blocked+=1
    return len(candidates),blocked
def channel_radius(t,axis,centre,interval,near_radius):
    # Permute axial direction to local Y, so the existing independent polygon
    # clip/project routine examines the complete triangle surface in the slab.
    cross_axes=[i for i in range(3) if i!=axis]
    p=t[:,:,[cross_axes[0],axis,cross_axes[1]]]
    lo,hi=p.min(axis=1),p.max(axis=1)
    c=np.asarray(centre)
    selected=(lo[:,1]<=interval[1])&(hi[:,1]>=interval[0])&(lo[:,0]<=c[0]+near_radius)&(hi[:,0]>=c[0]-near_radius)&(lo[:,2]<=c[1]+near_radius)&(hi[:,2]>=c[1]-near_radius)
    radius=float('inf');count=0
    for triangle in p[selected]:
        poly=g.clip_y(list(triangle),interval[0],True)
        if len(poly)<3:continue
        poly=g.clip_y(poly,interval[1],False)
        if len(poly)<3:continue
        radius=min(radius,g.projected_min_radius(poly,c));count+=1
    assert np.isfinite(radius)
    return {'minimum_surface_radius_mm':float(radius),'clipped_surface_triangles_examined':count}
def main():
    body=triangles('body-wide-v3.stl');cover=triangles('rear-cover-wide-v3.stl')
    report={'passed':True,'units':'mm','checks':{}}
    top=channel_radius(body,2,[0,0],[65,77],13.5)
    assert top['minimum_surface_radius_mm']>10.6
    top['virtual_21_2mm_stem_clear']=True
    top['line_measured_bore_diameters_mm']=[]
    for z in [66.,70.,74.,76.]:
        hits=line_intersections(body,1,[0,z]);diameter=float(np.min(hits[hits>0])-np.max(hits[hits<0]))
        assert 21.8<diameter<22.05
        top['line_measured_bore_diameters_mm'].append({'z_mm':z,'diameter_mm':diameter})
    report['checks']['top_guide']=top
    cover_holes=[]
    for x in [-39.,39.]:
        for y in [-27.,27.]:
            check=channel_radius(cover,2,[x,y],[-1,7],2)
            assert check['minimum_surface_radius_mm']>1.5
            cover_holes.append({'centre_xy_mm':[x,y],**check,'virtual_3mm_diameter_clear':True})
    report['checks']['rear_cover_screw_holes']=cover_holes
    body_hits=line_intersections(body,0,[31.,35.]);lip_hits=line_intersections(cover,0,[0.,4.])
    assert len(body_hits)==4 and len(lip_hits)==4,(body_hits,lip_hits)
    gaps=[float(lip_hits[0]-body_hits[1]),float(body_hits[2]-lip_hits[-1])]
    assert np.max(np.abs(np.array(gaps)-.4))<.002
    report['checks']['actual_mid_side_lip_clearances_mm']={
        'body_x_line_intersections_mm':body_hits.tolist(),'cover_lip_x_line_intersections_mm':lip_hits.tolist(),
        'left_right_clearance_mm':gaps,'corner_clearance_verified_by_analytic_offset':True}
    cable=[('body_cable_interior',body,[-9.5,12.5,3.5],[9.5,40.5,14.5]),
           ('cover_cable_interior',cover,[-9.5,-31.5,.1],[9.5,-20.5,5.3]),
           ('body_centre_path_to_cavity',body,[-.25,0,8.75],[.25,40,9.25])]
    report['checks']['cable_passage']={}
    for name,t,lo,hi in cable:
        candidate_count,count=blocked_box(t,np.array(lo),np.array(hi));assert count==0,(name,count)
        report['checks']['cable_passage'][name]={'virtual_clear_box_mm':[lo,hi],
            'triangle_bbox_candidates':candidate_count,'triangles_intersecting_clear_box':count,'clear':True}
    # Re-read the generic package, compare every serialized triangle to each STL.
    archive_path=HERE/'help-button-enclosure-v3-wide-two-parts.3mf'
    ns={'m':'http://schemas.microsoft.com/3dmanufacturing/core/2015/02'}
    with zipfile.ZipFile(archive_path) as archive:
        entries=archive.namelist()
        assert sorted(entries)==sorted(['[Content_Types].xml','_rels/.rels','3D/3dmodel.model'])
        root=ET.fromstring(archive.read('3D/3dmodel.model'))
    objects=root.findall('m:resources/m:object',ns)
    items=root.findall('m:build/m:item',ns)
    assert len(objects)==len(items)==2
    by_id={};object_reports=[]
    for obj,stl in zip(objects,[body,cover]):
        vertices=np.array([[float(v.attrib[a]) for a in ['x','y','z']] for v in obj.findall('m:mesh/m:vertices/m:vertex',ns)])
        faces=np.array([[int(f.attrib[a]) for a in ['v1','v2','v3']] for f in obj.findall('m:mesh/m:triangles/m:triangle',ns)])
        assert np.isfinite(vertices).all() and faces.min()>=0 and faces.max()<len(vertices)
        assert np.array_equal(vertices.astype(np.float32)[faces],stl.astype(np.float32))
        by_id[obj.attrib['id']]=(vertices.min(axis=0),vertices.max(axis=0))
        object_reports.append({'id':obj.attrib['id'],'name':obj.attrib.get('name'),
            'vertices':len(vertices),'triangles':len(faces),'every_triangle_matches_corresponding_stl':True})
    placed=[]
    for item in items:
        values=np.array([float(x) for x in item.attrib['transform'].split()])
        assert np.array_equal(values[:9],[1,0,0,0,1,0,0,0,1])
        lo,hi=by_id[item.attrib['objectid']];lo=lo+values[9:];hi=hi+values[9:]
        assert np.all(lo>=0) and np.all(hi[:2]<256) and lo[2]==0
        placed.append([lo.tolist(),hi.tolist()])
    a,b=np.array(placed[0]),np.array(placed[1])
    separation=np.maximum(np.maximum(a[0,:2]-b[1,:2],b[0,:2]-a[1,:2]),0)
    clearance=float(np.linalg.norm(separation));assert clearance>20
    report['three_mf']={'archive':archive_path.name,'objects':object_reports,'placed_bounds_mm':placed,
        'conservative_xy_bbox_clearance_mm':clearance,'within_256mm_plate':True,'each_bottom_z_mm':0,
        'contains_machine_settings':False,'contains_gcode':False,'archive_entries':entries}
    report['limits']='Selected STL channels and nominal clearances only; no physical assembly, slicing, or printing performed.'
    (HERE/'validation-exported-geometry.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
