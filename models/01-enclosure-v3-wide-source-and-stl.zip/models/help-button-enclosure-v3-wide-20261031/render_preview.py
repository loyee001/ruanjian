#!/usr/bin/env python3
"""Rasterize the actual exported STL triangles; no generated product imagery."""
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE=Path(__file__).resolve().parent

def read_stl(path):
    data=path.read_bytes()
    dtype=np.dtype([('normal','<f4',3),('vertices','<f4',(3,3)),('attribute','<u2')])
    return np.frombuffer(data,dtype=dtype,offset=84)['vertices'].astype(float)

def render(triangles,image,box,camera,colour,interior_shading=False):
    towards=np.array(camera,dtype=float); towards/=np.linalg.norm(towards)
    right=-np.cross([0,0,1],towards); right/=np.linalg.norm(right)
    up=np.cross(towards,-right)
    normals=np.cross(triangles[:,1]-triangles[:,0],triangles[:,2]-triangles[:,0])
    normals/=np.maximum(np.linalg.norm(normals,axis=1)[:,None],1e-12)
    visible=normals@towards>1e-8
    triangles,normals=triangles[visible],normals[visible]
    projected=np.stack((triangles@right,-(triangles@up)),axis=-1)
    lo,hi=projected.min(axis=(0,1)),projected.max(axis=(0,1))
    x,y,width,height=box
    scale=min(width/(hi[0]-lo[0]),height/(hi[1]-lo[1]))
    projected=(projected-(lo+hi)/2)*scale+[x+width/2,y+height/2]
    light=np.array([-.4,.65,1.]); light/=np.linalg.norm(light)
    brightness=.57+.43*np.maximum(normals@light,0)
    if interior_shading:
        # Only shade existing inner faces darker; geometry is never added/removed.
        centres=triangles.mean(axis=1)
        inside=(centres[:,1]<22)&(np.abs(centres[:,0])<47)&(centres[:,2]>3)&(centres[:,2]<73)
        brightness*=np.where(inside,.68,1)
    colours=np.clip(np.array(colour)*brightness[:,None],0,255).astype(int)
    order=np.argsort((triangles@towards).mean(axis=1))
    draw=ImageDraw.Draw(image)
    for i in order:
        draw.polygon([tuple(p) for p in projected[i]],fill=tuple(colours[i]))

def main():
    image=Image.new('RGB',(2000,1380),'#F5F3EF')
    draw=ImageDraw.Draw(image)
    font='/System/Library/Fonts/STHeiti Medium.ttc'
    title=ImageFont.truetype(font,51)
    text=ImageFont.truetype(font,34)
    small=ImageFont.truetype(font,27)
    draw.text((65,38),'外壳 V3 · 左右各加宽 5 mm',font=title,fill='#24362A')
    draw.rounded_rectangle((45,130,965,1240),28,fill='white')
    draw.rounded_rectangle((990,130,1955,765),28,fill='white')
    draw.rounded_rectangle((990,790,1955,1240),28,fill='white')
    draw.text((85,170),'正面 · 整体加宽，顶部按钮口保留',font=text,fill='#38423A')
    body=read_stl(HERE/'body-wide-v3.stl')
    render(body,image,(95,285,820,690),(.32,-1,.36),[246,233,207])
    draw=ImageDraw.Draw(image)
    draw.text((85,1045),'主体名义宽 98 mm（含双手约 120 mm）',font=small,fill='#24362A')
    draw.text((85,1100),'高度与深度保持原设计',font=small,fill='#5E6860')
    draw.text((85,1155),'眼窝外移，原黑眼珠形状与尺寸保留',font=small,fill='#5E6860')
    draw.text((1030,170),'背面 · 检修口同步加宽至 80 × 56 mm',font=text,fill='#38423A')
    render(body,image,(1085,245,775,385),(.22,1,.32),[246,233,207],True)
    draw=ImageDraw.Draw(image)
    draw.text((1030,680),'原插线缺口 20 × 12 mm 保留，底板仍为 3 mm',font=small,fill='#5E6860')
    draw.text((1030,825),'匹配后盖 · 90 × 64 mm',font=text,fill='#38423A')
    render(read_stl(HERE/'rear-cover-wide-v3.stl'),image,(1035,900,530,260),(.18,-1,1.7),[246,233,207])
    draw=ImageDraw.Draw(image)
    draw.text((1575,945),'止口单边',font=small,fill='#24362A')
    draw.text((1575,995),'名义间隙 0.4 mm',font=small,fill='#24362A')
    draw.text((1575,1060),'四孔中心距',font=small,fill='#5E6860')
    draw.text((1575,1110),'78 × 54 mm',font=small,fill='#5E6860')
    draw.text((65,1290),'根据实际导出 STL 三角网格绘制；未实装、未切片、未打印。',font=small,fill='#687168')
    image.save(HERE/'外壳V3-宽版-实际网格预览.png')

if __name__=='__main__': main()
