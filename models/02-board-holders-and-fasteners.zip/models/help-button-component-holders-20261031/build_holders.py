#!/usr/bin/env python3
"""Two independent PCB cradles with matching custom coarse screws, units mm.

The supplied board outlines and ESP mounting-hole centres are authoritative.
Connector envelopes, PCB thickness and installation height have not been measured.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import zipfile
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'help-button-print-reference-20261030/printable-prototype-v1/build_prototype.py'
spec = importlib.util.spec_from_file_location('mesh_tools', SOURCE)
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)

PITCH = 1.5
MAJOR_RADIUS = 3.0
ROOT_RADIUS = 2.25
RADIAL_CLEARANCE = 0.30
BOSS_R = 4.3
BOSS_H = 5.0
BOARD_SUPPORT_Z = 5.0
BASE_H = 2.0
SCREW_SHAFT = 7.0
HEAD_H = 3.0
HOLDER_STEP = .28
THREAD_STEP = .13
CREAM = [244, 228, 201]

BOARDS = {
    'esp32': {'board_mm': [52.0, 28.0], 'recess_mm': [52.6, 28.6],
              'mount_hole_centres_mm': [47.0, 23.0], 'mount_hole_diameter_mm': 3.0,
              'boss_x': 30.7, 'boss_y': 10.5, 'end_window_half_width': 6.5,
              'label': 'ESP32 开发板托座'},
    'button': {'board_mm': [30.0, 20.0], 'recess_mm': [30.6, 20.6],
               'mount_hole_centres_mm': None, 'mount_hole_diameter_mm': None,
               'boss_x': 19.7, 'boss_y': 7.5, 'end_window_half_width': 6.2,
               'label': 'DFR0029 按钮板托座'},
}


def thread_radius(x, y, z):
    """Symmetric triangular custom right-handed helix; not ISO M6."""
    theta = np.arctan2(y, x)
    phase = (z / PITCH - theta / (2 * np.pi)) % 1.0
    ridge = 1.0 - 2.0 * np.abs(phase - .5)
    return ROOT_RADIUS + (MAJOR_RADIUS - ROOT_RADIUS) * ridge


def holder_field(config):
    px, py = np.array(config['recess_mm']) / 2
    def field(x, y, z):
        base = g.slabshape(x, y, z, px + 2, py + 2, 1.5, 0, BASE_H)
        outer = g.slabshape(x, y, z, px + 2, py + 2, 1.5, 1.8, 7.2)
        # Square, known-size pocket walls; low floor is 3 mm below PCB support.
        inside = g.box(x, y, z, (0, 0, 6), (px, py, 5))
        wall = np.maximum(outer, -inside)
        f = np.minimum(base, wall)
        # 1.3 mm wide edge ledges avoid the middle of the solder side.
        for sy in (-1, 1):
            rail = g.box(x, y, z, (0, sy*(py-.65), 3.45),
                         (px, .65, 1.55))
            f = np.minimum(f, rail)
        # Open both short-edge centres for USB / PH leads. Exact connectors pending.
        for sx in (-1, 1):
            window = g.box(x, y, z, (sx*(px+1), 0, 7),
                           (2.1, config['end_window_half_width'], 5))
            f = np.maximum(f, -window)
        # Clamp tabs must cross the rim without resting on its 7.2 mm top.
        # Lower the entire crossing to the PCB underside support plane, z=5.
        for side in (-1, 1):
            crossing = g.box(x, y, z, (side*(px+1), side*config['boss_y'], 8),
                             (2.3, 4.6, 3))
            f = np.maximum(f, -crossing)
        if config['mount_hole_centres_mm']:
            hx, hy = np.array(config['mount_hole_centres_mm']) / 2
            for sx in (-1, 1):
                for sy in (-1, 1):
                    xp, yp = x-sx*hx, y-sy*hy
                    post = g.cyl(xp, yp, z, 2.1, 1.9, 5.05)
                    pin = g.cyl(xp, yp, z, 1.3, 4.95, 5.8)
                    f = np.minimum(f, np.minimum(post, pin))
        # Diagonally opposed screw bosses sit outside the PCB, away from port centres.
        for side in (-1, 1):
            xp = x - side*config['boss_x']
            yp = y - side*config['boss_y']
            boss = g.cyl(xp, yp, z, BOSS_R, 0, BOSS_H)
            f = np.minimum(f, boss)
            bore_r = thread_radius(xp, yp, z) + RADIAL_CLEARANCE
            bore = np.maximum(np.hypot(xp, yp)-bore_r, np.maximum(-1-z, z-6))
            f = np.maximum(f, -bore)
        return f
    return field


def screw_field(x, y, z):
    theta = np.arctan2(y, x)
    # Eight shallow grips; wide head prints on bed, shaft upwards.
    head_r = 4.15 + .15*np.cos(8*theta)
    head = np.maximum(np.hypot(x, y)-head_r, np.maximum(-z, z-HEAD_H))
    local_z = z - HEAD_H
    radial = thread_radius(x, y, local_z)
    # Chamfer the final 0.7 mm for easy starting; preserves handedness.
    radial = np.minimum(radial, ROOT_RADIUS + np.maximum(0, SCREW_SHAFT-local_z)*1.1)
    shaft = np.maximum(np.hypot(x, y)-radial,
                       np.maximum(2.85-z, z-(HEAD_H+SCREW_SHAFT)))
    return np.minimum(head, shaft)


def clamp_field(x, y, z):
    # Long end points towards PCB. 1.1 mm nominal overlap on a component-free edge.
    ring = g.cyl(x, y, z, 4.3, 0, 2.0)
    arm = g.slabshape(x+3.9, y, z, 1.9, 1.5, .45, 0, 2.0)
    plate = np.minimum(ring, arm)
    # Full ring around the 6.6 mm clearance hole; narrow arm touches only board edge.
    slot = g.cyl(x, y, z, 3.3, -1, 3)
    return np.maximum(plate, -slot)


def write_mf(path, parts, title):
    lines = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02">',
             f'<metadata name="Title">{title}</metadata><resources>',
             '<basematerials id="100"><base name="Cream PLA reference" displaycolor="#F4E4C9"/></basematerials>']
    build = []
    bounds = []
    for idx, (name, v, f, pos) in enumerate(parts, 1):
        lines.append(f'<object id="{idx}" type="model" name="{name}" pid="100" pindex="0"><mesh><vertices>')
        lines.extend('<vertex x="%.5f" y="%.5f" z="%.5f"/>' % tuple(q) for q in v)
        lines.append('</vertices><triangles>')
        lines.extend('<triangle v1="%d" v2="%d" v3="%d"/>' % tuple(q) for q in f)
        lines.append('</triangles></mesh></object>')
        build.append(f'<item objectid="{idx}" transform="1 0 0 0 1 0 0 0 1 {pos[0]} {pos[1]} 0"/>')
        lo, hi = v.min(axis=0)+[*pos, 0], v.max(axis=0)+[*pos, 0]
        bounds.append({'name': name, 'bounds_mm': [lo.tolist(), hi.tolist()]})
    lines.append('</resources><build>'+''.join(build)+'</build></model>')
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as out:
        out.writestr('[Content_Types].xml', '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
        out.writestr('_rels/.rels', '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
        out.writestr('3D/3dmodel.model', ''.join(lines))
    gaps = []
    for i, a in enumerate(bounds):
        for b in bounds[i+1:]:
            aa, bb = np.array(a['bounds_mm']), np.array(b['bounds_mm'])
            d = np.maximum(np.maximum(aa[0,:2]-bb[1,:2], bb[0,:2]-aa[1,:2]), 0)
            gaps.append(float(np.linalg.norm(d)))
    assert min(gaps) >= 5
    return {'objects': bounds, 'minimum_xy_bbox_clearance_mm': round(min(gaps),3),
            'all_parts_flat_on_bed': all(abs(q['bounds_mm'][0][2])<1e-6 for q in bounds),
            'model_only_not_sliced': True}


def render_meshes(image, parts, area):
    tris = np.concatenate([v[f]+[*pos,0] for _,v,f,pos in parts])
    normals = np.cross(tris[:,1]-tris[:,0], tris[:,2]-tris[:,0])
    normals /= np.maximum(np.linalg.norm(normals,axis=1)[:,None],1e-12)
    camera=np.array([.35,-.7,1.1]);camera/=np.linalg.norm(camera)
    right=np.cross([0,0,1],camera);right/=np.linalg.norm(right)
    up=np.cross(camera,right)
    use=normals@camera>0
    tris,normals=tris[use],normals[use]
    proj=np.stack((tris@right, -(tris@up)),axis=-1)
    lo,hi=proj.min(axis=(0,1)),proj.max(axis=(0,1))
    x,y,w,h=area;scale=min(w/(hi[0]-lo[0]),h/(hi[1]-lo[1]))
    proj=(proj-(lo+hi)/2)*scale+[x+w/2,y+h/2]
    light=np.array([-.4,-.7,1]);light/=np.linalg.norm(light)
    brightness=.56+.44*np.maximum(normals@light,0)
    colours=np.clip(np.array(CREAM)[None,:]*brightness[:,None],0,255).astype(int)
    order=np.argsort((tris@camera).mean(axis=1))
    draw=ImageDraw.Draw(image)
    for i in order:draw.polygon([tuple(q) for q in proj[i]],fill=tuple(colours[i]))


def preview(plates):
    img=Image.new('RGB',(1800,1260),'#F5F3EF');d=ImageDraw.Draw(img)
    font='/System/Library/Fonts/STHeiti Medium.ttc'
    title=ImageFont.truetype(font,48);text=ImageFont.truetype(font,32);small=ImageFont.truetype(font,26)
    d.text((60,38),'两块板，各一个小托座 · 分两盘打印',font=title,fill='#24362A')
    for j,(kind,parts) in enumerate(plates.items()):
        x=50+j*880
        d.rounded_rectangle((x,135,x+840,1130),28,fill='white')
        d.text((x+28,160),f'第 {j+1} 盘  '+BOARDS[kind]['label'],font=text,fill='#24362A')
        render_meshes(img,parts,(x+45,250,750,650))
        bw,bh=BOARDS[kind]['board_mm'];rw,rh=BOARDS[kind]['recess_mm']
        d.text((x+28,945),f'板子 {bw:g}×{bh:g}  /  凹槽 {rw:g}×{rh:g} mm',font=small,fill='#38423A')
        d.text((x+28,998),'1 个托座 + 2 颗粗牙螺丝 + 2 个压片',font=small,fill='#38423A')
        d.text((x+28,1051),'平底朝下；螺丝头贴板、螺杆朝上',font=small,fill='#38423A')
    d.text((60,1170),'由实际 STL 网格绘制。螺纹与实物板卡尚未试装；颜色仅为参考，未发送打印。',font=small,fill='#626C65')
    img.save(HERE/'两盘托座-实际模型预览.png')
    # Individual meshes for the parent's explanatory PPT.
    for kind,parts in plates.items():
        single=Image.new('RGB',(1400,950),'#F5F3EF')
        render_meshes(single,parts,(75,110,1250,700))
        ds=ImageDraw.Draw(single);ds.text((50,35),BOARDS[kind]['label']+' · 一盘完整五件',font=text,fill='#24362A')
        ds.text((50,875),'模型预览；实物装配与粗牙配合尚待确认。',font=small,fill='#626C65')
        single.save(HERE/f'plate-{kind}-preview.png')


def generate():
    original_files=[SOURCE.parent/n for n in ['body.stl','top-button.stl','rear-cover.stl']]
    originals={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in original_files}
    meshes={}
    print('Meshing custom screw...',flush=True)
    meshes['coarse-screw']=g.mesh(screw_field,[(-5,5),(-5,5),(-.2,11.2)],THREAD_STEP)
    print('Meshing edge clamp...',flush=True)
    meshes['edge-clamp']=g.mesh(clamp_field,[(-6.3,5.0),(-4.8,4.8),(-.2,2.3)],.16)
    report={'units':'mm','parameters':{'boards':BOARDS,
            'radial_pocket_clearance_each_side_mm':.30,
            'under_pcb_clearance_mm':3.0,'pcb_support_top_mm':BOARD_SUPPORT_Z,
            'esp_locating_pin_diameter_mm':2.6,'esp_pin_above_support_mm':.8,
            'custom_thread':{'nominal_major_diameter_mm':6,'pitch_mm':PITCH,
                            'radial_clearance_mm':RADIAL_CLEARANCE,'shaft_length_mm':SCREW_SHAFT,
                            'is_iso_m6':False,'physical_thread_fit_verified':False},
            'physical_pcb_fit_verified':False,'installed_button_trigger_height_verified':False},
            'meshes':{},'plates':{},'original_parts_sha256_unchanged':originals,
            'limitations':['Only board outlines and supplied ESP mounting holes are dimensioned.',
                           'PCB thickness, solder height, connectors, component-free clamp lands and switch trigger height require physical verification.',
                           'Custom printed screws are not ISO M6 and have not been physically fitted.',
                           'Bottom uses insulated adhesive; no existing body mounting holes are assumed.'],
            'sliced':False,'printer_command_sent':False}
    clamp_v,clamp_f=meshes['edge-clamp']
    # Validate the known rim/tab collision in a 1.6 mm thickness EXAMPLE only.
    report['assembly_example_not_physical_fit']={'example_pcb_thickness_mm':1.6,
        'example_pcb_top_z_mm':6.6,'screw_tip_z_mm':1.6,
        'minimum_clamp_to_holder_source_field':{}}
    plates={}
    for kind,cfg in BOARDS.items():
        print('Meshing '+kind+' cradle...',flush=True)
        px,py=np.array(cfg['recess_mm'])/2
        field=holder_field(cfg)
        clamp_samples=np.vstack((clamp_v,clamp_v[clamp_f].mean(axis=1)))
        for side in (-1,1):
            wp=clamp_samples.copy()
            wp[:,:2]*=side
            wp[:,0]+=side*cfg['boss_x'];wp[:,1]+=side*cfg['boss_y'];wp[:,2]+=6.6
            gap=float(field(wp[:,0],wp[:,1],wp[:,2]).min())
            assert gap>0,(kind,side,'clamp intersects cradle',gap)
            report['assembly_example_not_physical_fit']['minimum_clamp_to_holder_source_field'][kind+str(side)]=gap
        v,f=g.mesh(field,[(-cfg['boss_x']-4.8,cfg['boss_x']+4.8),(-py-2.5,py+2.5),(-.2,7.7)],HOLDER_STEP)
        meshes[kind+'-holder']=(v,f)
        # This is a cradle under the PCB, not a stand calibrated to the outer hat.
        parts=[(kind+'-holder',v,f,(100,100)),
               ('coarse-screw-1',*meshes['coarse-screw'],(80,145)),
               ('coarse-screw-2',*meshes['coarse-screw'],(96,145)),
               ('edge-clamp-1',*meshes['edge-clamp'],(118,145)),
               ('edge-clamp-2',*meshes['edge-clamp'],(140,145))]
        plates[kind]=parts
    for name,(v,f) in meshes.items():
        stats=g.validate(v,f)
        assert stats['boundary_edges']==stats['nonmanifold_edges']==0,(name,stats)
        assert stats['surface_components']==1 and stats['signed_volume_mm3']>0,(name,stats)
        assert v[:,2].min()>=-1e-6
        g.stl(HERE/(name+'.stl'),v,f)
        report['meshes'][name]=stats
    for number,(kind,parts) in enumerate(plates.items(),1):
        fname=f'plate-{number}-'+kind+'.3mf'
        report['plates'][fname]=write_mf(HERE/fname,parts,kind+' cradle + two custom screws + two clamps')
    assert all(hashlib.sha256(p.read_bytes()).hexdigest()==originals[str(p)] for p in original_files)
    preview(plates)
    (HERE/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (HERE/'说明.txt').write_text('''两块板，各做一个浅托座，按两盘打印

第 1 盘：plate-1-esp32.3mf
适用图纸中的 52×28 mm 开发板；凹槽 52.6×28.6 mm。
4 个直径 2.6 mm 的短定位柱按 47×23 mm 孔距排布，对应板上直径 3 mm 的孔。
托座外包络约 70×32.6 mm。

第 2 盘：plate-2-button.3mf
适用 DFR0029 的 30×20 mm 按钮板；凹槽 30.6×20.6 mm。
按钮板孔距未提供，因此没有编造定位柱或安装孔。
托座外包络约 48×24.6 mm。

每盘均含：1 个托座、2 颗自定义粗牙手拧螺丝、2 个边缘压片，共 5 件。
coarse-screw.stl 和 edge-clamp.stl 各是一件，两盘工程中已经各放了两件。
螺丝拧在托座外侧的螺纹座，压片压住板边；粗螺丝不穿电路板原来的 3 mm 孔。
两头中间开口用于引出 USB / PH 接线；具体插头空间尚未实测。

打印：单位毫米，保持工程原方向，托座平底贴板、螺丝头贴板且螺杆向上、压片平放。
建议 PLA，0.4 mm 喷嘴、0.16 mm 层高，螺丝与压片 100% 填充，不加支撑。
托座可用 4 层墙、25% 填充。颜色仅为奶白参考，请选择实际装载材料。
请按实际机型分别切片；工程只有模型，不含特定机器的 G-code，也没有发送打印。

装配：清理底边毛刺；轻放板卡，再让两个压片压住没有元件的窄板边，轻轻手拧。
若压片触碰元件、连接器或焊脚，不要硬拧，需按实物调整夹点。
板底名义净空约 3 mm，板厚、焊脚、接口尺寸均未实测；螺纹也尚未经过实物配合验证。
自定义螺纹约 6 mm 外径、1.5 mm 螺距，与标准 M6 螺丝不通用，不用于受力结构。
托座底部用绝缘双面胶固定在主壳内部；现有主壳没有为托座预设安装孔。

重要：这两个是独立托座，不是已校准高度的上下叠放机构。
按钮板必须按绿色帽的实际触发柱高度固定；目前不能保证放进去就能按到或自行回弹。
未修改原主壳、后盖、绿色按钮，未覆盖正在运行的打印任务。
''')
    print(json.dumps({k:{n:r[n] for n in ['triangles','size_mm','boundary_edges','surface_components']} for k,r in report['meshes'].items()},ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':
    HERE.mkdir(parents=True,exist_ok=True)
    generate()
