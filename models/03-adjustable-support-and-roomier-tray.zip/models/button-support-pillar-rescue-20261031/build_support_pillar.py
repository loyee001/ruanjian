#!/usr/bin/env python3
"""Screwless modular support for an existing button cradle, all dimensions mm.

Heights are alternatives, not dimensions inferred from the user's photograph.
Male pegs insert into blind sockets; broad shoulder faces carry vertical load.
No thread, snap, PCB locating post or enclosure fixing interface is introduced.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import datetime
import hashlib
import importlib.util
import json
import struct
import zipfile
import xml.etree.ElementTree as ET
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
TOOL = HERE.parent/'help-button-print-reference-20261030/printable-prototype-v1/build_prototype.py'
spec = importlib.util.spec_from_file_location('prototype_sdf', TOOL)
g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)

PEG = 8.0
PEG_HEIGHT = 3.0
SOCKET = 8.5
SOCKET_DEPTH = 3.3
STEP = .25
SPECS = {
    'wide-base': {'xy': [40.0, 30.0], 'body_h': 4.0, 'peg': True, 'socket': False, 'count': 1, 'label': '宽底座'},
    'main-pillar': {'xy': [20.0, 16.0], 'body_h': 20.0, 'peg': True, 'socket': True, 'count': 1, 'label': '主柱'},
    'riser-5mm': {'xy': [20.0, 16.0], 'body_h': 5.0, 'peg': True, 'socket': True, 'count': 6, 'label': '5 mm 加高节'},
    'top-support': {'xy': [36.0, 26.0], 'body_h': 6.0, 'peg': False, 'socket': True, 'count': 1, 'label': '平顶承托板'},
    'shim-1mm': {'xy': [36.0, 26.0], 'body_h': 1.0, 'peg': False, 'socket': False, 'count': 1, 'label': '1 mm 垫片'},
    'shim-2mm': {'xy': [36.0, 26.0], 'body_h': 2.0, 'peg': False, 'socket': False, 'count': 2, 'label': '2 mm 垫片'},
}


def field(kind, x, y, z):
    cfg = SPECS[kind]; w, d = cfg['xy']; h = cfg['body_h']
    shape = g.box(x, y, z, (0, 0, h/2), (w/2, d/2, h/2))
    if cfg['peg']:
        # Overlap the body by .3 mm to avoid a zero-thickness union interface.
        low, high = h-.3, h+PEG_HEIGHT
        peg = g.box(x, y, z, (0, 0, (low+high)/2), (PEG/2, PEG/2, (high-low)/2))
        shape = np.minimum(shape, peg)
    if cfg['socket']:
        low, high = -1.0, SOCKET_DEPTH
        socket = g.box(x, y, z, (0, 0, (low+high)/2), (SOCKET/2, SOCKET/2, (high-low)/2))
        shape = np.maximum(shape, -socket)
    return shape


def stack(risers, use_main=True, shims=()):
    parts = [('wide-base', 0.0)]
    z = 4.0
    if use_main:
        parts.append(('main-pillar', z)); z += 20.0
    for _ in range(risers):
        parts.append(('riser-5mm', z)); z += 5.0
    parts += [('top-support', z)]
    z += 6.0
    for kind in shims:
        parts.append((kind, z)); z += SPECS[kind]['body_h']
    return parts, z


def mesh_from_stl(path):
    data = path.read_bytes(); count = struct.unpack_from('<I', data, 80)[0]
    assert len(data) == 84+50*count
    dtype = np.dtype([('normal', '<f4', (3,)), ('vertices', '<f4', (3, 3)), ('attribute', '<u2')])
    tris = np.frombuffer(data, dtype=dtype, offset=84, count=count)['vertices'].astype(float)
    v, inverse = np.unique(tris.reshape(-1, 3), axis=0, return_inverse=True)
    return v, inverse.reshape(-1, 3)


def validate_joints(meshes):
    result = []
    for lower, upper in [('wide-base', 'top-support'), ('wide-base', 'riser-5mm'),
                         ('wide-base', 'main-pillar'), ('main-pillar', 'riser-5mm'),
                         ('riser-5mm', 'riser-5mm'), ('main-pillar', 'top-support'),
                         ('riser-5mm', 'top-support'), ('top-support', 'shim-1mm'),
                         ('top-support', 'shim-2mm'), ('shim-1mm', 'shim-2mm'),
                         ('shim-2mm', 'shim-2mm'), ('shim-2mm', 'shim-1mm')]:
        lower_h = SPECS[lower]['body_h']
        v1, f1 = meshes[lower]; v2, f2 = meshes[upper]
        # Samples come from actual exported STL vertices and face centroids.
        samples1 = np.vstack((v1, v1[f1].mean(axis=1)))
        samples2 = np.vstack((v2, v2[f2].mean(axis=1)))
        upper_into_lower = field(lower, samples2[:, 0], samples2[:, 1], samples2[:, 2]+lower_h)
        lower_into_upper = field(upper, samples1[:, 0], samples1[:, 1], samples1[:, 2]-lower_h)
        penetration = max(0.0, -float(upper_into_lower.min()), -float(lower_into_upper.min()))
        assert penetration < .00005, (lower, upper, penetration)
        # Shared shoulder points are outside the socket and inside both body footprints.
        cx, cy = np.meshgrid(np.linspace(5.0, 8.5, 8), np.linspace(-6, 6, 13), indexing='ij')
        lo = field(lower, cx, cy, np.full_like(cx, lower_h))
        hi = field(upper, cx, cy, np.zeros_like(cx))
        assert np.all(np.abs(lo) < 1e-8) and np.all(np.abs(hi) < 1e-8)
        assert np.all(field(lower, cx, cy, np.full_like(cx, lower_h-.05)) < 0)
        assert np.all(field(upper, cx, cy, np.full_like(cx, .05)) < 0)
        contact_xy = np.minimum(SPECS[lower]['xy'], SPECS[upper]['xy'])
        result.append({'lower': lower, 'upper': upper, 'upper_bottom_z_mm': lower_h,
                       'shoulder_gap_mm': 0.0, 'nominal_contact_area_mm2': float(np.prod(contact_xy)-(SOCKET*SOCKET if SPECS[upper]['socket'] else 0)),
                       'contact_samples': int(cx.size), 'faces_contact_under_compression': True,
                       'max_sampled_stl_to_source_penetration_mm': penetration,
                       'peg_side_clearance_mm': (SOCKET-PEG)/2 if SPECS[lower]['peg'] and SPECS[upper]['socket'] else None,
                       'peg_tip_to_socket_ceiling_gap_mm': SOCKET_DEPTH-PEG_HEIGHT if SPECS[lower]['peg'] and SPECS[upper]['socket'] else None})
    return result


def validate_shim_heights(meshes, choices):
    result = []
    for height, use_main, count in [(10, False, 0), (60, True, 6)]:
        for shims in choices.values():
            assembled, expected = stack(count, use_main=use_main, shims=shims)
            low = min(float(meshes[k][0][:, 2].min()+z) for k, z in assembled)
            high = max(float(meshes[k][0][:, 2].max()+z) for k, z in assembled)
            assert abs(high-low-expected) < .0001
            result.append({'base_support_height_mm': height, 'shims': shims,
                           'actual_stl_height_mm': high-low, 'expected_total_height_mm': expected})
    return result


def write_plate(path, parts, meshes):
    ns = 'http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
    lines = [f'<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xml:lang="en-US" xmlns="{ns}">',
             '<metadata name="Title">Adjustable button support pillar - twelve separate parts</metadata><resources>',
             '<basematerials id="100"><base name="Reference PLA" displaycolor="#F4E4C9"/></basematerials>']
    build = []; bounds = []
    for index, (name, kind, xy) in enumerate(parts, 1):
        v, f = meshes[kind]
        lines.append(f'<object id="{index}" type="model" name="{name}" pid="100" pindex="0"><mesh><vertices>')
        lines.extend('<vertex x="%.5f" y="%.5f" z="%.5f"/>' % tuple(point) for point in v)
        lines.append('</vertices><triangles>')
        lines.extend('<triangle v1="%d" v2="%d" v3="%d"/>' % tuple(face) for face in f)
        lines.append('</triangles></mesh></object>')
        build.append(f'<item objectid="{index}" transform="1 0 0 0 1 0 0 0 1 {xy[0]} {xy[1]} 0"/>')
        bounds.append({'name': name, 'type': kind, 'bbox_mm': [(v.min(axis=0)+[*xy, 0]).tolist(), (v.max(axis=0)+[*xy, 0]).tolist()]})
    lines.append('</resources><build>'+''.join(build)+'</build></model>')
    gaps = []
    for index, a in enumerate(bounds):
        for b in bounds[index+1:]:
            aa, bb = np.array(a['bbox_mm']), np.array(b['bbox_mm'])
            delta = np.maximum(np.maximum(aa[0, :2]-bb[1, :2], bb[0, :2]-aa[1, :2]), 0)
            gaps.append(float(np.linalg.norm(delta)))
    assert min(gaps) >= 5
    assert all(abs(part['bbox_mm'][0][2]) < 1e-6 for part in bounds)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('[Content_Types].xml', '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
        archive.writestr('_rels/.rels', '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
        archive.writestr('3D/3dmodel.model', ''.join(lines))
    with zipfile.ZipFile(path) as archive:
        xml = ET.fromstring(archive.read('3D/3dmodel.model'))
        assert len(xml.findall(f'{{{ns}}}resources/{{{ns}}}object')) == 12
        assert len(xml.findall(f'{{{ns}}}build/{{{ns}}}item')) == 12
    return {'object_count': 12, 'build_count': 12, 'parts': bounds, 'minimum_xy_bbox_clearance_mm': min(gaps),
            'all_parts_bottom_z0': True, 'machine_preset_present': False, 'gcode_present': False,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def render(image, tris, box, camera):
    camera = np.array(camera, dtype=float); camera /= np.linalg.norm(camera)
    right = np.cross([0, 0, 1], camera); right /= np.linalg.norm(right)
    up = np.cross(camera, right)
    normals = np.cross(tris[:, 1]-tris[:, 0], tris[:, 2]-tris[:, 0])
    normals /= np.maximum(np.linalg.norm(normals, axis=1)[:, None], 1e-12)
    visible = normals@camera > 1e-9
    tris, normals = tris[visible], normals[visible]
    projection = np.stack((tris@right, -(tris@up)), axis=-1)
    lo, hi = projection.min(axis=(0, 1)), projection.max(axis=(0, 1))
    x, y, width, height = box
    scale = min(width/(hi[0]-lo[0]), height/(hi[1]-lo[1]))
    projection = (projection-(lo+hi)/2)*scale+[x+width/2, y+height/2]
    light = np.array([-.4, -.65, 1]); light /= np.linalg.norm(light)
    brightness = .52+.48*np.maximum(normals@light, 0)
    colours = np.clip(np.array([244, 228, 201])[None, :]*brightness[:, None], 0, 255).astype(int)
    order = np.argsort((tris@camera).mean(axis=1)); draw = ImageDraw.Draw(image)
    for i in order:
        draw.polygon([tuple(point) for point in projection[i]], fill=tuple(colours[i]))


def previews(meshes, parts):
    font = '/System/Library/Fonts/STHeiti Medium.ttc'
    title = ImageFont.truetype(font, 46); regular = ImageFont.truetype(font, 30); small = ImageFont.truetype(font, 25)
    plate = Image.new('RGB', (1800, 1250), '#F4F3EE'); draw = ImageDraw.Draw(plate)
    draw.text((60, 30), '按钮托底承托柱 · 无螺丝 · 一盘 12 件', font=title, fill='#24452D')
    draw.text((60, 103), '1底座 + 1主柱 + 6加高节 + 1顶板 + 1片1mm垫片 + 2片2mm垫片', font=regular, fill='#4D5D4B')
    tri = np.concatenate([meshes[kind][0][meshes[kind][1]]+[*xy, 0] for _, kind, xy in parts])
    render(plate, tri, (100, 220, 1600, 760), (.13, -.35, 1.0))
    draw = ImageDraw.Draw(plate)
    draw.text((60, 30), '按钮托底承托柱 · 无螺丝 · 一盘 12 件', font=title, fill='#24452D')
    draw.text((60, 103), '1底座 + 1主柱 + 6加高节 + 1顶板 + 1片1mm垫片 + 2片2mm垫片', font=regular, fill='#4D5D4B')
    draw.text((60, 1040), '底座+顶板=10 mm；主柱可选；按5 mm增至60 mm，平垫片再微调0—5 mm。', font=regular, fill='#24452D')
    draw.text((60, 1103), '榫槽是插接定位，不是卡扣；高度未由照片标定，可先少量堆叠试摆。', font=small, fill='#4D5D4B')
    draw.text((60, 1160), '实际网格预览 · 未试装/未切片/未发送；底部盲槽有8.5 mm短跨桥接。', font=small, fill='#77523E')
    path1 = HERE/'承托柱-12件一盘-实际网格预览.png'; plate.save(path1)

    assembly = Image.new('RGB', (1500, 1300), '#F4F3EE'); draw = ImageDraw.Draw(assembly)
    draw.text((60, 30), '40 mm 装配示例 · 不是实测所需高度', font=title, fill='#24452D')
    draw.text((60, 110), '底座4 + 主柱20 + 两节各5 + 顶板6 = 40 mm', font=regular, fill='#4D5D4B')
    assembled, height = stack(2); assert height == 40
    tri = np.concatenate([meshes[kind][0][meshes[kind][1]]+[0, 0, z] for kind, z in assembled])
    render(assembly, tri, (230, 230, 1040, 790), (.55, -.75, .70))
    draw = ImageDraw.Draw(assembly)
    draw.text((60, 30), '40 mm 装配示例 · 不是实测所需高度', font=title, fill='#24452D')
    draw.text((60, 110), '底座4 + 主柱20 + 两节各5 + 顶板6 = 40 mm', font=regular, fill='#4D5D4B')
    draw.text((60, 1080), '顶面平整承托已有小托底；薄绝缘双面胶仅作临时定位，胶厚另计。', font=small, fill='#4D5D4B')
    draw.text((60, 1140), '方榫插入盲槽，受力支承面贴合；不是螺纹、卡扣或锁紧结构。', font=small, fill='#4D5D4B')
    draw.text((60, 1200), '实际网格装配预览；未完成实物承力、插合与按钮触发高度验证。', font=small, fill='#77523E')
    path2 = HERE/'承托柱-40mm装配示例-实际网格预览.png'; assembly.save(path2)
    return [{'path': str(path), 'basis': 'actual exported STL triangles', 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in [path1, path2]]


def main():
    original_paths = [HERE.parent/'help-button-component-holders-20261031'/name for name in ['button-holder.stl', 'build_holders.py']]
    old_hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in original_paths}
    meshes = {}; stats = {}
    for kind, cfg in SPECS.items():
        print('Meshing '+kind+'...', flush=True)
        w, d = cfg['xy']; total_h = cfg['body_h']+(PEG_HEIGHT if cfg['peg'] else 0)
        v, f = g.mesh(lambda x, y, z, k=kind: field(k, x, y, z),
                      [(-w/2-.5, w/2+.5), (-d/2-.5, d/2+.5), (-.2, total_h+.5)], STEP)
        report = g.validate(v, f)
        assert report['boundary_edges'] == report['nonmanifold_edges'] == 0
        assert report['surface_components'] == 1 and report['signed_volume_mm3'] > 0
        g.stl(HERE/(kind+'.stl'), v, f)
        meshes[kind] = mesh_from_stl(HERE/(kind+'.stl'))
        stats[kind] = {**report, 'requested_count': cfg['count'], 'effective_body_height_mm': cfg['body_h'],
                       'sha256': hashlib.sha256((HERE/(kind+'.stl')).read_bytes()).hexdigest()}
    joints = validate_joints(meshes)
    examples = []
    for target in range(10, 61, 5):
        use_main = target >= 30
        count = (target-(30 if use_main else 10))//5
        assembled, expected = stack(count, use_main=use_main)
        assert expected == target
        low = min(float(meshes[k][0][:, 2].min()+z) for k, z in assembled)
        high = max(float(meshes[k][0][:, 2].max()+z) for k, z in assembled)
        assert abs(high-low-expected) < .0001
        examples.append({'main_pillar_used': use_main, 'riser_count': count, 'effective_support_height_mm': expected,
                         'actual_stl_assembly_bbox_height_mm': high-low,
                         'placements': [{'part': k, 'bottom_z_mm': z} for k, z in assembled]})
    choices = {'shim_total_0mm': [], 'shim_total_1mm': ['shim-1mm'], 'shim_total_2mm': ['shim-2mm'],
               'shim_total_3mm': ['shim-1mm', 'shim-2mm'], 'shim_total_4mm': ['shim-2mm', 'shim-2mm'],
               'shim_total_5mm': ['shim-1mm', 'shim-2mm', 'shim-2mm']}
    placements = [('wide-base-1', 'wide-base', (40, 40)), ('main-pillar-1', 'main-pillar', (90, 40)),
                  ('top-support-1', 'top-support', (140, 40)), ('shim-1mm-1', 'shim-1mm', (200, 40)),
                  ('shim-2mm-1', 'shim-2mm', (40, 100)), ('shim-2mm-2', 'shim-2mm', (90, 100))]
    placements += [(f'riser-5mm-{i+1}', 'riser-5mm', xy) for i, xy in enumerate([(140, 90), (180, 90), (220, 90), (140, 130), (180, 130), (220, 130)])]
    plate = HERE/'按钮托底承托柱-可调10至60mm-12件.3mf'
    plate_report = write_plate(plate, placements, meshes)
    preview_report = previews(meshes, placements)
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == sha for p, sha in old_hashes.items())
    result = {'timestamp_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'units': 'mm', 'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'parameters': {'parts': SPECS, 'mesh_step_mm': STEP, 'peg_xy_mm': [PEG, PEG],
                             'peg_height_above_shoulder_mm': PEG_HEIGHT, 'socket_xy_mm': [SOCKET, SOCKET],
                             'socket_depth_mm': SOCKET_DEPTH, 'nominal_clearance_per_side_mm': (SOCKET-PEG)/2,
                             'socket_ceiling_above_peg_tip_mm': SOCKET_DEPTH-PEG_HEIGHT,
                             'riser_minimum_solid_web_above_socket_mm': 5-SOCKET_DEPTH,
                             'reference_existing_holder_middle_mm': [34.6, 24.6],
                             'top_support_face_mm': [36, 26], 'height_inferred_from_photo': False,
                             'optional_main_pillar': True, 'coarse_height_range_mm': [10, 60],
                             'coarse_height_step_mm': 5, 'extra_shim_adjustment_range_mm': [0, 5],
                             'user_reported_plunger_to_button_gap_mm': 2,
                             'reported_gap_used_to_set_support_height': False},
              'meshes': stats, 'joint_checks': joints, 'height_examples': examples,
              'shim_choices': choices, 'shim_height_examples': validate_shim_heights(meshes, choices),
              'plate': plate_report, 'previews': preview_report,
              'old_artifact_hashes_unchanged': old_hashes, 'physical_fit_verified': False,
              'load_or_button_trigger_verified': False, 'sliced': False, 'printer_command_sent': False,
              'scope': 'Closed/connected positive mesh; actual STL vertex+centroid to analytic field joint samples and nominal shoulder contact. Not a full mesh boolean or physical fit/strength test.'}
    (HERE/'validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    (HERE/'说明.txt').write_text('''按钮模块小托底的独立承托柱 · 无螺丝可调方案

用途：在平底盒内托住已有的按钮小托底，不是直接夹住PCB，也不是已按照片算出的固定高度。
用户给的2mm是压杆底到黄色按钮顶的间隙，不是小托底到壳底的支承高度，不能据此推定柱高，也不设计无间隙预压。
本套件提供10—60mm主支承高度，每5mm一档；主柱可选，顶面垫片另可加0—5mm。照片没有用来标定绝对高度。

一盘12件：宽底座1个（40×30，主体厚4mm）、主柱1个（20×16，主体高20mm）、5mm加高节6个、承托板1个（36×26，厚6mm）、1mm平垫片1片、2mm平垫片2片。
各类型另附STL，STL本身每个文件仅一件；全部实际数量已经在3MF里展开。

最低支承高度 = 底座4+顶板6 = 10mm，底座可直接插顶板；加1/2/3节分别15/20/25mm。
选用20mm主柱：底座4+主柱20+顶板6 = 30mm。加2节 = 40mm，加6节 = 60mm。
底座、主柱和加高节上方的3mm方榫会插入下一件，不在有效增高中重复相加。
方榫8×8mm、榫高3mm；底部盲插槽8.5×8.5mm、槽深3.3mm，单边名义间隙0.25mm，榫顶留0.3mm。
承重依靠接头周围的平面相接，不靠榫顶顶住；只有定位插接，没有锁扣、螺纹或锁紧力。

先平放宽底座，根据盒内空间选择是否使用主柱及0—6个加高节，最后插平顶承托板。主柱不是必须件。
将已有按钮小托底的中央实体部分放在承托板上；参考中央实体34.6×24.6mm，顶板36×26mm，仅为几何参考。两端耳朵可以外伸，不承诺未知实物适配。
若只需微调，将1/2/2mm平垫片叠在承托板上；可组合0、1、2、3、4、5mm。
可用很薄的绝缘双面胶临时定位底座、垫片及已有小托底；胶厚会增加总高度，需另计。
插上、轻按检查时不要强行顶住按钮。须留出按钮正常触发与回弹行程，也要避开插头、线缆及主壳内壁。

打印方向：所有件按3MF原方向，底面贴板、方榫朝上。带盲插槽件底部开口向下，槽顶有8.5mm短跨桥接，桥接和插合尚未实物验证。
建议0.4mm喷嘴、0.16或0.2mm层高、4墙、25%或更高填充。查看切片的盲槽桥接，避免在槽内留下难拆支撑。
3MF为毫米单位的模型工程，无打印机参数、无G-code；请按实际设备与耗材切片。
未试装、未切片、未发送打印；不保证未知盒内尺寸、实物插合、抗侧倒或长期承力。
''')
    print(json.dumps({'part_types': 6, 'physical_piece_count': 12, 'plate': str(plate),
                      'height_examples': examples, 'all_joint_sample_penetrations_mm': [j['max_sampled_stl_to_source_penetration_mm'] for j in joints]}, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    HERE.mkdir(parents=True, exist_ok=True)
    main()
