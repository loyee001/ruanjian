#!/usr/bin/env python3
"""Exact planar boundary mesh for the same axis-aligned modular-support SDF.

Exports to compact/ without changing the initial dense exports. A critical-plane
Cartesian cell decomposition removes unnecessary subdivisions of flat surfaces.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import datetime
import hashlib
import importlib.util
import json
import subprocess
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent
HERE = ROOT/'compact'
spec = importlib.util.spec_from_file_location('support_parameters', ROOT/'build_support_pillar.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
m.HERE = HERE


def exact_mesh(kind):
    cfg = m.SPECS[kind]; w, d = cfg['xy']; h = cfg['body_h']
    ax, ay, az = [-w/2, w/2], [-d/2, d/2], [0.0, h]
    if cfg['peg']:
        ax += [-m.PEG/2, m.PEG/2]; ay += [-m.PEG/2, m.PEG/2]
        az += [h-.3, h+m.PEG_HEIGHT]
    if cfg['socket']:
        ax += [-m.SOCKET/2, m.SOCKET/2]; ay += [-m.SOCKET/2, m.SOCKET/2]
        az += [m.SOCKET_DEPTH]
    axes = [np.array(sorted(set(a)), dtype=float) for a in [ax, ay, az]]
    centres = [(a[:-1]+a[1:])/2 for a in axes]
    xx, yy, zz = np.meshgrid(*centres, indexing='ij')
    occupied = m.field(kind, xx, yy, zz) < 0
    directions = [((-1, 0, 0), [0, 4, 7, 3]), ((1, 0, 0), [1, 2, 6, 5]),
                  ((0, -1, 0), [0, 1, 5, 4]), ((0, 1, 0), [3, 7, 6, 2]),
                  ((0, 0, -1), [0, 3, 2, 1]), ((0, 0, 1), [4, 5, 6, 7])]
    vertices, faces, lookup = [], [], {}
    def vertex(point):
        key = tuple(float(q) for q in point)
        if key not in lookup:
            lookup[key] = len(vertices); vertices.append(key)
        return lookup[key]
    for ix, iy, iz in np.argwhere(occupied):
        x0, x1 = axes[0][ix:ix+2]; y0, y1 = axes[1][iy:iy+2]; z0, z1 = axes[2][iz:iz+2]
        corners = [(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),
                   (x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)]
        for delta, quad in directions:
            other = np.array([ix, iy, iz])+delta
            if np.all(other >= 0) and np.all(other < occupied.shape) and occupied[tuple(other)]:
                continue
            a, b, c, d = [vertex(corners[q]) for q in quad]
            faces += [(a, b, c), (a, c, d)]
    return np.array(vertices, dtype=float), np.array(faces, dtype=np.int64)


def ray_hits(mesh, origin, direction, axis):
    vertices, faces = mesh; triangles = vertices[faces]
    origin = np.array(origin, dtype=float); direction = np.array(direction, dtype=float)
    e1, e2 = triangles[:,1]-triangles[:,0], triangles[:,2]-triangles[:,0]
    p = np.cross(direction, e2); det = np.einsum('ij,ij->i', e1, p)
    mask = np.abs(det) > 1e-10
    inv = np.zeros_like(det); inv[mask] = 1/det[mask]
    s = origin-triangles[:,0]
    u = np.einsum('ij,ij->i', s, p)*inv
    q = np.cross(s, e1)
    v = q@direction*inv
    t = np.einsum('ij,ij->i', e2, q)*inv
    valid = mask & (u >= -1e-8) & (v >= -1e-8) & (u+v <= 1+1e-8) & (t >= 0)
    return np.unique(np.round((origin[axis]+t[valid]*direction[axis]), 6))


def measure_exported_meshes(meshes):
    result = {'parts': {}, 'joint_clearances': []}
    for kind, cfg in m.SPECS.items():
        vertices, faces = meshes[kind]
        actual = np.ptp(vertices, axis=0)
        expected = np.array([*cfg['xy'], cfg['body_h']+(m.PEG_HEIGHT if cfg['peg'] else 0)])
        assert np.max(np.abs(actual-expected)) < .00001
        item = {'bbox_size_mm': actual.tolist(), 'expected_size_mm': expected.tolist()}
        if cfg['socket']:
            hits = ray_hits(meshes[kind], (.317, .223, -1), (0,0,1), 2)
            assert len(hits) >= 2 and abs(hits[0]-m.SOCKET_DEPTH) < .00001
            item['blind_socket_depth_mm'] = float(hits[0])
            widths = []
            for axis, origin, direction in [(0,(-50,.173,1),(1,0,0)), (1,(.173,-50,1),(0,1,0))]:
                hits = ray_hits(meshes[kind], origin, direction, axis)
                assert len(hits) == 4, (kind, axis, hits)
                widths.append(float(hits[2]-hits[1]))
            assert np.allclose(widths, [m.SOCKET,m.SOCKET], atol=.00001)
            item['socket_inner_xy_mm'] = widths
        if cfg['peg']:
            widths = []
            for axis, origin, direction in [(0,(-50,.173,cfg['body_h']+1),(1,0,0)),
                                             (1,(.173,-50,cfg['body_h']+1),(0,1,0))]:
                hits = ray_hits(meshes[kind], origin, direction, axis)
                assert len(hits) == 2, (kind, axis, hits)
                widths.append(float(hits[1]-hits[0]))
            assert np.allclose(widths, [m.PEG,m.PEG], atol=.00001)
            item['peg_outer_xy_mm'] = widths
            item['peg_above_shoulder_mm'] = float(vertices[:,2].max()-cfg['body_h'])
        result['parts'][kind] = item
    for lower, upper in [('wide-base','top-support'),('wide-base','main-pillar'),('wide-base','riser-5mm'),
                         ('main-pillar','riser-5mm'),('riser-5mm','riser-5mm'),
                         ('main-pillar','top-support'),('riser-5mm','top-support')]:
        clearance = (np.array(result['parts'][upper]['socket_inner_xy_mm'])-
                     np.array(result['parts'][lower]['peg_outer_xy_mm']))/2
        assert np.allclose(clearance,[.25,.25],atol=.00001)
        lower_plane = ray_hits(meshes[lower],(6.173,.223,-1),(0,0,1),2)[-1]
        upper_plane = ray_hits(meshes[upper],(6.173,.223,-1),(0,0,1),2)[0]
        gap = upper_plane+m.SPECS[lower]['body_h']-lower_plane
        assert abs(gap) < .00001
        result['joint_clearances'].append({'lower':lower,'upper':upper,
                                            'measured_single_side_xy_clearance_mm':clearance.tolist(),
                                            'measured_shoulder_gap_mm':float(gap)})
    return result


def render_depth_buffer(image, tris, box, camera):
    """Rasterize exact triangles with a depth buffer, including mating coplanar faces."""
    camera=np.array(camera,dtype=float); camera/=np.linalg.norm(camera)
    right=np.cross([0,0,1],camera); right/=np.linalg.norm(right)
    up=np.cross(camera,right)
    normals=np.cross(tris[:,1]-tris[:,0],tris[:,2]-tris[:,0])
    normals/=np.maximum(np.linalg.norm(normals,axis=1)[:,None],1e-12)
    visible=normals@camera>1e-9; tris,normals=tris[visible],normals[visible]
    projection=np.stack((tris@right,-(tris@up)),axis=-1)
    lo,hi=projection.min(axis=(0,1)),projection.max(axis=(0,1))
    x,y,width,height=box; scale=min(width/(hi[0]-lo[0]),height/(hi[1]-lo[1]))
    projection=(projection-(lo+hi)/2)*scale+[x+width/2,y+height/2]
    depths=tris@camera
    light=np.array([-.4,-.65,1]); light/=np.linalg.norm(light)
    brightness=.52+.48*np.maximum(normals@light,0)
    colours=np.clip(np.array([244,228,201])[None,:]*brightness[:,None],0,255).astype(np.uint8)
    pixels=np.array(image); zbuffer=np.full((image.height,image.width),-np.inf)
    for p,z,colour in zip(projection,depths,colours):
        x0=max(0,int(np.floor(p[:,0].min()))); x1=min(image.width,int(np.ceil(p[:,0].max()))+1)
        y0=max(0,int(np.floor(p[:,1].min()))); y1=min(image.height,int(np.ceil(p[:,1].max()))+1)
        if x1<=x0 or y1<=y0: continue
        denominator=(p[1,1]-p[2,1])*(p[0,0]-p[2,0])+(p[2,0]-p[1,0])*(p[0,1]-p[2,1])
        if abs(denominator)<1e-10: continue
        xx,yy=np.meshgrid(np.arange(x0,x1)+.5,np.arange(y0,y1)+.5)
        a=((p[1,1]-p[2,1])*(xx-p[2,0])+(p[2,0]-p[1,0])*(yy-p[2,1]))/denominator
        b=((p[2,1]-p[0,1])*(xx-p[2,0])+(p[0,0]-p[2,0])*(yy-p[2,1]))/denominator
        c=1-a-b; depth=a*z[0]+b*z[1]+c*z[2]
        region=zbuffer[y0:y1,x0:x1]
        mask=(a>=-1e-8)&(b>=-1e-8)&(c>=-1e-8)&(depth>region+1e-9)
        region[mask]=depth[mask]; pixels[y0:y1,x0:x1][mask]=colour
    image.paste(Image.fromarray(pixels))


def main():
    HERE.mkdir(exist_ok=True)
    report = json.loads((ROOT/'validation.json').read_text())
    meshes, stats = {}, {}
    for kind, cfg in m.SPECS.items():
        v, f = exact_mesh(kind)
        checked = m.g.validate(v, f)
        assert checked['boundary_edges'] == checked['nonmanifold_edges'] == 0
        assert checked['surface_components'] == 1 and checked['signed_volume_mm3'] > 0
        m.g.stl(HERE/(kind+'.stl'), v, f)
        meshes[kind] = m.mesh_from_stl(HERE/(kind+'.stl'))
        stats[kind] = {**checked, 'requested_count': cfg['count'], 'effective_body_height_mm': cfg['body_h'],
                       'sha256': hashlib.sha256((HERE/(kind+'.stl')).read_bytes()).hexdigest()}
    placements = []
    for part in report['plate']['parts']:
        bbox = np.array(part['bbox_mm'])
        placements.append((part['name'], part['type'], tuple((bbox[0,:2]+bbox[1,:2])/2)))
    plate = HERE/'按钮托底承托柱-可调10至60mm-12件-轻量版.3mf'
    report['plate'] = m.write_plate(plate, placements, meshes)
    report['meshes'] = stats
    report['joint_checks'] = m.validate_joints(meshes)
    report['shim_height_examples'] = m.validate_shim_heights(meshes, report['shim_choices'])
    for example in report['height_examples']:
        assembled, expected = m.stack(example['riser_count'], use_main=example['main_pillar_used'])
        low = min(float(meshes[k][0][:,2].min()+z) for k,z in assembled)
        high = max(float(meshes[k][0][:,2].max()+z) for k,z in assembled)
        assert abs(high-low-expected) < 1e-6
        example['actual_stl_assembly_bbox_height_mm'] = high-low
    report['mesh_measurements'] = measure_exported_meshes(meshes)
    m.render = render_depth_buffer
    report['previews'] = m.previews(meshes, placements)
    report['mesh_method'] = 'Exact Cartesian boundary extraction of original axis-aligned source field; no curved/thread features.'
    report['parameters']['mesh_step_mm'] = None
    report['compact_source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    report['compact_generated_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    validator = ROOT.parent/'help-button-print-reference-20261030/printable-prototype-v1/validate_meshes.py'
    result = subprocess.run([sys.executable, str(validator), *[str(HERE/(k+'.stl')) for k in m.SPECS]], capture_output=True, text=True)
    (HERE/'validation-independent.json').write_text(result.stdout)
    independent = json.loads(result.stdout)
    assert result.returncode == 0 and independent['passed'], result.stderr
    report['independent_stl_validation'] = {'passed': True, 'report': 'validation-independent.json', 'parts': 6,
                                           'all_six_closed_single_edge_component_positive_volume': True}
    (HERE/'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    (HERE/'说明.txt').write_text((ROOT/'说明.txt').read_text()+'\n轻量版：尺寸与原始方案相同，改用同一轴对齐源场的精确平面边界网格，减少平面的冗余细分，方便切片软件导入。\n')
    print(json.dumps({'plate': str(plate), 'bytes': plate.stat().st_size,
                      'triangles_per_type': {k:r['triangles'] for k,r in stats.items()},
                      'independent_validation_passed': True,
                      'max_joint_penetration_mm': max(r['max_sampled_stl_to_source_penetration_mm'] for r in report['joint_checks'])}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
