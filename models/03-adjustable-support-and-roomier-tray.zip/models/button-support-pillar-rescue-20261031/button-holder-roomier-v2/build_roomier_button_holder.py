#!/usr/bin/env python3
"""Enlarge only the button pocket by 1 mm in X/Y, then replace object 13.

Old artifacts, all twelve support-kit meshes, and every build transform remain
unchanged. No slicing, printer action or independent screws/clamps are added.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import datetime
import hashlib
import importlib.util
import json
import struct
import subprocess
import zipfile
import xml.etree.ElementTree as ET
import numpy as np

HERE=Path(__file__).resolve().parent
KIT=HERE.parent
OLD=KIT.parent/'help-button-component-holders-20261031'
SOURCE_3MF=KIT/'compact/立柱加按钮小底托-13件-同一盘.3mf'
spec=importlib.util.spec_from_file_location('existing_holders',OLD/'build_holders.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
NS='http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
N={'m':NS}
CONFIG=dict(h.BOARDS['button'])
CONFIG.update(recess_mm=[31.6,21.6],boss_x=20.2,label='按钮小底托 V2 · 凹槽长宽各加1mm')


def read_stl(path):
    data=path.read_bytes();count=struct.unpack_from('<I',data,80)[0]
    assert len(data)==84+50*count
    dtype=np.dtype([('normal','<f4',(3,)),('vertices','<f4',(3,3)),('attribute','<u2')])
    tris=np.frombuffer(data,dtype=dtype,offset=84,count=count)['vertices']
    vertices,inverse=np.unique(tris.reshape(-1,3),axis=0,return_inverse=True)
    return vertices,inverse.reshape(-1,3),tris


def ray_hits(tris,origin,direction,axis):
    tris=tris.astype(float);origin=np.array(origin,dtype=float);direction=np.array(direction,dtype=float)
    e1,e2=tris[:,1]-tris[:,0],tris[:,2]-tris[:,0]
    p=np.cross(direction,e2);det=np.einsum('ij,ij->i',e1,p)
    active=np.abs(det)>1e-10
    inv=np.zeros_like(det);inv[active]=1/det[active]
    s=origin-tris[:,0];u=np.einsum('ij,ij->i',s,p)*inv
    q=np.cross(s,e1);v=q@direction*inv;t=np.einsum('ij,ij->i',e2,q)*inv
    valid=active&(u>=-1e-8)&(v>=-1e-8)&(u+v<=1+1e-8)&(t>=0)
    return np.unique(np.round(origin[axis]+t[valid]*direction[axis],6))


def recess_measurements(tris):
    # End ports and clamp cut-outs interrupt the short walls. Sample each
    # uncut opposite end separately rather than measuring through a lead port.
    right=ray_hits(tris,(-50,-9.133,6.137),(1,0,0),0)
    left=ray_hits(tris,(-50,9.133,6.137),(1,0,0),0)
    right_inner=float(right[right>0][0]);left_inner=float(left[left<0][-1])
    across_y=ray_hits(tris,(.173,-50,6.137),(0,1,0),1)
    assert len(across_y)==4
    return {'x_inner_left_mm':left_inner,'x_inner_right_mm':right_inner,
            'recess_x_mm':right_inner-left_inner,'recess_y_mm':float(across_y[2]-across_y[1]),
            'sampling_z_mm':6.137,'sampling_method':'Actual exported STL ray intersections at uninterrupted inner-wall segments.'}


def object_bbox(obj,item):
    vertices=np.array([[float(p.attrib[k]) for k in ['x','y','z']] for p in obj.findall('m:mesh/m:vertices/m:vertex',N)])
    transform=list(map(float,item.attrib['transform'].split()))
    assert np.array_equal(transform[:9],np.eye(3).reshape(-1))
    vertices+=transform[9:12]
    return np.array([vertices.min(axis=0),vertices.max(axis=0)])


def xy_gap(a,b):
    delta=np.maximum(np.maximum(a[0,:2]-b[1,:2],b[0,:2]-a[1,:2]),0)
    return float(np.linalg.norm(delta))


def main():
    old_files=[OLD/'button-holder.stl',OLD/'build_holders.py',SOURCE_3MF]
    old_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in old_files}
    print('Meshing roomier button cradle only...',flush=True)
    f=h.holder_field(CONFIG);py=CONFIG['recess_mm'][1]/2
    vertices,faces=h.g.mesh(f,[(-CONFIG['boss_x']-4.8,CONFIG['boss_x']+4.8),(-py-2.5,py+2.5),(-.2,7.7)],h.HOLDER_STEP)
    mesh_stats=h.g.validate(vertices,faces)
    assert mesh_stats['boundary_edges']==mesh_stats['nonmanifold_edges']==0
    assert mesh_stats['surface_components']==1 and mesh_stats['signed_volume_mm3']>0
    stl=HERE/'button-holder-roomier-v2.stl'
    h.g.stl(stl,vertices,faces)
    vertices,faces,tris=read_stl(stl)
    _,_,old_tris=read_stl(OLD/'button-holder.stl')
    measured=recess_measurements(tris);old_measured=recess_measurements(old_tris)
    delta=[measured['recess_x_mm']-old_measured['recess_x_mm'],measured['recess_y_mm']-old_measured['recess_y_mm']]
    assert np.allclose([measured['recess_x_mm'],measured['recess_y_mm']],[31.6,21.6],atol=.00005)
    assert np.allclose(delta,[1,1],atol=.00005)
    with zipfile.ZipFile(SOURCE_3MF) as archive:
        entries={name:archive.read(name) for name in archive.namelist()}
    original_text=entries['3D/3dmodel.model'].decode('utf-8')
    original=ET.fromstring(entries['3D/3dmodel.model'])
    original_objects=original.findall('m:resources/m:object',N)
    original_build=original.findall('m:build/m:item',N)
    assert len(original_objects)==len(original_build)==13
    old_objects={obj.attrib['id']:ET.tostring(obj) for obj in original_objects[:12]}
    last_id=original_build[-1].attrib['objectid']
    assert last_id=='13'
    obj=next(p for p in original_objects if p.attrib['id']==last_id)
    parts=[f'<object id="{last_id}" type="model" name="button-holder-roomier-v2-13" pid="100" pindex="0"><mesh><vertices>']
    parts.extend('<vertex x="%.9g" y="%.9g" z="%.9g"/>'%tuple(v) for v in vertices)
    parts.append('</vertices><triangles>')
    parts.extend('<triangle v1="%d" v2="%d" v3="%d"/>'%tuple(face) for face in faces)
    parts.append('</triangles></mesh></object>')
    begin=original_text.index('<object id="'+last_id+'"')
    end=original_text.index('</object>',begin)+len('</object>')
    combined=original_text[:begin]+''.join(parts)+original_text[end:]
    entries['3D/3dmodel.model']=combined.encode('utf-8')
    output=HERE/'立柱加大按钮小底托-13件-同一盘.3mf'
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
        for name,data in entries.items():archive.writestr(name,data)
    with zipfile.ZipFile(output) as archive:
        parsed=ET.fromstring(archive.read('3D/3dmodel.model'))
        assert not any('gcode' in name.lower() or 'config' in name.lower() for name in archive.namelist())
    objects=parsed.findall('m:resources/m:object',N);build=parsed.findall('m:build/m:item',N)
    assert len(objects)==len(build)==13
    assert ET.tostring(parsed.find('m:build',N))==ET.tostring(original.find('m:build',N))
    assert all(ET.tostring(o)==old_objects[o.attrib['id']] for o in objects[:12])
    last=objects[-1]
    rv=np.array([[float(p.attrib[k]) for k in ['x','y','z']] for p in last.findall('m:mesh/m:vertices/m:vertex',N)],dtype=np.float32)
    rf=np.array([[int(p.attrib[k]) for k in ['v1','v2','v3']] for p in last.findall('m:mesh/m:triangles/m:triangle',N)])
    assert np.array_equal(rv[rf],tris)
    by_id={o.attrib['id']:o for o in objects}
    boxes=[object_bbox(by_id[item.attrib['objectid']],item) for item in build]
    gaps=[xy_gap(a,b) for i,a in enumerate(boxes) for b in boxes[i+1:]]
    assert min(gaps)>=5
    assert all(np.all(b[0,:2]>=0) and np.all(b[1,:2]<=256) and abs(b[0,2])<.000001 for b in boxes)
    validator=KIT.parent/'help-button-print-reference-20261030/printable-prototype-v1/validate_meshes.py'
    checked=subprocess.run([sys.executable,str(validator),str(stl)],capture_output=True,text=True)
    (HERE/'validation-independent.json').write_text(checked.stdout)
    independent=json.loads(checked.stdout)
    assert checked.returncode==0 and independent['passed'],checked.stderr
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in old_hashes.items())
    result={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'reference_board_mm':[30,20],'new_recess_mm':[31.6,21.6],'old_recess_mm':[30.6,20.6],
            'actual_stl_recess_measurements':measured,'original_stl_recess_measurements':old_measured,
            'actual_stl_recess_delta_xy_mm':delta,'height_mm':7.2,'base_thickness_mm':2,
            'pcb_support_z_mm':5,'boss_x_mm':20.2,'boss_y_mm':7.5,'end_window_half_width_mm':6.2,
            'central_body_xy_mm':[35.6,25.6],'support_plate_xy_mm':[36,26],
            'central_body_nominal_margin_per_side_xy_mm':[.2,.2],
            'support_scope':'Central body fits the centred top support nominal outline; end ears overhang. No physical fit/retention or alignment validation.',
            'mesh':mesh_stats,'independent_stl_validation_passed':True,
            'stl_sha256':hashlib.sha256(stl.read_bytes()).hexdigest(),
            'output_3mf':str(output),'output_3mf_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
            'objects':13,'build_items':13,'original_12_object_xml_exactly_preserved':True,
            'all_13_build_items_and_transforms_exactly_preserved':True,'new_stl_xml_float32_triangles_preserved':True,
            'last_object_world_bbox_mm':boxes[-1].tolist(),'minimum_xy_bbox_gap_mm':min(gaps),
            'all_inside_256x256':True,'all_bottom_z0':True,'new_screws_or_clamps_added':False,
            'old_artifact_sha256_unchanged':old_hashes,'physical_fit_verified':False,'sliced':False,
            'printer_command_sent':False,'machine_preset_present':False,'gcode_present':False}
    (HERE/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    (HERE/'说明.txt').write_text('''按钮小底托V2：只把凹槽长、宽各加1mm，不是整体缩放。
凹槽由30.6×20.6mm改为31.6×21.6mm；高度7.2、底厚2、PCB支承高度5mm均不变。
外侧两耳座保留，X中心由±19.7改±20.2mm，Y中心仍±7.5mm；没有新增独立螺丝或压片。
中央主体35.6×25.6mm，居中放在36×26mm立柱顶板上，单边名义余量只有0.2mm；耳座外伸。
仅几何名义覆盖，不保证打印收缩、边角毛刺、实际居中或固定。可用薄绝缘双面胶临时防滑，胶厚另计；不要压到PCB焊点。
完整13件3MF保留原12件立柱套件及所有位置，只替换第13件按钮小底托；V2仍位于(40,160,0)。
STL仅V2托座一件；13件工程已有它，不要再次叠加导入造成重复。
尚未实物试装、未切片、未发送打印；板卡尺寸、线口与触发行程仍需实物核对。
''')
    print(json.dumps({'output':str(output),'bytes':output.stat().st_size,'stl':str(stl),
                      'mesh':mesh_stats,'actual_recess_delta_xy_mm':delta,
                      'original_12_unchanged':True,'all_13_build_transforms_unchanged':True,
                      'min_xy_gap_mm':min(gaps),'independent_passed':True},ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':
    HERE.mkdir(parents=True,exist_ok=True)
    main()
