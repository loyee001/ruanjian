#!/usr/bin/env python3
"""Help-button shell V1. All dimensions mm. Pure numpy marching tetrahedra.
Exterior-fit prototype, not a hardware-calibrated assembly. See README.md.
"""
from pathlib import Path
import json, struct, zipfile, time
import numpy as np

OUT=Path(__file__).resolve().parent
STEP=0.65
PARAMS={"grid_mm":STEP,"body_nominal_mm":[88,62,76],"shell_wall_mm":3.0,
 "top_guide_bore_mm":22.0,"cap_stem_diameter_mm":21.2,
 "radial_guide_clearance_mm":0.4,"nominal_cap_travel_mm":3.0,
 "rear_opening_mm":[62,50],"rear_cover_mm":[80,64,5.4],
 "dev_board_mm":[52,28],"dev_board_hole_centres_mm":[47,23],
 "dev_board_hole_diameter_mm":3,"button_board_mm":[30,20],
 "hardware_height_and_button_travel_verified":False}

def box(x,y,z,c,h):
    qx=np.abs(x-c[0])-h[0]; qy=np.abs(y-c[1])-h[1]; qz=np.abs(z-c[2])-h[2]
    return np.sqrt(np.maximum(qx,0)**2+np.maximum(qy,0)**2+np.maximum(qz,0)**2)+np.minimum(np.maximum(np.maximum(qx,qy),qz),0)

def rbox(x,y,z,c,h,r):
    return box(x,y,z,c,[h[0]-r,h[1]-r,h[2]-r])-r

def roundrect(a,b,ha,hb,r):
    qa=np.abs(a)-(ha-r); qb=np.abs(b)-(hb-r)
    return np.sqrt(np.maximum(qa,0)**2+np.maximum(qb,0)**2)+np.minimum(np.maximum(qa,qb),0)-r

def slabshape(a,b,s,ha,hb,r,s0,s1):
    return np.maximum(roundrect(a,b,ha,hb,r),np.maximum(s0-s,s-s1))

def ell(x,y,z,c,r):
    # Exact zero-set; adequate signed field for CSG and interpolation.
    return (np.sqrt(((x-c[0])/r[0])**2+((y-c[1])/r[1])**2+((z-c[2])/r[2])**2)-1)*min(r)

def cyl(x,y,z,r,z0,z1):
    return np.maximum(np.sqrt(x*x+y*y)-r,np.maximum(z0-z,z-z1))

def body(x,y,z):
    outer=rbox(x,y,z,(0,0,38),(44,31,38),18)
    # Rounded, attached eyes, arms and flat-bottom feet.
    for sx in (-1,1):
        outer=np.minimum(outer,ell(x,y,z,(sx*16,-28,57),(13,9,13)))
        outer=np.minimum(outer,ell(x,y,z,(sx*43,-10,30),(12,10,13)))
        outer=np.minimum(outer,ell(x,y,z,(sx*23,-25,5),(15,14,8)))
    # A truly flat rear mounting land, attached to the main shell.
    outer=np.minimum(outer,slabshape(x,z-35,y,40,32,9,25,33))
    outer=np.maximum(outer,-z)
    cavity=rbox(x,y,z,(0,0,38),(41,28,35),15)
    shell=np.maximum(outer,-cavity)
    # Thick roof guide sleeve and collar; keep clear of the PCB volume.
    shell=np.minimum(shell,cyl(x,y,z,15,65,77))
    shell=np.minimum(shell,cyl(x,y,z,24,73,77))
    port=cyl(x,y,z,11,61,81)
    # Two slots allow the cap lugs to enter; rotate cap 90 degrees to retain.
    for sx in (-1,1):
        port=np.minimum(port,box(x,y,z,(sx*11.7,0,71),(1.2,2.6,11)))
    shell=np.maximum(shell,-port)
    # Large actual rear access to the hollow cavity.
    access=slabshape(x,z-35,y,31,25,8,22,40)
    shell=np.maximum(shell,-access)
    for sx in (-1,1):
      for sz in (-1,1):
        bore=np.maximum(np.sqrt((x-sx*34)**2+(z-(35+sz*27))**2)-1.7,np.maximum(20-y,y-38))
        shell=np.maximum(shell,-bore)
    # Shallow eye sockets and a shallow smile, all integral geometry.
    for sx in (-1,1):
        pupil=ell(x,y,z,(sx*16,-36.2,58),(5.0,1.4,6.8))
        shell=np.maximum(shell,-pupil)
    smile=np.full(np.broadcast_shapes(x.shape,y.shape,z.shape),1e6)
    for a in np.linspace(np.pi*1.12,np.pi*1.88,19):
        cx=7*np.cos(a); cz=42+4.2*np.sin(a)
        smile=np.minimum(smile,ell(x,y,z,(cx,-30.7,cz),(1.0,1.2,1.0)))
    return np.maximum(shell,-smile)

def cap(x,y,z):
    # Printed upside down: wide flat head on bed, stem grows vertically.
    head=cyl(x,y,z,21.5,0,5)
    tube=np.maximum(cyl(x,y,z,10.6,4.8,22),-cyl(x,y,z,7.3,5,23))
    post=cyl(x,y,z,3.5,4.8,22)
    f=np.minimum(np.minimum(head,tube),post)
    for sx in (-1,1):
        lug=box(x,y,z,(sx*10.9,0,21),(1.5,2.1,1))
        f=np.minimum(f,lug)
    return f

def cover(x,y,z):
    plate=slabshape(x,y,z,40,32,9,0,2.4)
    lip=np.maximum(slabshape(x,y,z,30.6,24.6,7.6,2.2,5.4),-slabshape(x,y,z,28.0,22.0,6.0,2.0,6.0))
    f=np.minimum(plate,lip)
    for sx in (-1,1):
      for sy in (-1,1):
        f=np.maximum(f,-cyl(x-sx*34,y-sy*27,z,1.7,-1,7))
    # Open edge cable notch, independent of a specific USB connector position.
    f=np.maximum(f,-box(x,y,z,(0,-30,3),(6,7,5)))
    return f

def guide_sample(x,y,z):
    f=cyl(x,y,z,15,0,12)
    f=np.maximum(f,-cyl(x,y,z,11,-1,13))
    # Wide base collar on bed; sleeve geometry matches body guide.
    f=np.minimum(f,np.maximum(cyl(x,y,z,19,0,2),-cyl(x,y,z,11,-1,3)))
    for sx in (-1,1):
        f=np.maximum(f,-box(x,y,z,(sx*11.7,0,6),(1.2,2.6,8)))
    return f

def tray(x,y,z):
    f=slabshape(x,y,z,30,18,2,0,2.4)
    # 47 x 23 mm centre spacings from supplied board drawing only.
    for sx in (-1,1):
      for sy in (-1,1):
        f=np.maximum(f,-cyl(x-sx*23.5,y-sy*11.5,z,1.7,-1,4))
    # Two tie slots; plate is not anchored to the enclosure in V1.
    for sx in (-1,1):
        f=np.maximum(f,-box(x,y,z,(sx*27.5,0,1.2),(0.9,8,3)))
    return f

CORN=np.array([[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]],dtype=np.int32)
TETS=[[0,5,1,6],[0,1,2,6],[0,2,3,6],[0,3,7,6],[0,7,4,6],[0,4,5,6]]

def mesh(field,bounds,step=STEP):
    axes=[np.arange(lo-0.173,hi+step,step) for lo,hi in bounds]
    xx,yy,zz=np.meshgrid(*axes,indexing='ij')
    vals=field(xx,yy,zz).astype(np.float64)
    del xx,yy,zz
    cv=np.stack([vals[c[0]:len(axes[0])-1+c[0],c[1]:len(axes[1])-1+c[1],c[2]:len(axes[2])-1+c[2]] for c in CORN],axis=-1)
    active=np.any(cv<0,axis=-1)&np.any(cv>=0,axis=-1)
    inds=np.argwhere(active); cubev=cv[active]
    base=np.stack([axes[i][inds[:,i]] for i in range(3)],axis=-1)
    allp=base[:,None,:]+CORN[None,:,:]*step
    pieces=[]
    for tet in TETS:
      p=allp[:,tet,:]; v=cubev[:,tet]
      cases=np.sum((v<0)*(1<<np.arange(4)),axis=1)
      for case in range(1,15):
        sel=cases==case
        if not np.any(sel): continue
        pp=p[sel]; vv=v[sel]
        ins=[i for i in range(4) if case&(1<<i)]; outs=[i for i in range(4) if not case&(1<<i)]
        def edge(i,j):
            t=vv[:,i]/(vv[:,i]-vv[:,j])
            return pp[:,i]+t[:,None]*(pp[:,j]-pp[:,i])
        if len(ins)==1:
            tri=np.stack([edge(ins[0],j) for j in outs],axis=1)[:,None,:,:]
        elif len(ins)==3:
            tri=np.stack([edge(outs[0],j) for j in ins],axis=1)[:,None,:,:]
        else:
            a,b=ins; c,d=outs
            q=[edge(a,c),edge(a,d),edge(b,d),edge(b,c)]
            tri=np.stack([np.stack([q[0],q[1],q[2]],axis=1),np.stack([q[0],q[2],q[3]],axis=1)],axis=1)
        direction=pp[:,outs].mean(axis=1)-pp[:,ins].mean(axis=1)
        norms=np.cross(tri[:,:,1]-tri[:,:,0],tri[:,:,2]-tri[:,:,0])
        flip=np.sum(norms*direction[:,None,:],axis=-1)<0
        tmp=tri[:,:,1,:].copy()
        tri[:,:,1,:]=np.where(flip[:,:,None],tri[:,:,2,:],tri[:,:,1,:])
        tri[:,:,2,:]=np.where(flip[:,:,None],tmp,tri[:,:,2,:])
        pieces.append(tri.reshape(-1,3,3))
    tris=np.round(np.concatenate(pieces),5)
    # Quantise vertices once, making all shared STL edge coordinates identical.
    verts,inv=np.unique(tris.reshape(-1,3),axis=0,return_inverse=True)
    faces=inv.reshape(-1,3)
    keep=(faces[:,0]!=faces[:,1])&(faces[:,1]!=faces[:,2])&(faces[:,2]!=faces[:,0])
    faces=faces[keep]
    verts[:,2]-=verts[:,2].min()
    return verts,faces

def validate(v,f):
    e=np.sort(np.concatenate([f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]]),axis=1)
    ue,counts=np.unique(e,axis=0,return_counts=True)
    signed=np.sum(np.einsum('ij,ij->i',v[f[:,0]],np.cross(v[f[:,1]],v[f[:,2]])))/6
    if signed<0:
        f[:]=f[:,[0,2,1]]; signed=-signed
    # Count connected surface components, distinguishing a closed cap's two
    # locally separate stem cross-sections from a genuinely loose shell.
    parent=np.arange(len(v))
    def find(a):
      while parent[a]!=a:
        parent[a]=parent[parent[a]]; a=parent[a]
      return a
    for a,b in ue:
      ra=find(a); rb=find(b)
      if ra!=rb: parent[rb]=ra
    comps=len({find(int(a)) for a in np.unique(f)})
    return {"vertices":len(v),"triangles":len(f),"boundary_edges":int(np.sum(counts==1)),"nonmanifold_edges":int(np.sum(counts>2)),"surface_components":comps,"signed_volume_mm3":round(float(signed),2),"bounds_mm":np.round([v.min(axis=0),v.max(axis=0)],3).tolist(),"size_mm":np.round(np.ptp(v,axis=0),3).tolist()}

def stl(path,v,f):
    t=v[f].astype('<f4'); n=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]); lengths=np.linalg.norm(n,axis=1); n/=np.maximum(lengths[:,None],1e-12)
    data=np.zeros(len(f),dtype=np.dtype([('n','<f4',(3,)),('v','<f4',(3,3)),('attr','<u2')]))
    data['n']=n; data['v']=t
    with open(path,'wb') as file: file.write(b'Help button prototype v1; mm; hardware fit unverified'.ljust(80,b' ')); file.write(struct.pack('<I',len(f))); file.write(data.tobytes())

def three_mf(parts):
    ns='http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
    lines=[f'<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xml:lang="en-US" xmlns="{ns}"><metadata name="Title">Help button printable shell prototype V1</metadata><resources>']
    colors=['#FFF1CF','#6B9E74','#FFF1CF','#D6D6D6','#D6D6D6']
    lines.append('<basematerials id="100">'+''.join(f'<base name="part-{i+1}" displaycolor="{c}"/>' for i,c in enumerate(colors))+'</basematerials>')
    transforms=[]
    # Flat on the plate, all within 256 x 256 mm. Body uses its natural flat base.
    placements=[(65,63),(168,40),(174,106),(59,151),(161,180)]
    for i,(name,v,f) in enumerate(parts):
        lines.append(f'<object id="{i+1}" type="model" name="{name}" pid="100" pindex="{i}"><mesh><vertices>')
        lines.extend('<vertex x="%.5f" y="%.5f" z="%.5f"/>'%tuple(a) for a in v)
        lines.append('</vertices><triangles>')
        lines.extend('<triangle v1="%d" v2="%d" v3="%d"/>'%tuple(a) for a in f)
        lines.append('</triangles></mesh></object>')
        px,py=placements[i]; transforms.append(f'<item objectid="{i+1}" transform="1 0 0 0 1 0 0 0 1 {px} {py} 0"/>')
    lines.append('</resources><build>'+''.join(transforms)+'</build></model>')
    content='''<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>'''
    rels='''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>'''
    with zipfile.ZipFile(OUT/'help-button-prototype-v1.3mf','w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml',content); z.writestr('_rels/.rels',rels); z.writestr('3D/3dmodel.model',''.join(lines))

if __name__=='__main__':
    report={"parameters":PARAMS,"parts":{},"note":"All STL parts placed with minimum z = 0. No electronics fit or button travel calibration has been performed."}
    parts=[]
    specs=[('body',body,[(-58,58),(-41,35),(-2,79)]),('top-button',cap,[(-24,24),(-24,24),(-2,24)]),('rear-cover',cover,[(-42,42),(-34,34),(-2,8)]),('guide-test',guide_sample,[(-21,21),(-21,21),(-2,14)]),('pcb-tray',tray,[(-32,32),(-20,20),(-2,5)])]
    for name,field,bounds in specs:
        started=time.time(); v,f=mesh(field,bounds); stats=validate(v,f)
        if stats['boundary_edges'] or stats['nonmanifold_edges']: raise RuntimeError((name,stats))
        stl(OUT/(name+'.stl'),v,f); parts.append((name,v,f)); report['parts'][name]=stats
        print(name,json.dumps(stats),f'{time.time()-started:.1f}s',flush=True)
    three_mf(parts)
    (OUT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print('3MF and validation.json written',flush=True)
