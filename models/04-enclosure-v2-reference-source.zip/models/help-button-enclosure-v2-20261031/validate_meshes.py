#!/usr/bin/env python3
"""Read-only binary-STL topology checks for the help-button prototype.

Usage (all dimensions are millimetres):
  python3 validate_meshes.py
  python3 validate_meshes.py body.stl --tolerance-mm 0.00001

The JSON report goes to stdout. Exit status is 0 only when every requested
file passes; no STL, generator, or report file is created or modified.
This checks mesh topology, not self-intersections, wall thickness, printable
overhangs, assembly clearances, electronics fit, or working button travel.
"""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
import struct
import sys

import numpy as np


STL_FACET = np.dtype([
    ("normal", "<f4", (3,)),
    ("vertices", "<f4", (3, 3)),
    ("attribute", "<u2"),
])
DEFAULT_PARTS = ("body.stl", "top-button.stl", "rear-cover.stl")


class UnionFind:
    def __init__(self, count: int):
        self.parent = np.arange(count, dtype=np.int64)
        self.rank = np.zeros(count, dtype=np.uint8)

    def find(self, item: int) -> int:
        parent = self.parent
        item = int(item)
        while parent[item] != item:
            parent[item] = parent[parent[item]]
            item = int(parent[item])
        return item

    def union(self, a: int, b: int) -> None:
        a, b = self.find(a), self.find(b)
        if a == b:
            return
        if self.rank[a] < self.rank[b]:
            a, b = b, a
        self.parent[b] = a
        if self.rank[a] == self.rank[b]:
            self.rank[a] += 1


def read_binary_stl(path: Path) -> tuple[np.ndarray, np.ndarray, dict]:
    """Reject truncation and trailing bytes rather than silently dropping data."""
    data = path.read_bytes()
    if len(data) < 84:
        raise ValueError("Binary STL is shorter than its 84-byte header.")
    count = struct.unpack_from("<I", data, 80)[0]
    expected = 84 + 50 * count
    if len(data) != expected:
        raise ValueError(
            f"Binary STL size mismatch: header says {count} facets / "
            f"{expected} bytes, actual {len(data)} bytes."
        )
    if not count:
        raise ValueError("Binary STL contains no facets.")
    facets = np.frombuffer(data, dtype=STL_FACET, offset=84, count=count)
    triangles = facets["vertices"].astype(np.float64)
    normals = facets["normal"].astype(np.float64)
    if not np.isfinite(triangles).all():
        raise ValueError("Vertex coordinates contain NaN or infinity.")
    if not np.isfinite(normals).all():
        raise ValueError("Stored facet normals contain NaN or infinity.")
    return triangles, normals, {"file_bytes": len(data), "declared_facets": count}


def topology(vertices: np.ndarray, faces: np.ndarray, tolerance: float) -> dict:
    """Check winding and components using shared edges, not vertex touches."""
    triangles = vertices[faces]
    cross = np.cross(triangles[:, 1] - triangles[:, 0],
                     triangles[:, 2] - triangles[:, 0])
    double_area = np.linalg.norm(cross, axis=1)
    repeated = ((faces[:, 0] == faces[:, 1]) |
                (faces[:, 1] == faces[:, 2]) |
                (faces[:, 2] == faces[:, 0]))
    # Tiny but nonzero float32 triangles are warnings, not false degeneracies.
    degenerate = repeated | (double_area <= 1e-12)
    near_degenerate = (~degenerate) & (double_area <= tolerance ** 2)
    _, duplicate_counts = np.unique(np.sort(faces, axis=1), axis=0,
                                    return_counts=True)

    directed = np.stack((faces[:, [0, 1]], faces[:, [1, 2]],
                         faces[:, [2, 0]]), axis=1).reshape(-1, 2)
    undirected = np.sort(directed, axis=1)
    _, first, inverse, counts = np.unique(
        undirected, axis=0, return_index=True, return_inverse=True,
        return_counts=True,
    )
    edge_sign = np.where(directed[:, 0] < directed[:, 1], 1, -1)
    sign_sum = np.bincount(inverse, weights=edge_sign, minlength=len(counts))
    bad_orientation = (counts == 2) & (sign_sum != 0)

    owner = np.repeat(np.arange(len(faces), dtype=np.int64), 3)
    first_owner = owner[first]
    connectivity = UnionFind(len(faces))
    for a, b in zip(owner, first_owner[inverse]):
        if a != b:
            connectivity.union(a, b)
    roots = np.fromiter((connectivity.find(i) for i in range(len(faces))),
                        dtype=np.int64, count=len(faces))
    _, component, component_counts = np.unique(
        roots, return_inverse=True, return_counts=True,
    )
    # Translating the integration origin reduces cancellation for offset parts.
    origin = (vertices.min(axis=0) + vertices.max(axis=0)) / 2
    shifted = triangles - origin
    tetra_volume = np.einsum(
        "ij,ij->i", shifted[:, 0],
        np.cross(shifted[:, 1], shifted[:, 2]),
    ) / 6
    volumes = np.bincount(component, weights=tetra_volume)
    return {
        "vertices": int(len(vertices)),
        "facets": int(len(faces)),
        "edges": int(len(counts)),
        "closed_two_face_edges": int(np.count_nonzero(counts == 2)),
        "boundary_edges": int(np.count_nonzero(counts == 1)),
        "nonmanifold_edges": int(np.count_nonzero(counts > 2)),
        "degenerate_facets": int(np.count_nonzero(degenerate)),
        "near_degenerate_facets_warning": int(np.count_nonzero(near_degenerate)),
        "duplicate_facets": int(np.sum(duplicate_counts - 1)),
        "inconsistent_winding_edges": int(np.count_nonzero(bad_orientation)),
        "edge_connected_components": int(len(component_counts)),
        "components": [
            {"facets": int(n), "signed_volume_mm3": float(volume)}
            for n, volume in zip(component_counts, volumes)
        ],
        "signed_volume_mm3": float(tetra_volume.sum()),
        "surface_area_mm2": float(double_area.sum() / 2),
    }


def tolerance_weld(vertices: np.ndarray, faces: np.ndarray,
                   tolerance: float) -> tuple[np.ndarray, np.ndarray, int]:
    """Spatial-hash weld only numerically coincident vertices, in memory.

    Search neighbouring cells so points straddling a rounding boundary still
    match. Each cluster is bounded by its first representative, avoiding an
    unbounded chain of merges. The source STL is never changed.
    """
    buckets: dict[tuple[int, int, int], list[int]] = {}
    representatives: list[np.ndarray] = []
    mapping = np.empty(len(vertices), dtype=np.int64)
    offsets = tuple(itertools.product((-1, 0, 1), repeat=3))
    tolerance_squared = tolerance * tolerance
    for index, point in enumerate(vertices):
        cell = tuple(int(n) for n in np.floor(point / tolerance))
        match = None
        for offset in offsets:
            key = tuple(cell[axis] + offset[axis] for axis in range(3))
            for candidate in buckets.get(key, ()):
                delta = point - representatives[candidate]
                if float(np.dot(delta, delta)) <= tolerance_squared:
                    match = candidate
                    break
            if match is not None:
                break
        if match is None:
            match = len(representatives)
            representatives.append(point)
            buckets.setdefault(cell, []).append(match)
        mapping[index] = match
    return (np.asarray(representatives), mapping[faces],
            int(len(vertices) - len(representatives)))


def inspect_mesh(triangles: np.ndarray, normals: np.ndarray,
                 tolerance_mm: float | None = None) -> dict:
    vertices, inverse = np.unique(triangles.reshape(-1, 3), axis=0,
                                  return_inverse=True)
    faces = inverse.reshape(-1, 3)
    lower, upper = vertices.min(axis=0), vertices.max(axis=0)
    size = upper - lower
    scale = max(float(np.abs(vertices).max()), float(size.max()), 1.0)
    # Two float32 ULPs at model scale, with a one-nanometre lower bound.
    tolerance = (max(1e-6, 2 * float(np.spacing(np.float32(scale))))
                 if tolerance_mm is None else tolerance_mm)
    raw = topology(vertices, faces, tolerance)
    selected = raw
    report = {
        "bbox_min_mm": lower.tolist(),
        "bbox_max_mm": upper.tolist(),
        "size_mm": size.tolist(),
        "coordinate_tolerance_mm": tolerance,
        "z_nonnegative_within_tolerance": bool(lower[2] >= -tolerance),
        "raw_exact_coordinate_topology": raw,
        "topology_basis": "exact float32 coordinates",
        "tolerance_merged_vertices": 0,
    }
    # Exact closed meshes are assessed without any tolerance merge: nearby
    # real features and valid sliver triangles must not be collapsed.
    if raw["boundary_edges"]:
        welded_v, welded_f, merged = tolerance_weld(vertices, faces, tolerance)
        report["tolerance_merged_vertices"] = merged
        if merged:
            tolerant = topology(welded_v, welded_f, tolerance)
            report["tolerant_coordinate_topology"] = tolerant
            old_errors = raw["boundary_edges"] + raw["nonmanifold_edges"]
            new_errors = (tolerant["boundary_edges"] +
                          tolerant["nonmanifold_edges"])
            if (new_errors < old_errors and
                    tolerant["degenerate_facets"] <= raw["degenerate_facets"] and
                    tolerant["duplicate_facets"] <= raw["duplicate_facets"]):
                selected = tolerant
                report["topology_basis"] = "float32-tolerance weld (analysis only)"

    cross = np.cross(triangles[:, 1] - triangles[:, 0],
                     triangles[:, 2] - triangles[:, 0])
    norm_lengths = np.linalg.norm(normals, axis=1)
    dot = np.einsum("ij,ij->i", cross, normals)
    report["stored_normal_zero_facets_warning"] = int(np.count_nonzero(norm_lengths == 0))
    report["stored_normal_opposes_winding_facets"] = int(np.count_nonzero(dot < 0))
    report["checked_topology"] = selected
    checks = {
        "closed_no_boundary_edges": selected["boundary_edges"] == 0,
        "no_nonmanifold_edges": selected["nonmanifold_edges"] == 0,
        "no_degenerate_facets": selected["degenerate_facets"] == 0,
        "no_duplicate_facets": selected["duplicate_facets"] == 0,
        "consistent_edge_winding": selected["inconsistent_winding_edges"] == 0,
        "stored_normals_do_not_oppose_winding": bool(np.all(dot >= 0)),
        "single_edge_connected_component": selected["edge_connected_components"] == 1,
        "positive_signed_volume": selected["signed_volume_mm3"] > 1e-9,
        "positive_bbox_dimensions": bool(np.all(size > tolerance)),
        "z_nonnegative": report["z_nonnegative_within_tolerance"],
    }
    report["checks"] = checks
    report["passed"] = all(checks.values())
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("paths", nargs="*", type=Path,
                        help="Binary STL files; defaults to the three shell parts.")
    parser.add_argument("--tolerance-mm", type=float, default=None,
                        help="Coincident-coordinate tolerance; default: two float32 ULPs.")
    args = parser.parse_args()
    if args.tolerance_mm is not None and (
            not np.isfinite(args.tolerance_mm) or args.tolerance_mm <= 0):
        parser.error("--tolerance-mm must be finite and greater than zero")
    paths = args.paths or [Path(__file__).resolve().parent / name
                           for name in DEFAULT_PARTS]
    parts = []
    for path in paths:
        entry = {"path": str(path.resolve())}
        try:
            triangles, normals, metadata = read_binary_stl(path)
            entry.update(metadata)
            entry.update(inspect_mesh(triangles, normals, args.tolerance_mm))
        except (OSError, ValueError, struct.error) as error:
            entry.update({"passed": False, "error": str(error)})
        parts.append(entry)
    report = {
        "passed": all(part["passed"] for part in parts),
        "units_assumed": "mm (STL does not encode units)",
        "scope": (
            "Binary-format, finite-coordinate, edge-topology, winding, component, "
            "volume and build-plane checks. Does not verify self-intersections, "
            "wall thickness, overhangs, hardware fit or mechanism function."
        ),
        "parts": parts,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
