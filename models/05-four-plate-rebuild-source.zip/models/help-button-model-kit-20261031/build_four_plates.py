from pathlib import Path
import re,zipfile,json,uuid,hashlib
import xml.etree.ElementTree as E
from xml.sax.saxutils import escape

OUT=Path(__file__).resolve().parent
BASE=OUT.parent
inputs=[BASE/'help-button-component-holders-20261031/plate-1-esp32.3mf',
        BASE/'help-button-component-holders-20261031/plate-2-button.3mf',
        BASE/'help-button-enclosure-v2-20261031/help-button-enclosure-v2-two-parts.3mf',
        BASE/'help-button-mouth-20261031/黑色笑嘴.3mf']
names=['01 ESP32托座与螺丝','02 按钮板托座与螺丝','03 V2主壳与匹配后盖','04 黑色笑嘴']
ns='http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
pns='http://schemas.microsoft.com/3dmanufacturing/production/2015/06'
header=f'<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xml:lang="en-US" xmlns="{ns}" xmlns:BambuStudio="http://schemas.bambulab.com/package/2021" xmlns:p="{pns}" requiredextensions="p">'
main=[header,'<metadata name="Application">BambuStudio-02.08.02.61</metadata><metadata name="BambuStudio:3mfVersion">1</metadata><metadata name="Title">DengNiLai four separate plates</metadata><resources>']
configs=['<?xml version="1.0" encoding="UTF-8"?><config>']
build=[];rels=[];meshes={};plates=[];records=[]
idx=0
for plate,src in enumerate(inputs):
    with zipfile.ZipFile(src) as z: data=z.read('3D/3dmodel.model').decode()
    blocks={}
    for m in re.finditer(r'<object\b([^>]*)>(.*?)</object>',data,re.S):
        attrs=dict(re.findall(r'(\w+)="([^"]*)"',m.group(1)))
        mesh=re.search(r'<mesh>.*?</mesh>',m.group(2),re.S).group()
        blocks[attrs['id']]=(attrs.get('name','part'),mesh)
    items=re.findall(r'<item\b([^>]*)/?>',data)
    membership=[]
    origin=[(plate%2)*307.2,-(plate//2)*307.2,0]
    for item in items:
        a=dict(re.findall(r'(\w+)="([^"]*)"',item));name,mesh=blocks[a['objectid']]
        t=list(map(float,a.get('transform','1 0 0 0 1 0 0 0 1 0 0 0').split()))
        local=t[9:12].copy();t[9]+=origin[0];t[10]+=origin[1]
        idx+=1;oid=idx*2;partid=idx*2-1;path=f'3D/Objects/object_{idx}.model'
        colour=2 if plate==3 else 1
        main.append(f'<object id="{oid}" type="model" p:UUID="{uuid.uuid4()}"><components><component p:path="/{path}" objectid="{partid}" p:UUID="{uuid.uuid4()}" transform="1 0 0 0 1 0 0 0 1 0 0 0"/></components></object>')
        meshes[path]=header.replace(' requiredextensions="p"','')+f'<resources><object id="{partid}" type="model">{mesh}</object></resources></model>'
        build.append(f'<item objectid="{oid}" p:UUID="{uuid.uuid4()}" transform="'+ ' '.join(f'{q:g}' for q in t)+'" printable="1"/>')
        rels.append(f'<Relationship Target="/{path}" Id="rel{idx}" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>')
        count=mesh.count('<triangle ')
        configs.append(f'<object id="{oid}"><metadata key="name" value="{escape(name)}"/><metadata key="extruder" value="{colour}"/><metadata face_count="{count}"/>')
        if 'screw' in name or 'clamp' in name:
            configs.append('<metadata key="sparse_infill_density" value="100%"/>')
        configs.append(f'<part id="{partid}" subtype="normal_part" uuid="{uuid.uuid4()}"><metadata key="name" value="{escape(name)}"/><metadata key="matrix" value="1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1"/><metadata key="source_file" value="{src.name}"/><mesh_stat face_count="{count}" edges_fixed="0" degenerate_facets="0" facets_removed="0" facets_reversed="0" backwards_edges="0"/></part></object>')
        membership.append(oid)
        records.append({'object_id':oid,'part_id':partid,'asset_path':path,'mesh_sha256':hashlib.sha256(mesh.encode()).hexdigest(),'name':name,'plate':plate+1,'extruder':colour,'local_translation':local,'global_translation':t[9:12],'triangles':count})
    plates.append((names[plate],membership))
for number,(name,membership) in enumerate(plates,1):
    configs.append(f'<plate><metadata key="plater_id" value="{number}"/><metadata key="plater_name" value="{name}"/><metadata key="locked" value="false"/><metadata key="filament_map_mode" value="Auto For Flush"/>')
    for oid in membership:
        configs.append(f'<model_instance><metadata key="object_id" value="{oid}"/><metadata key="instance_id" value="0"/><metadata key="identify_id" value="{oid}"/></model_instance>')
    configs.append('</plate>')
configs.append('</config>');main.extend(['</resources><build p:UUID="'+str(uuid.uuid4())+'">',*build,'</build></model>'])
# Only one explicitly named printer family. No start/end/change G-code copied.
settings={'printer_settings_id':'Bambu Lab P2S 0.4 nozzle','printer_model':'Bambu Lab P2S','printer_variant':'0.4','nozzle_diameter':['0.4'],'printable_area':['0x0','256x0','256x256','0x256'],'printable_height':'256','print_settings_id':'0.16mm Optimal @BBL P2S','layer_height':'0.16','initial_layer_print_height':'0.2','wall_loops':'4','sparse_infill_density':'25%','enable_support':'0','curr_bed_type':'Textured PEI Plate','filament_settings_id':['Bambu PLA Basic @BBL P2S','Bambu PLA Basic @BBL P2S'],'filament_colour':['#F4E4C9','#111111'],'filament_type':['PLA','PLA'],'filament_diameter':['1.75','1.75'],'filament_vendor':['Bambu Lab','Bambu Lab']}
target=OUT/'等你来-四盘完整模型-修正版.3mf'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('[Content_Types].xml','<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
    z.writestr('_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
    z.writestr('3D/3dmodel.model',''.join(main));z.writestr('3D/_rels/3dmodel.model.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(rels)+'</Relationships>')
    for path,mesh in meshes.items():z.writestr(path,mesh)
    z.writestr('Metadata/model_settings.config',''.join(configs));z.writestr('Metadata/project_settings.config',json.dumps(settings,ensure_ascii=False,indent=2))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    config=E.fromstring(z.read('Metadata/model_settings.config'))
    assert len(config.findall('plate'))==4
    assert [len(x.findall('model_instance')) for x in config.findall('plate')]==[5,5,2,1]
    assert len(records)==13 and not any('gcode' in n.lower() for n in z.namelist())
    # Bambu's native format requires globally unique mesh/part IDs across assets.
    assert len({r['part_id'] for r in records})==13
    assert len({r['object_id'] for r in records}|{r['part_id'] for r in records})==26
    for r in records:
        child=E.fromstring(z.read(r['asset_path']))
        node=child.find('{'+ns+'}resources/{'+ns+'}object')
        assert int(node.attrib['id'])==r['part_id']
        part=config.find(f"object[@id='{r['object_id']}']/part")
        assert int(part.attrib['id'])==r['part_id']
report={'path':str(target),'plate_count':4,'object_count':13,'objects_per_plate':[5,5,2,1],'plate_origin_rule':'2x2, 1.2 x 256mm stride, positive X / negative Y','machine':'P2S 0.4 reference only','gcode_included':False,'gui_import_verified':False,'objects':records,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'sources':[str(p) for p in inputs]}
(OUT/'four-plates-corrected-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'path':str(target),'bytes':target.stat().st_size,'plates':4,'objects':13,'gcode':False},ensure_ascii=False))
