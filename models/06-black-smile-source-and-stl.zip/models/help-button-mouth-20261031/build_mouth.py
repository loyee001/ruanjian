#!/usr/bin/env python3
"""One glue-in black smile for the existing help-button mouth recess; mm.

All previews are drawn from the exported triangle meshes, not generated images.
This script does not alter an original part or talk to a slicer/printer.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import zipfile

import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'help-button-print-reference-20261030/printable-prototype-v1'


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


body_generator = load_module('mouth_reference_body', BASE / 'build_prototype.py')
preview_tools = load_module('mouth_mesh_preview', BASE / 'black-pupils-20261031/build_pupils.py')
independent_validator = load_module('mouth_stl_validator', BASE / 'validate_meshes.py')

ANGLES = np.linspace(np.pi * 1.12, np.pi * 1.88, 19)
CENTRES = np.column_stack((7 * np.cos(ANGLES), 42 + 4.2 * np.sin(ANGLES) - 39))
STEP = 0.10
PARAMS = {
    'quantity': 1,
    'material_reference': 'black PLA',
    'source_curve': '19 original points: x=7*cos(a), body_z=42+4.2*sin(a); a in [1.12*pi,1.88*pi]',
    'source_groove_ellipsoid_radii_mm': [1.0, 1.2, 1.0],
    'source_groove_body_y_mm': -30.7,
    'visible_plate_radius_mm': 0.85,
    'visible_plate_print_z_mm': [0.0, 0.7],
    'locating_ridge_radius_mm': 0.45,
    'locating_ridge_print_z_mm': [0.6, 1.25],
    'rounded_ridge_tip_radii_mm': [0.45, 0.45, 0.30],
    'overall_nominal_mm': [14.7168708, 4.3538750, 1.55],
    'mesh_step_mm': STEP,
    'assembly_transform': 'body_x=print_x; body_y=print_z-31.9; body_z=print_y+39',
    'plate_back_body_y_mm': -31.2,
    'nominal_flat_white_face_body_y_mm': -31.0,
    'plate_back_to_nominal_white_face_gap_mm': 0.2,
    'print_orientation': 'broad flat visible face on plate at Z=0; narrower locating ridge upwards',
    'fixing': 'small amount of adhesive suitable for PLA; not a snap fit',
    'physical_fit_verified': False,
}


def mouth_field(x, y, z):
    shape = np.full(np.broadcast_shapes(x.shape, y.shape, z.shape), 1e6)
    for cx, cy in CENTRES:
        radial = np.sqrt((x - cx) ** 2 + (y - cy) ** 2)
        plate = np.maximum(radial - 0.85, np.maximum(-z, z - 0.7))
        ridge = np.maximum(radial - 0.45, np.maximum(0.6 - z, z - 1.25))
        tip = body_generator.ell(x, y, z, (cx, cy, 1.25), (0.45, 0.45, 0.30))
        shape = np.minimum(shape, np.minimum(plate, np.minimum(ridge, tip)))
    return shape


def assembled(points):
    return np.column_stack((points[:, 0], points[:, 2] - 31.9, points[:, 1] + 39))


def three_mf(vertices, faces):
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02">',
        '<metadata name="Title">Black smile insert; one piece; flat face down</metadata>',
        '<resources><basematerials id="100"><base name="Black PLA reference" displaycolor="#111111"/></basematerials>',
        '<object id="1" type="model" name="mouth-black" pid="100" pindex="0"><mesh><vertices>',
    ]
    lines.extend('<vertex x="%.6f" y="%.6f" z="%.6f"/>' % tuple(point) for point in vertices)
    lines.append('</vertices><triangles>')
    lines.extend('<triangle v1="%d" v2="%d" v3="%d"/>' % tuple(face) for face in faces)
    lines.append('</triangles></mesh></object></resources><build><item objectid="1" transform="1 0 0 0 1 0 0 0 1 128 128 0"/></build></model>')
    content = '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>'
    relationships = '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>'
    with zipfile.ZipFile(HERE / '黑色笑嘴.3mf', 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('[Content_Types].xml', content)
        archive.writestr('_rels/.rels', relationships)
        archive.writestr('3D/3dmodel.model', ''.join(lines))


def collision_samples(vertices, faces):
    # Vertices, face centres and all edge midpoints: real exported surface.
    surface = np.vstack((vertices, vertices[faces].mean(axis=1),
                         (vertices[faces[:, 0]] + vertices[faces[:, 1]]) / 2,
                         (vertices[faces[:, 1]] + vertices[faces[:, 2]]) / 2,
                         (vertices[faces[:, 2]] + vertices[faces[:, 0]]) / 2))
    lower, upper = vertices.min(axis=0), vertices.max(axis=0)
    axes = [np.arange(lo, hi + 0.03, 0.06) for lo, hi in zip(lower, upper)]
    xx, yy, zz = np.meshgrid(*axes, indexing='ij')
    filled = mouth_field(xx, yy, zz) <= 0
    interior = np.column_stack((xx[filled], yy[filled], zz[filled]))
    reports = {}
    for name, samples in [('surface_vertices_faces_and_edges', surface), ('solid_grid_0.06mm', interior)]:
        world = assembled(samples)
        values = body_generator.body(world[:, 0], world[:, 1], world[:, 2])
        minimum = int(np.argmin(values))
        reports[name] = {
            'sample_count': int(len(samples)),
            'minimum_positive_source_body_field_mm': float(values[minimum]),
            'minimum_at_body_xyz_mm': world[minimum].tolist(),
            'intersecting_samples': int(np.count_nonzero(values <= 0)),
        }
        assert values.min() > 0, (name, reports[name])
    return reports


def previews(vertices, faces):
    image = Image.new('RGB', (1920, 1340), '#F5F3EE')
    draw = ImageDraw.Draw(image)
    font_path = '/System/Library/Fonts/STHeiti Medium.ttc'
    title = ImageFont.truetype(font_path, 50)
    heading = ImageFont.truetype(font_path, 31)
    small = ImageFont.truetype(font_path, 25)
    draw.text((60, 40), '黑色笑嘴 · 一件独立嵌件', fill='#23382C', font=title)
    draw.text((63, 112), '沿用现有微笑曲线，不改白色主壳与原脸', fill='#627064', font=small)
    draw.rounded_rectangle((40, 175, 1090, 1190), 30, fill='white')
    draw.rounded_rectangle((1120, 175, 1880, 680), 30, fill='white')
    draw.rounded_rectangle((1120, 710, 1880, 1190), 30, fill='white')

    body = preview_tools.read_stl(BASE / 'body.stl')
    cap = preview_tools.read_stl(BASE / 'top-button.stl').copy()
    cap[:, :, 1] *= -1
    cap[:, :, 2] = 82 - cap[:, :, 2]
    mouth = assembled(vertices)[faces[:, [0, 2, 1]]]
    objects = [(body, [246, 233, 207]), (cap, [109, 161, 116]), (mouth, [24, 26, 24])]
    for side, filename in [(-1, 'pupil-left.stl'), (1, 'pupil-right.stl')]:
        pupil = preview_tools.read_stl(BASE / 'black-pupils-20261031' / filename)
        eye = np.stack((pupil[:, :, 0] + side * 16, pupil[:, :, 2] - 38,
                        pupil[:, :, 1] + 58), axis=-1)[:, [0, 2, 1]]
        objects.append((eye, [31, 33, 31]))
    preview_tools.render(objects, image, (90, 225, 945, 835), (.08, -1, .20))
    draw.text((85, 1105), '实际 STL 装配预览：现有黑眼珠 + 新笑嘴', fill='#344639', font=heading)

    draw.text((1160, 205), '打印方向', fill='#23382C', font=heading)
    preview_tools.render([(vertices[faces], [41, 43, 41])], image,
                         (1180, 285, 640, 240), (.15, -1, 1.7))
    draw.text((1160, 555), '平面贴板，窄定位脊朝上', fill='#344639', font=heading)
    size = np.ptp(vertices, axis=0)
    draw.text((1160, 610), '约 %.2f × %.2f × %.2f mm' % tuple(size), fill='#627064', font=small)

    draw.text((1160, 740), '脸部局部：保持原有笑弧尺寸', fill='#23382C', font=heading)
    centre = body.mean(axis=1)
    local = body[(np.abs(centre[:, 0]) < 11) & (centre[:, 2] > 34) & (centre[:, 2] < 44) & (centre[:, 1] < -26)]
    preview_tools.render([(local, [246, 233, 207]), (mouth, [24, 26, 24])], image,
                         (1190, 815, 610, 235), (0, -1, .03))
    draw.text((1160, 1080), '黑色 PLA；少量适用胶固定', fill='#344639', font=heading)
    draw.text((1160, 1135), '定位脊不是卡扣，尺寸待实装确认', fill='#627064', font=small)
    draw.text((60, 1240), '本图由实际三角网格绘制；3MF 仅一件笑嘴，无 G-code，未发送打印。', fill='#627064', font=small)
    image.save(HERE / '黑色笑嘴-实际网格装配预览.png')


def main():
    HERE.mkdir(parents=True, exist_ok=True)
    originals = [BASE / name for name in ('build_prototype.py', 'body.stl', 'top-button.stl', 'rear-cover.stl')]
    originals += [BASE / 'black-pupils-20261031' / name for name in ('pupil-left.stl', 'pupil-right.stl')]
    hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in originals}
    vertices, faces = body_generator.mesh(mouth_field, [(-8.2, 8.2), (-2.8, 3.0), (-0.5, 1.9)], step=STEP)
    stats = body_generator.validate(vertices, faces)
    assert stats['boundary_edges'] == stats['nonmanifold_edges'] == 0
    assert stats['surface_components'] == 1 and stats['signed_volume_mm3'] > 0
    body_generator.stl(HERE / 'mouth-black.stl', vertices, faces)
    # Re-read the float32 STL rather than verifying only the source arrays.
    triangles, normals, binary_meta = independent_validator.read_binary_stl(HERE / 'mouth-black.stl')
    actual = independent_validator.inspect_mesh(triangles, normals)
    assert actual['passed'], actual
    exported_vertices, inverse = np.unique(triangles.reshape(-1, 3), axis=0, return_inverse=True)
    exported_faces = inverse.reshape(-1, 3)
    collision = collision_samples(exported_vertices, exported_faces)
    three_mf(exported_vertices, exported_faces)
    previews(exported_vertices, exported_faces)
    assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == value for path, value in hashes.items())
    report = {
        'parameters': PARAMS, 'source_mesh_topology': stats,
        'exported_binary_stl': dict(binary_meta, **actual),
        'sampled_assembly_clearance': collision,
        'fit_check_scope': 'Positive values at sampled exported surface and dense solid points against the original V1 analytic body field. Shared V1/V2 recess compatibility follows the unchanged source smile curve. This is not an exact mesh-intersection proof or physical fit test.',
        'three_mf': {'unit': 'millimeter', 'objects': 1, 'build_items': 1,
                     'material_reference': '#111111', 'bed_min_z_mm': 0.0,
                     'orientation': 'broad flat face down, locating ridge up', 'contains_gcode': False},
        'original_sha256_unchanged': hashes,
        'sliced': False, 'printer_command_sent': False, 'physical_fit_verified': False,
    }
    (HERE / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    (HERE / '说明.txt').write_text(
        '黑色笑嘴（1件）\n\n'
        '打开“黑色笑嘴.3mf”，按毫米导入，保持原方向：宽平面贴板、窄定位脊朝上。\n'
        '尺寸约14.72×4.35×1.55毫米，黑色PLA。沿用原来的19点微笑曲线，没有放大嘴、没有修改脸或主壳。\n'
        '建议0.12或0.16毫米层高、100%填充，无需支撑；这么小的件要先清洁打印板，必要时加少量与模型相连的外侧brim（防翘边）提高附着。\n'
        '取件时等板冷却，轻拿，避免弯折。定位脊仅用于对位，不是卡扣，不要硬压。\n'
        '先干放到原浅凹槽确认方向和位置，再用少量适合PLA的胶固定，清理多余胶。\n'
        '宽前板背面与白脸名义平面留0.2毫米间隙；定位脊伸入原槽。具体接触、胶量和实物间隙仍待打印后检查。\n'
        '已验证独立STL闭合、单连通、正体积、打印最低Z=0，并计算表面与密集内部采样点对原body场无相交。\n'
        '这不代表实装已通过；V1/V2仅适用于原微笑凹槽未改变的版本。\n'
        '3MF为1件模型与黑色参考色，不含特定打印机配置或G-code；尚未切片，没有操作打印机。\n'
        '装配预览直接绘制真实STL三角网格，不是AI效果图。原主壳、按钮、后盖和黑眼珠文件均未改动。\n')
    print(json.dumps({'output': str(HERE), 'size_mm': actual['size_mm'],
                      'facets': actual['checked_topology']['facets'],
                      'stl_passed': actual['passed'], 'clearance': collision}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
