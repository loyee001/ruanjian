#!/usr/bin/env python3
"""Two glue-in pupils for the existing V1 eye recesses; all units mm."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import zipfile
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
spec = importlib.util.spec_from_file_location('body_generator', BASE / 'build_prototype.py')
body_generator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(body_generator)

PARAMS = {
    'quantity': 2,
    'colour': 'black',
    'overall_mm': [9.4, 13.0, 2.8],
    'visible_oval_plate_thickness_mm': 0.8,
    'locating_boss_mm': [6.0, 8.2, 2.0],
    'existing_recess_ellipsoid_radii_mm': [5.0, 1.4, 6.8],
    'assembly_eye_centres_body_mm': [[-16, -38, 58], [16, -38, 58]],
    'print_orientation': 'flat oval face on bed; smaller rounded locating boss upwards',
    'fixing': 'small amount of suitable adhesive; not a snap fit',
    'physical_fit_verified': False,
}

def pupil_mesh():
    count = 128
    angle = np.arange(count) * 2 * np.pi / count
    rings = [(0, 4.5, 6.3), (0.2, 4.7, 6.5), (0.65, 4.7, 6.5),
             (0.8, 4.55, 6.35), (0.8, 3.0, 4.1), (2.25, 3.0, 4.1)]
    for phi in np.linspace(0, np.pi / 2, 19)[1:-1]:
        rings.append((2.25 + .55 * np.sin(phi), 3 * np.cos(phi), 4.1 * np.cos(phi)))
    vertices = [np.array([rx * np.cos(angle), ry * np.sin(angle), np.full(count, z)]).T
                for z, rx, ry in rings]
    vertices = np.concatenate(vertices)
    bottom = len(vertices)
    top = bottom + 1
    vertices = np.vstack((vertices, [0, 0, 0], [0, 0, 2.8]))
    faces = []
    for j in range(count):
        k = (j + 1) % count
        faces.append([bottom, k, j])
    for ring in range(len(rings) - 1):
        for j in range(count):
            k = (j + 1) % count
            a, b = ring * count + j, ring * count + k
            c, d = (ring + 1) * count + k, (ring + 1) * count + j
            faces.extend([[a, b, c], [a, c, d]])
    for j in range(count):
        faces.append([(len(rings) - 1) * count + j,
                      (len(rings) - 1) * count + (j + 1) % count, top])
    return vertices, np.array(faces, dtype=np.int32)

def assembled(vertices, side):
    return np.column_stack((vertices[:, 0] + side * 16,
                            vertices[:, 2] - 38, vertices[:, 1] + 58))

def write_three_mf(vertices, faces):
    lines = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02">',
             '<metadata name="Title">Black pupils, two pieces, for help-button V1</metadata><resources>',
             '<basematerials id="100"><base name="Black PLA" displaycolor="#111111"/></basematerials>']
    for i, name in [(1, 'pupil-left'), (2, 'pupil-right')]:
        lines.append(f'<object id="{i}" type="model" name="{name}" pid="100" pindex="0"><mesh><vertices>')
        lines.extend('<vertex x="%.6f" y="%.6f" z="%.6f"/>' % tuple(v) for v in vertices)
        lines.append('</vertices><triangles>')
        lines.extend('<triangle v1="%d" v2="%d" v3="%d"/>' % tuple(f) for f in faces)
        lines.append('</triangles></mesh></object>')
    lines.append('</resources><build><item objectid="1" transform="1 0 0 0 1 0 0 0 1 110 125 0"/>'
                 '<item objectid="2" transform="1 0 0 0 1 0 0 0 1 130 125 0"/></build></model>')
    with zipfile.ZipFile(HERE / '黑色眼珠-两只.3mf', 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
        z.writestr('_rels/.rels', '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
        z.writestr('3D/3dmodel.model', ''.join(lines))

def read_stl(path):
    data = path.read_bytes()
    dtype = np.dtype([('normal', '<f4', 3), ('vertices', '<f4', (3, 3)), ('attribute', '<u2')])
    return np.frombuffer(data, dtype=dtype, offset=84)['vertices'].astype(float)

def render(objects, image, box, camera):
    towards = np.array(camera, dtype=float)
    towards /= np.linalg.norm(towards)
    right = np.cross([0, 0, 1], towards)
    right /= np.linalg.norm(right)
    up = np.cross(towards, right)
    # Flip the horizontal basis for a natural front view.
    right = -right
    triangles = np.concatenate([o[0] for o in objects])
    colour = np.concatenate([np.tile(o[1], (len(o[0]), 1)) for o in objects])
    normals = np.cross(triangles[:, 1] - triangles[:, 0], triangles[:, 2] - triangles[:, 0])
    lengths = np.linalg.norm(normals, axis=1)
    normals /= np.maximum(lengths[:, None], 1e-12)
    # Assembly transform swaps axes; reorient each transformed object below.
    visible = normals @ towards > 1e-8
    triangles, colour, normals = triangles[visible], colour[visible], normals[visible]
    projected = np.stack((triangles @ right, -(triangles @ up)), axis=-1)
    lo, hi = projected.min(axis=(0, 1)), projected.max(axis=(0, 1))
    x, y, width, height = box
    scale = min(width / (hi[0] - lo[0]), height / (hi[1] - lo[1]))
    projected = (projected - (lo + hi) / 2) * scale + [x + width / 2, y + height / 2]
    light = np.array([-.4, -.7, .9]); light /= np.linalg.norm(light)
    brightness = .57 + .43 * np.maximum(normals @ light, 0)
    colours = np.clip(colour * brightness[:, None], 0, 255).astype(int)
    order = np.argsort((triangles @ towards).mean(axis=1))
    draw = ImageDraw.Draw(image)
    for i in order:
        draw.polygon([tuple(p) for p in projected[i]], fill=tuple(colours[i]))

def preview(vertices, faces):
    image = Image.new('RGB', (1800, 1180), '#F5F3EF')
    draw = ImageDraw.Draw(image)
    font_path = '/System/Library/Fonts/STHeiti Medium.ttc'
    title = ImageFont.truetype(font_path, 53)
    text = ImageFont.truetype(font_path, 31)
    small = ImageFont.truetype(font_path, 25)
    draw.text((75, 45), '黑色眼珠 · 两只独立嵌件', fill='#24362A', font=title)
    draw.rounded_rectangle((55, 145, 1110, 1060), 35, fill='white')
    draw.rounded_rectangle((1140, 145, 1745, 1060), 35, fill='white')
    body = read_stl(BASE / 'body.stl')
    cap = read_stl(BASE / 'top-button.stl').copy()
    cap[:, :, 1] *= -1
    cap[:, :, 2] = 82 - cap[:, :, 2]
    objects = [(body, [246, 233, 207]), (cap, [109, 161, 116])]
    for side in (-1, 1):
        # Preserve outward winding after the y/z swap (negative determinant).
        eye = assembled(vertices, side)[faces[:, [0, 2, 1]]]
        objects.append((eye, [38, 40, 38]))
    render(objects, image, (105, 205, 945, 735), (.1, -1, .22))
    draw.text((95, 975), '装配示意：嵌入现有两个眼窝', fill='#38423A', font=text)
    eye1 = vertices[faces].copy()
    eye2 = eye1.copy(); eye2[:, :, 0] += 17
    render([(eye1, [43, 45, 43]), (eye2, [43, 45, 43])], image,
           (1190, 265, 505, 420), (0, -1, 1.7))
    draw.text((1190, 195), '打印时这样放', fill='#24362A', font=text)
    draw.text((1190, 755), '平面贴板，小凸台朝上', fill='#38423A', font=text)
    draw.text((1190, 825), '每只 9.4 × 13 × 2.8 mm', fill='#38423A', font=small)
    draw.text((1190, 880), '黑色 PLA · 两只同盘', fill='#38423A', font=small)
    draw.text((1190, 935), '少量胶固定，尺寸待实装确认', fill='#6A6F69', font=small)
    draw.text((75, 1100), '根据实际 STL 网格绘制；原有白色主壳与绿色按钮文件未修改。', fill='#6A6F69', font=small)
    image.save(HERE / '黑色眼珠-装配与打印示意.png')

if __name__ == '__main__':
    original_hashes = {n: hashlib.sha256((BASE / n).read_bytes()).hexdigest()
                       for n in ('body.stl', 'top-button.stl', 'rear-cover.stl')}
    v, f = pupil_mesh()
    stats = body_generator.validate(v, f)
    assert stats['boundary_edges'] == stats['nonmanifold_edges'] == 0
    assert stats['surface_components'] == 1 and stats['signed_volume_mm3'] > 0
    assert np.allclose(np.ptp(v, axis=0), [9.4, 13, 2.8])
    samples = np.vstack((v, v[f].mean(axis=1), (v[f[:, 0]] + v[f[:, 1]]) / 2,
                         (v[f[:, 1]] + v[f[:, 2]]) / 2, (v[f[:, 2]] + v[f[:, 0]]) / 2))
    clearance = {}
    for side in (-1, 1):
        points = assembled(samples, side)
        values = body_generator.body(points[:, 0], points[:, 1], points[:, 2])
        assert values.min() > 0, f'Pupil intersects source body field: {values.min()}'
        clearance[str(side)] = float(values.min())
    body_generator.stl(HERE / 'pupil-left.stl', v, f)
    shutil.copyfile(HERE / 'pupil-left.stl', HERE / 'pupil-right.stl')
    write_three_mf(v, f)
    preview(v, f)
    assert all(hashlib.sha256((BASE / n).read_bytes()).hexdigest() == h for n, h in original_hashes.items())
    report = {'parameters': PARAMS, 'topology': stats,
              'sampled_source_body_field_min_positive_mm': clearance,
              'fit_check_limit': 'Sampled analytic source-body field, not physical fit or an exact mesh collision proof.',
              'original_part_sha256_unchanged': original_hashes,
              'three_mf_contains_two_black_pupils': True,
              'sliced': False, 'printer_command_sent': False}
    (HERE / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    (HERE / '说明.txt').write_text('黑色眼珠（两只）\n\n打开“黑色眼珠-两只.3mf”，按毫米导入，保持原方向。\n两只眼珠平面贴打印板，小凸台朝上；选择实际黑色PLA耗材后切片。\n每只9.4×13×2.8毫米；建议0.16毫米层高、100%填充，无需支撑。\n打印后清理边缘，先轻放到眼窝检查，再用少量适合PLA的胶固定，不要硬压。\n原外壳无需重打。当前尺寸按现有数字模型设计，尚未实装验证。\n3MF含模型及黑色参考色，不含特定打印机的切片G-code，也没有发送打印。\n\n扬声器：当前外壳与ESP32程序均未设计桌面扬声器；提醒由手机系统通知/弹窗承担。\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
