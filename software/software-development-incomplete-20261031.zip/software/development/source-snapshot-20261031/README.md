# 等你来 / 拍拍小怪兽 · Android 软件

桌面按钮通过 ESP32 BLE 向 Android 手机发起求助。手机将同一件未完成求助逐级提醒，并记录回应和处理时间。仓库同时保留早期“等你来”名称和正在开发的“拍拍小怪兽”界面名称。

## 先看版本状态

**当前源码是开发快照，与下面的 0.2.1 APK 不是同一次构建。**

| 内容 | 状态 |
| --- | --- |
| `app/`、`tests/` | 2026-10-31 导出的最新本地源码；包含家长密码、服务恢复和协议阅读/签名相关开发 |
| `../../releases/0.2.1/deng-ni-lai-0.2.1-bluetooth.apk` | 已有原版调试包；包名 `com.loyee.dengnilai`，versionCode 3，版本 `0.2.1-bluetooth` |
| `../../releases/0.2.1/deng-ni-lai-0.2.1-simulation.apk` | 已有独立模拟调试包；包名 `com.loyee.dengnilai.simulation`，versionCode 3，版本 `0.2.1-simulation` |

两个已有 APK 均通过 `aapt2 dump badging` 元数据检查与 `apksigner verify` 签名验证。它们早于最新源码修改，**不包含最新密码/协议相关改动**。本次上传整理没有操作手机或重做蓝牙、跨应用弹窗实测。

当前源码的 `MainActivity.java` 引用了 `AgreementActivity`，但该文件未出现在本次源码快照中；全量编译因此未通过。旧模拟构建脚本的文本锚点也尚未适配新的界面名称和结构。请勿把开发快照当作可直接构建的新版本。具体编译结果见 [`verification/source-check.json`](verification/source-check.json)。

## 安装已有调试 APK

在自己的 Android 手机上安装 `../../releases/0.2.1/` 中对应的 APK。最低 Android 8（API 26），目标 Android 15（API 35）。原版和模拟版使用不同包名，可分别保存记录。

1. 打开应用，按界面开始作业陪伴；按系统提示允许通知、附近设备和悬浮提醒。
2. 搜索并选择 `DengNiLai Button`，完成通知订阅后再按实体按钮。
3. 模拟版另有“5 秒后按一次”“5 秒后连续按 3 次”，可给使用者留出切换应用的时间。
4. 点击“收到，我来了”记为回应；问题处理后再标记完成。

悬浮提醒受 Android 系统和其他应用的限制；不能保证所有应用、系统页面、方向或手机都可覆盖显示。系统强制停止应用会结束服务，需要重新打开应用。本仓库未发布开发者的签名私钥；自行构建会使用自己的调试密钥，通常不能直接覆盖本目录已有签名的 APK。

## 源码与检查

| 路径 | 内容 |
| --- | --- |
| `app/src/main/` | 原生 Java 界面、状态、BLE、前台服务、悬浮提醒、资源和 Manifest |
| `tests/` | 求助状态、BLE 去重/协议、恢复、密码、家长授权和协议阅读策略测试 |
| `simulation/` | 旧独立模拟包的暂存源码补丁 |
| `tools/` | 可选模拟器/手机验收脚本；读取脚本说明后，明确指定设备再操作 |
| `manual-build.sh` | Android SDK 工具离线构建流程（当前全量源码问题需先修复） |
| `build-simulation.sh` | 从暂存副本生成独立包的旧脚本（锚点需先更新） |
| `test.sh` | 运行六组无界面 JVM 检查 |
| `source-provenance.json` | 源码快照哈希和导出时的路径适配说明 |
| `../../manifest.json` | 软件目录全部发布文件大小和 SHA-256（不包含清单自身） |

需要自行安装 **JDK 17、Android SDK Platform 35、Build Tools 35.0.0**。Gradle 配置使用 Android Gradle Plugin 8.6.0；本仓库没有打包 Gradle wrapper、SDK、缓存或第三方依赖。

```sh
# 将路径改成自己的安装位置。
export ANDROID_SDK_ROOT="$HOME/Library/Android/sdk"
export DENG_NI_LAI_JDK="/path/to/jdk-17"
bash test.sh
# 修复 README 所列源码问题后再执行：
bash manual-build.sh
bash build-simulation.sh
```

本次独立运行 `bash test.sh`：六组检查共 **229 项通过**（19 + 30 + 30 + 83 + 33 + 34）。这验证了相关策略和协议逻辑，不能替代完整 Android 编译、安装、真机权限、蓝牙或界面验证。

## 接口和硬件

BLE 广播名为 `DengNiLai Button`。BLE 不要求手机和按钮连接同一 Wi-Fi。配套 ESP32 固件和接线放在硬件仓库：[loyee001/yingjian](https://github.com/loyee001/yingjian)。本软件目录不重复打包硬件工具链。

另外保留家庭局域网调试接口，开始陪伴后原版监听 8742，已有独立模拟包监听 8743。接口要求会话配对令牌；不要将端口暴露到公网，也不要把令牌写进仓库。`GET /state`、`POST /help`、`POST /ack`、`POST /complete` 分别用于观察、求助、回应、完成。

## 隐私与打包范围

本目录未包含本机调试签名密钥、私钥、SDK、缓存、构建中间产物、调试日志、手机截图、设备标识、实际配对码或使用者记录。测试中的数字密码和 MAC 地址是固定测试样例，不是使用者凭证。本次只整理并验证本地文件，没有宣称新的真机测试已通过。
