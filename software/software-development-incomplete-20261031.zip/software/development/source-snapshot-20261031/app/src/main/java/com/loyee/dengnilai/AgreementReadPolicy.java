package com.loyee.dengnilai;

/** Pure decisions for foreground reading and meaningful pen strokes. */
final class AgreementReadPolicy {
    static final long REQUIRED_READ_MILLIS = 10000L;
    private long accumulatedMillis;
    private long foregroundSince = -1;
    private boolean signatureValid;

    AgreementReadPolicy(long restoredReadMillis) {
        accumulatedMillis = Math.max(0, Math.min(REQUIRED_READ_MILLIS, restoredReadMillis));
    }

    void resume(long monotonicMillis) {
        if (foregroundSince < 0 && monotonicMillis >= 0) foregroundSince = monotonicMillis;
    }

    void pause(long monotonicMillis) {
        accumulatedMillis = readMillis(monotonicMillis);
        foregroundSince = -1;
    }

    long readMillis(long monotonicMillis) {
        long remaining = REQUIRED_READ_MILLIS - accumulatedMillis;
        if (foregroundSince < 0 || monotonicMillis < foregroundSince || remaining <= 0) {
            return accumulatedMillis;
        }
        long elapsed = monotonicMillis - foregroundSince;
        return accumulatedMillis + Math.min(remaining, elapsed);
    }

    long remainingMillis(long monotonicMillis) {
        return REQUIRED_READ_MILLIS - readMillis(monotonicMillis);
    }

    boolean canSign(long monotonicMillis) {
        return remainingMillis(monotonicMillis) == 0;
    }

    void setSignatureValid(boolean valid, long monotonicMillis) {
        signatureValid = valid && canSign(monotonicMillis);
    }

    boolean canConfirm(long monotonicMillis) {
        return canSign(monotonicMillis) && signatureValid;
    }

    static boolean substantialSignature(float lengthDp, float widthDp, float heightDp, int segments) {
        if (Float.isNaN(lengthDp) || Float.isInfinite(lengthDp)
                || Float.isNaN(widthDp) || Float.isInfinite(widthDp)
                || Float.isNaN(heightDp) || Float.isInfinite(heightDp)
                || lengthDp < 36f || widthDp < 0 || heightDp < 0 || segments < 1) return false;
        // Length rejects a tap; extent also rejects repeated tiny movement in one spot.
        return Math.hypot(widthDp, heightDp) >= 24.0;
    }
}
