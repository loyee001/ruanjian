package com.loyee.dengnilai;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.AtomicFile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** A versioned, device-local agreement receipt. No network or shared storage. */
final class AgreementStore {
    static final int VERSION = 1;
    static final String AGREEMENT_TEXT = "使用本APP，请允许其获取所有权限（系统自动禁止的权限除外）";
    private static final String PREFERENCES = "deng_ni_lai_agreement";
    private static final String SIGNATURE_NAME = "gentleman-signature-v1.png";
    private static final int MAX_SIGNATURE_BYTES = 4 * 1024 * 1024;
    private static final byte[] PNG_HEADER = {(byte) 137, 80, 78, 71, 13, 10, 26, 10};

    private AgreementStore() {}

    static boolean isAccepted(Context context) {
        try {
            File directory = directory(context);
            if (new File(directory, "signing.pending").exists()) return false;
            SharedPreferences receipt = preferences(context);
            if (receipt.getInt("version", 0) != VERSION
                    || receipt.getLong("signed_at", 0) <= 0
                    || receipt.getLong("read_millis", 0) < AgreementReadPolicy.REQUIRED_READ_MILLIS
                    || !AGREEMENT_TEXT.equals(receipt.getString("agreement_text", ""))
                    || !SIGNATURE_NAME.equals(receipt.getString("signature_file", ""))) return false;
            String expected = receipt.getString("signature_sha256", "");
            if (!validDigest(expected)) return false;
            File signature = new File(directory, SIGNATURE_NAME);
            if (!signature.isFile() || signature.length() <= PNG_HEADER.length
                    || signature.length() > MAX_SIGNATURE_BYTES || !isPng(signature)) return false;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(signature.getAbsolutePath(), options);
            if (options.outWidth <= 0 || options.outHeight <= 0
                    || options.outWidth > 1024 || options.outHeight > 1024
                    || !"image/png".equals(options.outMimeType)) return false;
            return MessageDigest.isEqual(expected.getBytes(StandardCharsets.US_ASCII),
                    digestFile(signature).getBytes(StandardCharsets.US_ASCII));
        } catch (IOException | RuntimeException invalidReceipt) {
            return false;
        }
    }

    /** Called by the activity's worker only after a real signature and ten-second gate. */
    static synchronized void save(Context context, Bitmap signature, long readMillis) throws IOException {
        if (readMillis < AgreementReadPolicy.REQUIRED_READ_MILLIS || signature == null
                || signature.isRecycled() || signature.getWidth() <= 0 || signature.getHeight() <= 0
                || signature.getWidth() > 1024 || signature.getHeight() > 1024 || !hasInk(signature)) {
            throw new IOException("Agreement reading or handwritten signature is incomplete");
        }
        File directory = directory(context);
        if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Cannot create private receipt directory");
        File pending = new File(directory, "signing.pending");
        // A failed/unfinished transaction must remain unaccepted, even if a failed
        // SharedPreferences commit has already updated its in-memory cache.
        try (FileOutputStream marker = new FileOutputStream(pending)) {
            marker.write(1);
            marker.getFD().sync();
        }
        byte[] png;
        try (ByteArrayOutputStream encoded = new ByteArrayOutputStream()) {
            if (!signature.compress(Bitmap.CompressFormat.PNG, 100, encoded)) throw new IOException("Cannot encode signature");
            png = encoded.toByteArray();
        }
        if (png.length <= PNG_HEADER.length || png.length > MAX_SIGNATURE_BYTES) throw new IOException("Invalid signature size");
        String digest = digestBytes(png);
        File destination = new File(directory, SIGNATURE_NAME);
        AtomicFile atomic = new AtomicFile(destination);
        FileOutputStream output = null;
        try {
            output = atomic.startWrite();
            output.write(png);
            atomic.finishWrite(output);
            output = null;
        } catch (IOException | RuntimeException failure) {
            if (output != null) atomic.failWrite(output);
            throw new IOException("Cannot persist signature", failure);
        }
        if (!destination.isFile() || !digest.equals(digestFile(destination))) throw new IOException("Signature read-back failed");
        long signedAt = System.currentTimeMillis();
        if (signedAt <= 0) throw new IOException("Invalid signing time");
        boolean committed = preferences(context).edit()
                .putInt("version", VERSION).putLong("signed_at", signedAt)
                .putLong("read_millis", AgreementReadPolicy.REQUIRED_READ_MILLIS)
                .putString("agreement_text", AGREEMENT_TEXT)
                .putString("signature_file", SIGNATURE_NAME)
                .putString("signature_sha256", digest).commit();
        if (!committed) throw new IOException("Cannot persist agreement receipt");
        if (!pending.delete()) throw new IOException("Cannot complete agreement transaction");
        if (!isAccepted(context)) throw new IOException("Agreement receipt read-back failed");
    }

    private static boolean hasInk(Bitmap bitmap) {
        int[] row = new int[bitmap.getWidth()];
        int dark = 0;
        for (int y = 0; y < bitmap.getHeight(); y++) {
            bitmap.getPixels(row, 0, row.length, 0, y, row.length, 1);
            for (int color : row) {
                if ((color >>> 24) > 100 && ((color >> 16) & 255) < 180
                        && ((color >> 8) & 255) < 180 && (color & 255) < 180 && ++dark >= 24) return true;
            }
        }
        return false;
    }

    private static SharedPreferences preferences(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
    }

    private static File directory(Context context) {
        return new File(context.getApplicationContext().getNoBackupFilesDir(), "agreements");
    }

    private static boolean isPng(File file) throws IOException {
        try (FileInputStream input = new FileInputStream(file)) {
            for (byte expected : PNG_HEADER) if (input.read() != (expected & 255)) return false;
            return true;
        }
    }

    private static boolean validDigest(String digest) {
        if (digest == null || digest.length() != 64) return false;
        for (int i = 0; i < digest.length(); i++) {
            char c = digest.charAt(i);
            if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return false;
        }
        return true;
    }

    private static MessageDigest sha256() throws IOException {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException unavailable) { throw new IOException("SHA-256 unavailable", unavailable); }
    }

    private static String digestBytes(byte[] bytes) throws IOException {
        return hex(sha256().digest(bytes));
    }

    private static String digestFile(File file) throws IOException {
        MessageDigest digest = sha256();
        byte[] buffer = new byte[8192];
        int total = 0;
        try (FileInputStream input = new FileInputStream(file)) {
            int count;
            while ((count = input.read(buffer)) != -1) {
                total += count;
                if (total > MAX_SIGNATURE_BYTES) throw new IOException("Signature exceeds size limit");
                digest.update(buffer, 0, count);
            }
        }
        return hex(digest.digest());
    }

    private static String hex(byte[] bytes) {
        char[] hex = "0123456789abcdef".toCharArray();
        char[] result = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            result[i * 2] = hex[(bytes[i] >>> 4) & 15];
            result[i * 2 + 1] = hex[bytes[i] & 15];
        }
        return new String(result);
    }
}
