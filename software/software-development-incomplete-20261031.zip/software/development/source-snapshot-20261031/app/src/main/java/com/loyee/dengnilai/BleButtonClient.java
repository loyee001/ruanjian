package com.loyee.dengnilai;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.os.SystemClock;
import android.provider.Settings;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Session-owned BLE central. All Bluetooth operations and listener calls use the main thread. */
final class BleButtonClient {
    static final UUID SERVICE_UUID = UUID.fromString("e8f5a000-7e9b-4b8b-9a4c-6d6e696c6169");
    static final UUID PRESS_UUID = UUID.fromString("e8f5a001-7e9b-4b8b-9a4c-6d6e696c6169");
    private static final UUID CCCD_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final Object SNAPSHOT_LOCK = new Object();
    private static final LinkedHashMap<String, FoundDevice> FOUND = new LinkedHashMap<>();
    private static volatile String currentStatus = "尚未连接蓝牙按钮";
    private static volatile String currentName = "";
    private static volatile boolean scanning, connected;

    interface Listener {
        void onStateChanged();
        void onPress(String requestId);
        void onDeviceSelected(String address, String name);
    }

    static final class FoundDevice {
        final String address, name;
        FoundDevice(String address, String name) { this.address = address; this.name = name; }
    }

    private final Context context;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private final SeenPresses seen = new SeenPresses();
    private final ReconnectPolicy reconnectPolicy = new ReconnectPolicy();
    private BluetoothLeScanner scanner;
    private ScanCallback scanCallback;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic pressCharacteristic;
    private Runnable scanTimeout, connectionTimeout, reconnectTask;
    private String selectedAddress = "", selectedName = "";
    private long scanGeneration, connectionGeneration;
    private boolean closed, connecting, reconnectEnabled;

    BleButtonClient(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        BluetoothManager manager = this.context.getSystemService(BluetoothManager.class);
        adapter = manager == null ? null : manager.getAdapter();
        synchronized (SNAPSHOT_LOCK) { FOUND.clear(); }
        scanning = false; connected = false; currentName = "";
        currentStatus = "尚未连接蓝牙按钮";
    }

    static List<FoundDevice> devices() {
        synchronized (SNAPSHOT_LOCK) { return new ArrayList<>(FOUND.values()); }
    }
    static String status() { return currentStatus; }
    static boolean isScanning() { return scanning; }
    static boolean isConnected() { return connected; }
    static String connectedName() { return currentName; }
    boolean isClosed() { return closed; }

    void scan() { onMain(this::startScan); }
    void pauseScan() { onMain(() -> {
        if (closed || !scanning) return;
        stopScan();
        update(devices().isEmpty() ? "扫描已暂停，回到应用后可重新扫描按钮" : "扫描已暂停，请回到应用点选按钮连接");
    }); }
    void connect(String address) { onMain(() -> connectSelected(address)); }
    void restoreConnection(String address, String name) { onMain(() -> {
        if (closed || connected || connecting || !Protocol.validAddress(address)) return;
        selectedAddress = address;
        selectedName = safeName(name);
        reconnectEnabled = true;
        reconnectPolicy.reset();
        connectKnown(true);
    }); }
    void disconnect() { onMain(() -> {
        if (closed) return;
        reconnectEnabled = false; cancelReconnect();
        stopScan(); releaseGatt(); update("已断开蓝牙按钮");
    }); }
    void close() { onMain(() -> {
        if (closed) return;
        closed = true; reconnectEnabled = false; cancelReconnect(); stopScan(); releaseGatt();
        synchronized (SNAPSHOT_LOCK) { FOUND.clear(); }
        seen.clear(); update("尚未连接蓝牙按钮");
        main.removeCallbacksAndMessages(null);
    }); }

    private void onMain(Runnable task) {
        if (Looper.myLooper() == main.getLooper()) task.run(); else main.post(task);
    }
    private void update(String value) { currentStatus = value; listener.onStateChanged(); }

    private boolean ready(boolean forScan) {
        if (adapter == null || !context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            update("这台手机不支持低功耗蓝牙"); return false;
        }
        if (Build.VERSION.SDK_INT >= 31) {
            if (context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                || (forScan && context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)) {
                update("请允许“附近设备”权限后再连接"); return false;
            }
        } else if (forScan) {
            if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                update("此安卓版本需要定位权限才能扫描蓝牙"); return false;
            }
            LocationManager location = context.getSystemService(LocationManager.class);
            boolean locationOn = Build.VERSION.SDK_INT >= 28
                ? location != null && location.isLocationEnabled()
                : Settings.Secure.getInt(context.getContentResolver(), Settings.Secure.LOCATION_MODE, 0) != 0;
            if (!locationOn) { update("请打开手机定位开关后再扫描蓝牙"); return false; }
        }
        try {
            if (!adapter.isEnabled()) { update("蓝牙未打开，请先打开手机蓝牙"); return false; }
        } catch (SecurityException error) {
            update("蓝牙权限已关闭，请重新授权"); return false;
        }
        return true;
    }

    private void startScan() {
        if (closed) return;
        if (connected || connecting) { update(connected ? "按钮已连接，换设备请先断开" : "正在连接按钮，请稍候"); return; }
        reconnectEnabled = false; cancelReconnect(); stopScan();
        if (!ready(true)) return;
        synchronized (SNAPSHOT_LOCK) { FOUND.clear(); }
        final long generation = ++scanGeneration;
        scanCallback = new ScanCallback() {
            @Override public void onScanResult(int callbackType, ScanResult result) {
                onMain(() -> found(generation, result));
            }
            @Override public void onBatchScanResults(List<ScanResult> results) {
                for (ScanResult result : results) onMain(() -> found(generation, result));
            }
            @Override public void onScanFailed(int errorCode) {
                onMain(() -> {
                    if (closed || generation != scanGeneration) return;
                    stopScan(); update("扫描未能开始（" + errorCode + "），请稍后重试");
                });
            }
        };
        try {
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { scanCallback = null; update("蓝牙尚未就绪，请打开蓝牙后重试"); return; }
            scanning = true;
            scanner.startScan(Collections.singletonList(new ScanFilter.Builder().setServiceUuid(new ParcelUuid(SERVICE_UUID)).build()),
                new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCallback);
            update("正在寻找拍拍小怪兽按钮（15 秒）…");
            scanTimeout = () -> {
                if (closed || generation != scanGeneration) return;
                stopScan();
                update(devices().isEmpty() ? "未找到按钮，请确认 ESP32 已上电并烧录配套固件" : "扫描完成，请点选你的按钮连接");
            };
            main.postDelayed(scanTimeout, 15000);
        } catch (SecurityException error) {
            stopScan(); update("蓝牙权限已关闭，请重新授权");
        } catch (RuntimeException error) {
            stopScan(); update("蓝牙扫描暂不可用，请关闭再打开蓝牙后重试");
        }
    }

    private void found(long generation, ScanResult result) {
        if (closed || !scanning || generation != scanGeneration || result == null || result.getScanRecord() == null) return;
        List<ParcelUuid> services = result.getScanRecord().getServiceUuids();
        if (services == null || !services.contains(new ParcelUuid(SERVICE_UUID))) return;
        try {
            String address = result.getDevice().getAddress();
            if (!BluetoothAdapter.checkBluetoothAddress(address)) return;
            String name = result.getScanRecord().getDeviceName();
            name = safeName(name);
            synchronized (SNAPSHOT_LOCK) {
                FoundDevice previous = FOUND.get(address);
                if (previous != null && previous.name.equals(name)) return;
                FOUND.put(address, new FoundDevice(address, name));
            }
            update("找到 " + devices().size() + " 个按钮，请点选你的设备");
        } catch (SecurityException error) {
            stopScan(); update("蓝牙权限已关闭，请重新授权");
        }
    }

    private void stopScan() {
        scanGeneration++;
        if (scanTimeout != null) main.removeCallbacks(scanTimeout);
        scanTimeout = null;
        if (scanner != null && scanCallback != null) {
            try { scanner.stopScan(scanCallback); } catch (SecurityException | IllegalStateException ignored) { }
        }
        scanner = null; scanCallback = null; scanning = false;
    }

    private void connectSelected(String address) {
        if (closed) return;
        FoundDevice selected;
        synchronized (SNAPSHOT_LOCK) { selected = FOUND.get(address); }
        if (selected == null) { update("请先扫描，再点选列表中的按钮"); return; }
        if (!ready(false)) return;
        selectedAddress = selected.address; selectedName = selected.name;
        reconnectEnabled = true;
        reconnectPolicy.reset();
        // Only an explicit list selection is remembered; scans and automatic reconnects cannot opt in.
        listener.onDeviceSelected(selectedAddress, selectedName);
        connectKnown(false);
    }

    private static String safeName(String name) {
        if (name == null || name.trim().isEmpty()) return "拍拍小怪兽按钮";
        String value = name.replaceAll("[\\p{Cntrl}]", "").trim();
        return value.isEmpty() ? "拍拍小怪兽按钮" : value.substring(0, Math.min(40, value.length()));
    }

    private void connectKnown(boolean restoring) {
        if (closed) return;
        cancelReconnect(); stopScan(); releaseGatt();
        if (!ready(false)) return;
        final long generation = connectionGeneration;
        connecting = true;
        update((restoring ? "正在恢复连接 " : "正在连接 ") + selectedName + "…");
        BluetoothGattCallback callback = new BluetoothGattCallback() {
            @Override public void onConnectionStateChange(BluetoothGatt source, int status, int newState) {
                onMain(() -> connectionChanged(generation, source, status, newState));
            }
            @Override public void onServicesDiscovered(BluetoothGatt source, int status) {
                onMain(() -> servicesDiscovered(generation, source, status));
            }
            @Override public void onDescriptorWrite(BluetoothGatt source, BluetoothGattDescriptor descriptor, int status) {
                onMain(() -> subscribed(generation, source, descriptor, status));
            }
            @SuppressWarnings("deprecation")
            @Override public void onCharacteristicChanged(BluetoothGatt source, BluetoothGattCharacteristic characteristic) {
                if (Build.VERSION.SDK_INT >= 33) return;
                byte[] value = characteristic.getValue();
                final byte[] copy = value == null ? null : value.clone();
                onMain(() -> notification(generation, source, characteristic, copy));
            }
            @Override public void onCharacteristicChanged(BluetoothGatt source, BluetoothGattCharacteristic characteristic, byte[] value) {
                final byte[] copy = value == null ? null : value.clone();
                onMain(() -> notification(generation, source, characteristic, copy));
            }
        };
        try {
            BluetoothDevice device = adapter.getRemoteDevice(selectedAddress);
            gatt = device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE, BluetoothDevice.PHY_LE_1M_MASK, main);
            if (gatt == null) retryableFailure("连接未能开始");
            else armTimeout(generation, "连接超时，请靠近按钮后重试");
        } catch (SecurityException error) { fail("蓝牙权限已关闭，请重新授权"); }
          catch (RuntimeException error) { retryableFailure("连接暂不可用"); }
    }

    private boolean current(long generation, BluetoothGatt source) {
        return !closed && generation == connectionGeneration && source == gatt;
    }
    private void connectionChanged(long generation, BluetoothGatt source, int status, int newState) {
        if (!current(generation, source)) return;
        if (status != BluetoothGatt.GATT_SUCCESS) { retryableFailure("按钮连接中断（" + status + "）"); return; }
        if (newState == BluetoothProfile.STATE_CONNECTED) {
            update("已连接，正在确认按钮服务…");
            try {
                if (!source.discoverServices()) retryableFailure("读取按钮服务失败");
                else armTimeout(generation, "读取按钮服务超时，请重新连接");
            } catch (SecurityException error) { fail("蓝牙权限已关闭，请重新授权"); }
              catch (RuntimeException error) { retryableFailure("读取按钮服务暂不可用"); }
        } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
            retryableFailure("按钮已断开");
        }
    }
    @SuppressWarnings("deprecation")
    private void servicesDiscovered(long generation, BluetoothGatt source, int status) {
        if (!current(generation, source)) return;
        if (status != BluetoothGatt.GATT_SUCCESS) { retryableFailure("读取按钮服务失败"); return; }
        BluetoothGattService service = source.getService(SERVICE_UUID);
        BluetoothGattCharacteristic characteristic = service == null ? null : service.getCharacteristic(PRESS_UUID);
        if (characteristic == null || (characteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) == 0) {
            fail("这个设备没有拍拍小怪兽按钮服务，请检查固件"); return;
        }
        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(CCCD_UUID);
        if (descriptor == null) { fail("按钮固件缺少通知设置，请更新配套固件"); return; }
        try {
            pressCharacteristic = characteristic;
            if (!source.setCharacteristicNotification(characteristic, true)) { retryableFailure("无法开启按钮通知"); return; }
            boolean started;
            if (Build.VERSION.SDK_INT >= 33) started = source.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == 0;
            else {
                descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                started = source.writeDescriptor(descriptor);
            }
            if (!started) { retryableFailure("无法订阅按钮通知"); return; }
            update("正在开启按钮提醒…");
            armTimeout(generation, "订阅按钮提醒超时，请重新连接");
        } catch (SecurityException error) { fail("蓝牙权限已关闭，请重新授权"); }
          catch (RuntimeException error) { retryableFailure("订阅按钮通知暂不可用"); }
    }
    private void subscribed(long generation, BluetoothGatt source, BluetoothGattDescriptor descriptor, int status) {
        if (!current(generation, source) || descriptor == null || !CCCD_UUID.equals(descriptor.getUuid())
            || descriptor.getCharacteristic() != pressCharacteristic) return;
        if (status != BluetoothGatt.GATT_SUCCESS) { retryableFailure("开启按钮提醒失败"); return; }
        if (connectionTimeout != null) main.removeCallbacks(connectionTimeout);
        connectionTimeout = null; connecting = false; connected = true; currentName = selectedName;
        reconnectPolicy.onSubscribed(SystemClock.elapsedRealtime());
        update("已连接 " + selectedName + "，拍按钮即可提醒");
    }
    private void notification(long generation, BluetoothGatt source, BluetoothGattCharacteristic characteristic, byte[] value) {
        if (!current(generation, source) || !connected || characteristic != pressCharacteristic) return;
        String requestId = Protocol.requestIdFromPayload(selectedAddress, value);
        if (requestId != null && seen.accept(requestId)) listener.onPress(requestId);
    }
    private void armTimeout(long generation, String message) {
        if (connectionTimeout != null) main.removeCallbacks(connectionTimeout);
        connectionTimeout = () -> { if (!closed && generation == connectionGeneration && !connected) retryableFailure(message); };
        main.postDelayed(connectionTimeout, 20000);
    }
    private void fail(String message) {
        reconnectEnabled = false; cancelReconnect(); releaseGatt(); update(message);
    }
    private void retryableFailure(String message) {
        releaseGatt();
        if (!reconnectEnabled || closed) { update(message); return; }
        // Turning off Bluetooth/revoking permission is not a reason to poll or relaunch the app.
        if (!ready(false)) return;
        long delay = reconnectPolicy.nextDelay(SystemClock.elapsedRealtime());
        if (delay < 0) { update(message + "；自动重连已暂停，请回应用重新连接"); return; }
        final long generation = connectionGeneration;
        update(message + "，" + (delay / 1000) + " 秒后重连（" + reconnectPolicy.attempts() + "/3）");
        reconnectTask = () -> {
            reconnectTask = null;
            if (closed || !reconnectEnabled || generation != connectionGeneration || connected || connecting || scanning) return;
            connectKnown(true);
        };
        main.postDelayed(reconnectTask, delay);
    }
    private void cancelReconnect() {
        if (reconnectTask != null) main.removeCallbacks(reconnectTask);
        reconnectTask = null;
    }
    private void releaseGatt() {
        connectionGeneration++;
        if (connectionTimeout != null) main.removeCallbacks(connectionTimeout);
        connectionTimeout = null;
        BluetoothGatt old = gatt; gatt = null; pressCharacteristic = null;
        connected = false; connecting = false; currentName = "";
        if (old != null) {
            try { old.disconnect(); } catch (SecurityException | IllegalStateException ignored) { }
            try { old.close(); } catch (RuntimeException ignored) { }
        }
    }

    /** Pure Java protocol parsing, independently testable without an Android device. */
    static final class Protocol {
        private static final Pattern PRESS = Pattern.compile("PRESS:([0-9a-fA-F]{8}):([1-9][0-9]{0,4})");
        private static final Pattern ADDRESS = Pattern.compile("[0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5}");
        static boolean validAddress(String address) { return address != null && ADDRESS.matcher(address).matches(); }
        static String requestIdFromPayload(String address, byte[] value) {
            if (!validAddress(address) || value == null || value.length < 16 || value.length > 20) return null;
            Matcher matcher = PRESS.matcher(new String(value, StandardCharsets.US_ASCII));
            if (!matcher.matches()) return null;
            return "ble:" + address.replace(":", "").toLowerCase(Locale.US) + ":" + matcher.group(1).toLowerCase(Locale.US) + ":" + matcher.group(2);
        }
    }
    /** Three attempts per outage, with a budget reset only after a minute of stable subscription. */
    static final class ReconnectPolicy {
        private static final long[] DELAYS = {2000, 5000, 15000};
        private int attempts;
        private long subscribedAt = -1;
        void reset() { attempts = 0; subscribedAt = -1; }
        void onSubscribed(long now) { subscribedAt = now; }
        long nextDelay(long now) {
            if (subscribedAt >= 0 && now >= subscribedAt && now - subscribedAt >= 60000) attempts = 0;
            subscribedAt = -1;
            return attempts < DELAYS.length ? DELAYS[attempts++] : -1;
        }
        int attempts() { return attempts; }
    }
    static final class SeenPresses {
        private final LinkedHashMap<String, Boolean> recent = new LinkedHashMap<>();
        boolean accept(String id) {
            if (recent.containsKey(id)) return false;
            recent.put(id, Boolean.TRUE);
            if (recent.size() > 128) recent.remove(recent.keySet().iterator().next());
            return true;
        }
        void clear() { recent.clear(); }
    }
}
