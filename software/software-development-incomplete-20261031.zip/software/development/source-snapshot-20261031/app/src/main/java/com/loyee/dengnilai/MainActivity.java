package com.loyee.dengnilai;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int CREAM = Color.rgb(247, 244, 236), INK = Color.rgb(39, 58, 45), GREEN = Color.rgb(83, 120, 94), MUTED = Color.rgb(110, 120, 109);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final ExecutorService PIN_WORKER = Executors.newSingleThreadExecutor();
    private SessionStore store;
    private ParentGate parentGate;
    private AlertDialog pinDialog;
    private ScrollView scroll;
    private LinearLayout content;
    private TextView waitingTime;
    private boolean startAfterPermission;
    private boolean resumed, pendingStopRequest;
    private boolean initialized, updatesRegistered;
    private String pendingBluetoothAction, pendingBluetoothAddress;
    private final BroadcastReceiver updates = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { render(); }
    };
    private final Runnable clock = new Runnable() {
        @Override public void run() { updateWaitingTime(); handler.postDelayed(this, 1000); }
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (!AgreementStore.isAccepted(this)) { openAgreement(getIntent()); return; }
        store = SessionStore.get(this); parentGate = ParentGate.get(this);
        readParentStopIntent(getIntent());
        getWindow().setStatusBarColor(CREAM); getWindow().setNavigationBarColor(CREAM);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        scroll = new ScrollView(this); scroll.setBackgroundColor(CREAM); scroll.setFillViewport(true);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(18), dp(22), dp(32));
        scroll.addView(content); setContentView(scroll);
        if (Build.VERSION.SDK_INT >= 30) scroll.setOnApplyWindowInsetsListener((view, insets) -> {
            android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
            scroll.setPadding(bars.left, bars.top, bars.right, bars.bottom); return insets;
        });
        initialized = true;
        render();
    }
    private void openAgreement(Intent incoming) {
        Intent agreement = new Intent(this, AgreementActivity.class);
        if (incoming != null && incoming.getAction() != null) agreement.putExtra(AgreementActivity.EXTRA_NEXT_ACTION, incoming.getAction());
        startActivity(agreement); finish();
    }
    @Override protected void onStart() {
        super.onStart();
        if (!initialized) return;
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(updates, new IntentFilter(HelpService.CHANGED), Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(updates, new IntentFilter(HelpService.CHANGED));
        updatesRegistered = true;
        handler.post(clock);
    }
    @Override protected void onResume() {
        super.onResume();
        if (!initialized) return;
        if (!AgreementStore.isAccepted(this)) { openAgreement(getIntent()); return; }
        resumed = true;
        // This is a user-visible reopen, not a background launch after force-stop.
        if (store.state.isSessionActive() && !HelpService.running && parentGate.hasPin()) resumeReceiving();
        render();
        if (pendingStopRequest) { pendingStopRequest = false; requestParentStop(); }
        else if (store.state.isSessionActive() && !HelpService.running && !parentGate.hasPin()) showSetPin(this::startSession);
    }
    @Override protected void onPause() {
        resumed = false;
        // Leaving the password screen cancels its pending UI action, including a verified Stop.
        if (pinDialog != null) pinDialog.dismiss();
        super.onPause();
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (!initialized || !AgreementStore.isAccepted(this)) { openAgreement(intent); return; }
        setIntent(intent); readParentStopIntent(intent);
        if (resumed && pendingStopRequest) { pendingStopRequest = false; requestParentStop(); }
    }
    private void readParentStopIntent(Intent intent) {
        if (intent != null && ParentGate.REQUEST_STOP.equals(intent.getAction())) {
            pendingStopRequest = true;
            intent.setAction(null);
        }
    }
    @Override protected void onStop() {
        if (initialized && store.state.isSessionActive() && BleButtonClient.isScanning()) act(HelpService.BLE_STOP_SCAN);
        handler.removeCallbacks(clock);
        if (updatesRegistered) { unregisterReceiver(updates); updatesRegistered = false; }
        super.onStop();
    }
    @Override protected void onDestroy() {
        if (pinDialog != null) pinDialog.dismiss();
        super.onDestroy();
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this); view.setText(value); view.setTextSize(size); view.setTextColor(color);
        view.setLineSpacing(dp(3), 1); view.setFontFeatureSettings("kern");
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }
    private void space(LinearLayout parent, int height) { parent.addView(new View(this), new LinearLayout.LayoutParams(1, dp(height))); }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable(); drawable.setColor(color); drawable.setCornerRadius(dp(radius)); return drawable;
    }
    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20)); card.setBackground(background(Color.WHITE, 24));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2); params.bottomMargin = dp(14);
        content.addView(card, params); return card;
    }
    private Button button(String value, boolean primary, Runnable action) {
        Button view = new Button(this); view.setAllCaps(false); view.setText(value); view.setTextSize(16);
        view.setTextColor(primary ? Color.WHITE : GREEN);
        view.setBackground(background(primary ? GREEN : Color.rgb(235, 241, 232), 14));
        view.setMinHeight(dp(50)); view.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(52)); params.topMargin = dp(10); view.setLayoutParams(params);
        view.setOnClickListener(ignored -> action.run()); return view;
    }
    private void act(String action) {
        if (HelpService.STOP.equals(action)) { requestParentStop(); return; }
        try { startService(new Intent(this, HelpService.class).setAction(action)); }
        catch (RuntimeException denied) { Toast.makeText(this, "请先开始作业陪伴，再试一次", Toast.LENGTH_LONG).show(); }
    }
    private void startSession() {
        if (!parentGate.hasPin()) { showSetPin(this::startSession); return; }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !store.preferences.getBoolean("notification_asked", false)) {
            startAfterPermission = true; askNotifications(); return;
        }
        resumeReceiving();
    }
    private void resumeReceiving() {
        try { startForegroundService(new Intent(this, HelpService.class).setAction(HelpService.START)); }
        catch (RuntimeException denied) { Toast.makeText(this, "暂时无法开始陪伴，请稍后重试", Toast.LENGTH_LONG).show(); }
    }

    private void showSetPin(Runnable afterSaved) {
        showPinDialog("设置家长密码", "请设置 6 位数字密码。结束陪伴和修改密码时需要验证，没有默认密码。",
            new String[]{"输入 6 位数字密码", "再次输入密码"}, "保存密码", false,
            values -> parentGate.configurePin(values[0], values[1]), result -> {
                Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show(); render(); afterSaved.run();
            });
    }
    private void showChangePin() {
        showPinDialog("修改家长密码", "先验证旧密码，再设置新密码。",
            new String[]{"旧密码", "新密码（6 位数字）", "再次输入新密码"}, "确认修改", false,
            values -> parentGate.changePin(values[0], values[1], values[2]), result -> {
                Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show(); render();
            });
    }
    private void requestParentStop() {
        if (!store.state.isSessionActive()) { Toast.makeText(this, "当前没有进行中的陪伴", Toast.LENGTH_SHORT).show(); return; }
        if (!parentGate.hasPin()) { showSetPin(this::requestParentStop); return; }
        final long sessionStartedAt = store.state.sessionStartedAt;
        showPinDialog("结束本次陪伴", "请输入家长设置的 6 位数字密码。取消或密码错误会继续陪伴。",
            new String[]{"家长密码"}, "验证并结束", true,
            values -> parentGate.authorizeStop(values[0], sessionStartedAt), result -> {
                if (!store.state.isSessionActive() || store.state.sessionStartedAt != sessionStartedAt) {
                    parentGate.revokeStopAuthorization(result.authorizationToken);
                    Toast.makeText(this, "陪伴已经变化，请重新操作", Toast.LENGTH_SHORT).show(); return;
                }
                try {
                    startService(new Intent(this, HelpService.class).setAction(HelpService.STOP)
                        .putExtra(ParentGate.EXTRA_STOP_AUTH, result.authorizationToken));
                } catch (RuntimeException error) {
                    parentGate.revokeStopAuthorization(result.authorizationToken);
                    Toast.makeText(this, "暂时无法结束，请重新验证", Toast.LENGTH_LONG).show();
                }
            });
    }
    private interface PinOperation { ParentGate.Result run(String[] values); }
    private interface PinSuccess { void run(ParentGate.Result result); }
    private void showPinDialog(String title, String description, String[] hints, String positive,
            boolean cancelWhileBusy, PinOperation operation, PinSuccess success) {
        if (pinDialog != null && pinDialog.isShowing()) return;
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(12), dp(24), dp(8));
        form.addView(text(description, 14, MUTED, false));
        EditText[] fields = new EditText[hints.length];
        for (int i = 0; i < hints.length; i++) {
            EditText field = new EditText(this); field.setHint(hints[i]); field.setTextSize(18);
            field.setSingleLine(true); field.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            field.setTransformationMethod(PasswordTransformationMethod.getInstance());
            field.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
            field.setSaveEnabled(false); field.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
            fields[i] = field; form.addView(field, new LinearLayout.LayoutParams(-1, dp(56)));
        }
        TextView message = text("", 13, Color.rgb(157, 52, 43), false); form.addView(message);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(title).setView(form)
            .setNegativeButton("取消", (ignored, which) -> { }).setPositiveButton(positive, null).create();
        pinDialog = dialog;
        dialog.setOnDismissListener(ignored -> {
            for (EditText field : fields) field.setText("");
            if (pinDialog == dialog) pinDialog = null;
        });
        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
                String[] values = new String[fields.length];
                for (int i = 0; i < fields.length; i++) {
                    values[i] = fields[i].getText().toString(); fields[i].setText(""); fields[i].setEnabled(false);
                }
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setEnabled(cancelWhileBusy);
                dialog.setCancelable(cancelWhileBusy); dialog.setCanceledOnTouchOutside(false);
                message.setText("正在验证，请稍候…");
                PIN_WORKER.execute(() -> {
                    ParentGate.Result result;
                    try { result = operation.run(values); }
                    catch (RuntimeException error) { result = ParentGate.Result.error("暂时无法验证，请稍后重试"); }
                    finally { Arrays.fill(values, ""); }
                    final ParentGate.Result answer = result;
                    runOnUiThread(() -> {
                        if (!resumed || isFinishing() || isDestroyed() || pinDialog != dialog || !dialog.isShowing()) {
                            if (!answer.authorizationToken.isEmpty()) parentGate.revokeStopAuthorization(answer.authorizationToken);
                            return;
                        }
                        for (EditText field : fields) field.setEnabled(true);
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setEnabled(true); dialog.setCancelable(true);
                        if (answer.success) { dialog.dismiss(); success.run(answer); }
                        else { message.setText(answer.message); fields[0].requestFocus(); }
                    });
                });
            });
            fields[0].requestFocus();
        });
        dialog.show();
    }
    private void askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && !store.preferences.getBoolean("notification_asked", false)) {
            store.preferences.edit().putBoolean("notification_asked", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 31);
        } else startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
    }
    private void bluetoothAction(String action, String address) {
        if (!store.state.isSessionActive()) {
            Toast.makeText(this, "请先开始作业陪伴", Toast.LENGTH_SHORT).show(); return;
        }
        if (HelpService.BLE_DISCONNECT.equals(action)) { act(action); return; }
        String[] needed = Build.VERSION.SDK_INT >= 31
            ? new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}
            : new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
        java.util.ArrayList<String> missing = new java.util.ArrayList<>();
        for (String permission : needed) if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) missing.add(permission);
        if (!missing.isEmpty()) {
            pendingBluetoothAction = action; pendingBluetoothAddress = address;
            requestPermissions(missing.toArray(new String[0]), 32); return;
        }
        BluetoothManager manager = getSystemService(BluetoothManager.class);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null || !getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, "这台手机不支持低功耗蓝牙", Toast.LENGTH_LONG).show(); return;
        }
        try {
            if (!adapter.isEnabled()) {
                pendingBluetoothAction = action; pendingBluetoothAddress = address;
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 33); return;
            }
            Intent command = new Intent(this, HelpService.class).setAction(action);
            if (address != null) command.putExtra("device_address", address);
            startService(command);
        } catch (RuntimeException error) {
            Toast.makeText(this, "蓝牙暂未就绪，请打开蓝牙后再试", Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 33) {
            String action = pendingBluetoothAction, address = pendingBluetoothAddress;
            pendingBluetoothAction = null; pendingBluetoothAddress = null;
            if (resultCode == RESULT_OK && action != null) bluetoothAction(action, address);
            else Toast.makeText(this, "打开蓝牙后，可再点搜索按钮", Toast.LENGTH_SHORT).show();
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] result) {
        super.onRequestPermissionsResult(requestCode, permissions, result);
        if (requestCode == 31 && startAfterPermission) { startAfterPermission = false; startSession(); }
        if (requestCode == 32) {
            boolean allowed = result.length > 0;
            for (int value : result) allowed &= value == PackageManager.PERMISSION_GRANTED;
            String action = pendingBluetoothAction, address = pendingBluetoothAddress;
            pendingBluetoothAction = null; pendingBluetoothAddress = null;
            if (allowed && action != null) bluetoothAction(action, address);
            else Toast.makeText(this, Build.VERSION.SDK_INT >= 31 ? "连接按钮需要允许附近设备权限；可在系统应用权限中开启" : "搜索按钮需要允许定位权限；可在系统应用权限中开启", Toast.LENGTH_LONG).show();
        }
        render();
    }

    private void render() {
        if (content == null) return;
        int scrollY = scroll.getScrollY(); content.removeAllViews(); waitingTime = null;
        LinearLayout heading = new LinearLayout(this); heading.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout words = new LinearLayout(this); words.setOrientation(LinearLayout.VERTICAL);
        words.addView(text("给孩子一个及时的回应", 13, MUTED, false));
        words.addView(text("拍拍小怪兽", 34, INK, true));
        heading.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
        heading.addView(new MascotView(this), new LinearLayout.LayoutParams(dp(96), dp(96)));
        content.addView(heading); space(content, 16);

        boolean active = store.state.isSessionActive();
        boolean receiving = active && HelpService.running;
        LinearLayout session = card();
        session.addView(text(active ? receiving ? "作业陪伴中" : "陪伴接收已暂停" : "今晚，一起把卡点解决", 22, INK, true));
        space(session, 8);
        session.addView(text(active ? receiving ? "接收服务正在运行，蓝牙连接状态见下方。" : "求助记录仍在本机，请恢复接收服务后继续。" : "先开始陪伴，再接收桌面求助器的提醒。", 14, MUTED, false));
        if (active && !receiving) session.addView(button("恢复作业陪伴", true, this::startSession));
        session.addView(button(active ? "结束本次陪伴" : "开始作业陪伴", !active, () -> { if (store.state.isSessionActive()) requestParentStop(); else startSession(); }));

        LinearLayout parent = card();
        parent.addView(text("家长结束密码", 18, INK, true));
        space(parent, 8);
        parent.addView(text(parentGate.hasPin() ? "已设置 6 位数字密码，结束陪伴时需要验证。" : "首次开始陪伴前，请设置并确认 6 位数字密码。", 13, MUTED, false));
        parent.addView(button(parentGate.hasPin() ? "修改家长密码" : "设置家长密码", false,
            () -> { if (parentGate.hasPin()) showChangePin(); else showSetPin(this::render); }));

        LinearLayout permissions = card();
        permissions.addView(text("让提醒找得到你", 18, INK, true));
        boolean notify = HelpService.helpNotificationsEnabled(this);
        boolean overlays = Settings.canDrawOverlays(this);
        space(permissions, 10);
        permissions.addView(text((notify ? "● 通知已开启" : "○ 通知尚未开启") + "\n" + (overlays ? "● 悬浮提醒已允许" : "○ 悬浮提醒尚未允许"), 14, MUTED, false));
        if (!notify) permissions.addView(button("开启通知", false, () -> askNotifications()));
        if (!overlays) permissions.addView(button("允许悬浮提醒", false, () -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())))));
        space(permissions, 10);
        permissions.addView(text(overlays ? "提醒会逐级放大；部分应用和系统页面可能限制显示。" : notify ? "当前会通过通知提醒。允许悬浮提醒后，才能在其他应用上方显示。" : "目前只能在本页查看求助；请开启通知或允许悬浮提醒。", 12, MUTED, false));
        space(permissions, 10);
        permissions.addView(text("切到抖音等其他 APP 前，请保持「作业陪伴中」。一键清理或强行停止会中断接收；红米可在应用设置中检查后台弹出与电池限制。", 12, MUTED, false));
        permissions.addView(button("检查后台运行设置", false, () -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())))));

        LinearLayout current = card();
        current.addView(text("当前求助", 18, INK, true));
        HelpState.Event event = store.state.current();
        if (event == null) {
            space(current, 10); current.addView(text("还没有待处理的求助", 20, INK, true));
            current.addView(text("孩子的每一次主动求助，都值得被听见。", 13, MUTED, false));
        } else {
            space(current, 10); current.addView(text(statusLabel(event.status), 23, INK, true));
            current.addView(text("第 " + event.count + " 次提醒 · 提醒等级 " + event.level + "/3", 15, GREEN, true));
            waitingTime = text("", 13, MUTED, false); current.addView(waitingTime); updateWaitingTime();
            space(current, 7); current.addView(text(deliveryLabel(store.state.lastDelivery), 12, MUTED, false));
            if (active && HelpState.WAITING.equals(event.status)) current.addView(button("收到，我来了", true, () -> act(HelpService.ACK)));
            if (active && event.unresolved()) current.addView(button("已经处理完成", false, () -> act(HelpService.COMPLETE)));
        }
        Button simulate = button("模拟按一下", true, () -> act(HelpService.HELP));
        simulate.setEnabled(receiving); simulate.setAlpha(receiving ? 1 : 0.45f); current.addView(simulate);
        space(current, 8); current.addView(text(active ? "再次按下会提醒同一件事，最多升至三级。" : "开始陪伴后，可先按这里体验。", 12, MUTED, false));

        LinearLayout connection = card();
        connection.addView(text("蓝牙桌面按钮", 18, INK, true)); space(connection, 8);
        connection.addView(text(active ? BleButtonClient.status() : "开始陪伴后，可连接 ESP32 按钮。", 14, MUTED, false));
        connection.addView(text("无需同一个 Wi-Fi。板子烧录配套程序后，搜索并选择 DengNiLai Button。", 12, MUTED, false));
        Button scanBluetooth = button(BleButtonClient.isScanning() ? "正在搜索蓝牙按钮…" : "搜索蓝牙按钮", true, () -> bluetoothAction(HelpService.BLE_SCAN, null));
        scanBluetooth.setEnabled(active && !BleButtonClient.isScanning() && !BleButtonClient.isConnected());
        scanBluetooth.setAlpha(scanBluetooth.isEnabled() ? 1 : 0.45f); connection.addView(scanBluetooth);
        for (BleButtonClient.FoundDevice device : BleButtonClient.devices()) {
            Button connect = button("连接 " + device.name, false, () -> bluetoothAction(HelpService.BLE_CONNECT, device.address));
            connect.setEnabled(active && !BleButtonClient.isConnected()); connection.addView(connect);
        }
        if (active && BleButtonClient.isConnected()) connection.addView(button("断开蓝牙按钮", false, () -> bluetoothAction(HelpService.BLE_DISCONNECT, null)));

        connection = card();
        connection.addView(text("Wi-Fi 连接（可选）", 18, INK, true)); space(connection, 8);
        if (active) {
            List<String> addresses = HelpService.localAddresses();
            connection.addView(text(store.connectionError.isEmpty() ? "手机与桌面设备连接同一个 Wi-Fi" : store.connectionError, 13, MUTED, false));
            TextView address = text(addresses.isEmpty() ? "暂未发现局域网地址，可先模拟按键" : join(addresses), 13, INK, false); address.setTextIsSelectable(true); connection.addView(address);
            space(connection, 8); connection.addView(text("本次配对码", 12, MUTED, false));
            TextView token = text(store.token, 15, GREEN, true); token.setTextIsSelectable(true); connection.addView(token);
            connection.addView(text("仅在本次陪伴期间接收求助。", 12, MUTED, false));
        } else connection.addView(text("开始陪伴后，会显示连接地址和本次配对码。", 13, MUTED, false));

        LinearLayout records = card();
        records.addView(text("本机求助记录", 18, INK, true));
        List<HelpState.Event> history = store.state.events();
        if (history.isEmpty()) { space(records, 10); records.addView(text("还没有记录，今晚从一次及时回应开始。", 13, MUTED, false)); }
        for (int index = history.size() - 1; index >= Math.max(0, history.size() - 8); index--) {
            HelpState.Event item = history.get(index); space(records, 15);
            records.addView(text(statusLabel(item.status) + "  ·  " + item.count + " 次提醒", 14, INK, true));
            StringBuilder detail = new StringBuilder("发起 ").append(time(item.startedAt));
            detail.append("\n提醒 ");
            for (int n = 0; n < item.reminderTimes.size(); n++) {
                if (n > 0) detail.append("、");
                if (n == 5) { detail.append("等 ").append(item.reminderTimes.size()).append(" 次"); break; }
                detail.append(time(item.reminderTimes.get(n)));
            }
            for (long response : item.responseTimes) detail.append("\n回应 ").append(time(response));
            if (item.completedAt > 0) detail.append("\n完成 ").append(time(item.completedAt));
            else if (item.closedAt > 0) detail.append("\n陪伴结束 ").append(time(item.closedAt)).append("（未标记完成）");
            records.addView(text(detail.toString(), 12, MUTED, false));
        }
        TextView footer = text("把提出问题的主动权，交还给孩子。\n记录仅保存在这部手机。", 12, MUTED, false);
        footer.setGravity(Gravity.CENTER); content.addView(footer);
        scroll.post(() -> scroll.scrollTo(0, scrollY));
    }
    private static String join(List<String> values) { StringBuilder result = new StringBuilder(); for (String value : values) { if (result.length() > 0) result.append('\n'); result.append(value); } return result.toString(); }
    private static String time(long value) { return new SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA).format(new Date(value)); }
    static String statusLabel(String status) {
        if (HelpState.WAITING.equals(status)) return "等待家长回应";
        if (HelpState.ACKNOWLEDGED.equals(status)) return "已回应，等待处理";
        if (HelpState.COMPLETED.equals(status)) return "已处理完成";
        return "陪伴已结束，未标记完成";
    }
    private static String deliveryLabel(String value) {
        if ("overlay_requested".equals(value)) return "已请求显示悬浮提醒，部分页面可能限制显示";
        if ("notification".equals(value)) return "已通过通知提醒，尚未显示跨应用悬浮卡";
        if ("app_only".equals(value)) return "当前仅在应用内可见，请开启提醒权限";
        if ("acknowledged".equals(value)) return "提醒已收起，处理后请标记完成";
        if ("completed".equals(value)) return "这次求助已经处理完成";
        return "";
    }
    private void updateWaitingTime() {
        if (waitingTime == null || store == null) return;
        HelpState.Event event = store.state.current(); if (event == null) return;
        long end = event.closedAt > 0 ? event.closedAt : !event.responseTimes.isEmpty() && HelpState.ACKNOWLEDGED.equals(event.status) ? event.responseTimes.get(event.responseTimes.size() - 1) : System.currentTimeMillis();
        long seconds = Math.max(0, (end - event.startedAt) / 1000);
        waitingTime.setText("发起于 " + new SimpleDateFormat("HH:mm:ss", Locale.CHINA).format(new Date(event.startedAt)) + " · " + (HelpState.WAITING.equals(event.status) ? "已等待 " : "已记录 ") + seconds / 60 + " 分 " + seconds % 60 + " 秒");
    }
}
