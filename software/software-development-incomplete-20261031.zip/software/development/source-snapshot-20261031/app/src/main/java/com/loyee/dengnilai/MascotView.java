package com.loyee.dengnilai;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** The original DengNiLai mascot, bundled locally for the app and reminders. */
final class MascotView extends View {
    private static Bitmap sharedMascot;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF destination = new RectF();
    private final Bitmap mascot;

    MascotView(Context context) {
        super(context);
        setContentDescription("拍拍小怪兽立体头像：奶白身体、大眼睛和绿色头顶按钮");
        synchronized (MascotView.class) {
            if (sharedMascot == null) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inScaled = false;
                options.inSampleSize = 2;
                sharedMascot = BitmapFactory.decodeResource(
                        context.getResources(), R.drawable.dengni_mascot_avatar, options);
            }
            mascot = sharedMascot;
        }
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mascot == null) return;
        int width = getWidth() - getPaddingLeft() - getPaddingRight();
        int height = getHeight() - getPaddingTop() - getPaddingBottom();
        if (width <= 0 || height <= 0) return;
        float scale = Math.min(width / (float) mascot.getWidth(),
                height / (float) mascot.getHeight());
        float drawnWidth = mascot.getWidth() * scale;
        float drawnHeight = mascot.getHeight() * scale;
        float left = getPaddingLeft() + (width - drawnWidth) / 2f;
        float top = getPaddingTop() + (height - drawnHeight) / 2f;
        destination.set(left, top, left + drawnWidth, top + drawnHeight);
        canvas.drawBitmap(mascot, null, destination, paint);
    }
}
