package com.loyee.dengnilai;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/** Local parent PIN credential plus short-lived, in-memory permission to end one session. */
final class ParentGate {
    static final String REQUEST_STOP = "com.loyee.dengnilai.REQUEST_PARENT_STOP";
    static final String EXTRA_STOP_AUTH = "com.loyee.dengnilai.STOP_AUTH";
    private static final String PIN_RECORD = "pin_record";
    private static ParentGate instance;
    private final Object lock = new Object();
    private final SharedPreferences preferences;
    private final AttemptPolicy attempts;
    private final StopGrants stopGrants = new StopGrants();
    private boolean verifying;

    static synchronized ParentGate get(Context context) {
        if (instance == null) instance = new ParentGate(context.getApplicationContext());
        return instance;
    }
    private ParentGate(Context context) {
        preferences = context.getSharedPreferences("parent_gate_v1", Context.MODE_PRIVATE);
        long elapsed = SystemClock.elapsedRealtime();
        long remaining = Math.max(0, Math.min(AttemptPolicy.LOCK_MS,
            preferences.getLong("blocked_until", 0) - System.currentTimeMillis()));
        attempts = new AttemptPolicy(preferences.getInt("failed_attempts", 0),
            remaining > 0 ? elapsed + remaining : 0, elapsed);
    }

    boolean hasPin() { return !preferences.getString(PIN_RECORD, "").isEmpty(); }

    static final class Result {
        final boolean success;
        final String message, authorizationToken;
        private final String verifiedRecord;
        private Result(boolean success, String message, String token, String record) {
            this.success = success; this.message = message;
            authorizationToken = token; verifiedRecord = record;
        }
        static Result error(String message) { return new Result(false, message, "", ""); }
        private static Result ok(String message) { return new Result(true, message, "", ""); }
    }

    /** Called on the authentication worker, never on the UI thread. */
    Result configurePin(String pin, String confirmation) {
        if (!ParentPin.validPin(pin)) return Result.error("请设置 6 位数字密码");
        if (!pin.equals(confirmation)) return Result.error("两次密码不一致，请重新输入");
        if (hasPin()) return Result.error("已经设置过密码，请使用修改密码");
        try {
            String record = ParentPin.create(pin);
            synchronized (lock) {
                if (hasPin()) return Result.error("密码已设置，请使用修改密码");
                if (!preferences.edit().putString(PIN_RECORD, record).commit()) return Result.error("密码未能保存，请重试");
                attempts.success(); persistAttempts(); stopGrants.clear();
            }
            return Result.ok("家长密码已设置");
        } catch (GeneralSecurityException error) { return Result.error("此设备暂时无法保存密码，请稍后重试"); }
    }

    /** Called on the authentication worker; verifying the old PIN is mandatory. */
    Result changePin(String oldPin, String newPin, String confirmation) {
        if (!ParentPin.validPin(newPin)) return Result.error("新密码需要 6 位数字");
        if (!newPin.equals(confirmation)) return Result.error("两次新密码不一致");
        Result verified = verifyPin(oldPin);
        if (!verified.success) return verified;
        try {
            String record = ParentPin.create(newPin);
            synchronized (lock) {
                if (!verified.verifiedRecord.equals(preferences.getString(PIN_RECORD, ""))) return Result.error("密码已发生变化，请重新验证");
                if (!preferences.edit().putString(PIN_RECORD, record).commit()) return Result.error("新密码未能保存，请重试");
                stopGrants.clear();
            }
            return Result.ok("家长密码已修改");
        } catch (GeneralSecurityException error) { return Result.error("此设备暂时无法保存密码，请稍后重试"); }
    }

    Result authorizeStop(String pin, long sessionStartedAt) {
        if (sessionStartedAt <= 0) return Result.error("这次陪伴已经变化，请返回后重试");
        Result verified = verifyPin(pin);
        if (!verified.success) return verified;
        synchronized (lock) {
            if (!verified.verifiedRecord.equals(preferences.getString(PIN_RECORD, ""))) return Result.error("密码已发生变化，请重新验证");
            String token = stopGrants.issue(sessionStartedAt, SystemClock.elapsedRealtime());
            return token == null ? Result.error("授权未能生成，请重试") : new Result(true, "验证通过", token, "");
        }
    }

    private Result verifyPin(String pin) {
        final String record;
        synchronized (lock) {
            long remaining = attempts.remaining(SystemClock.elapsedRealtime());
            if (remaining > 0) return Result.error("密码尝试过多，请 " + ((remaining + 999) / 1000) + " 秒后再试");
            if (verifying) return Result.error("正在验证，请稍候");
            record = preferences.getString(PIN_RECORD, "");
            if (record.isEmpty()) return Result.error("请先设置家长密码");
            verifying = true;
        }
        boolean matched;
        try { matched = ParentPin.verify(pin, record); }
        catch (GeneralSecurityException error) {
            synchronized (lock) { verifying = false; }
            return Result.error("此设备暂时无法验证密码，请稍后重试");
        }
        synchronized (lock) {
            verifying = false;
            if (!record.equals(preferences.getString(PIN_RECORD, ""))) return Result.error("密码已发生变化，请重新验证");
            if (matched) {
                attempts.success(); persistAttempts();
                return new Result(true, "验证通过", "", record);
            }
            attempts.failure(SystemClock.elapsedRealtime()); persistAttempts();
            long remaining = attempts.remaining(SystemClock.elapsedRealtime());
            return Result.error(remaining > 0 ? "密码错误，请 30 秒后再试" : "密码错误，请重新输入（还可尝试 " + (5 - attempts.failures()) + " 次）");
        }
    }

    boolean consumeStopAuthorization(String token, long sessionStartedAt) {
        synchronized (lock) {
            return hasPin() && stopGrants.consume(token, sessionStartedAt, SystemClock.elapsedRealtime());
        }
    }
    void revokeStopAuthorization(String token) { synchronized (lock) { stopGrants.revoke(token); } }
    private void persistAttempts() {
        long remaining = attempts.remaining(SystemClock.elapsedRealtime());
        preferences.edit().putInt("failed_attempts", attempts.failures())
            .putLong("blocked_until", remaining > 0 ? System.currentTimeMillis() + remaining : 0).commit();
    }

    /** Pure Java monotonic deadline; persisted remaining time is restored as at most one 30s interval. */
    static final class AttemptPolicy {
        static final long LOCK_MS = 30000;
        private int failed;
        private long blockedUntil;
        AttemptPolicy(int failures, long until, long now) {
            failed = Math.max(0, Math.min(4, failures));
            blockedUntil = until > now ? Math.min(until, now + LOCK_MS) : 0;
            if (until > 0 && until <= now) failed = 0;
        }
        long remaining(long now) {
            if (blockedUntil == 0) return 0;
            if (now >= blockedUntil) { success(); return 0; }
            return Math.min(LOCK_MS, blockedUntil - now);
        }
        void failure(long now) {
            if (remaining(now) > 0) return;
            failed++;
            if (failed >= 5) { failed = 0; blockedUntil = now + LOCK_MS; }
        }
        void success() { failed = 0; blockedUntil = 0; }
        int failures() { return failed; }
        long blockedUntil() { return blockedUntil; }
    }

    /** One random grant, one session, one consumption; grants are never persisted or logged. */
    static final class StopGrants {
        static final long TTL_MS = 30000;
        private final SecureRandom random = new SecureRandom();
        private String token = "";
        private long session, issuedAt, expiresAt;
        String issue(long sessionStartedAt, long now) {
            clear();
            if (sessionStartedAt <= 0 || now < 0 || now > Long.MAX_VALUE - TTL_MS) return null;
            byte[] bytes = new byte[32]; random.nextBytes(bytes);
            token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
            session = sessionStartedAt; issuedAt = now; expiresAt = now + TTL_MS;
            return token;
        }
        boolean consume(String candidate, long sessionStartedAt, long now) {
            if (!matches(candidate)) return false;
            boolean allowed = session == sessionStartedAt && now >= issuedAt && now < expiresAt;
            clear();
            return allowed;
        }
        void revoke(String candidate) { if (matches(candidate)) clear(); }
        private boolean matches(String candidate) {
            return candidate != null && candidate.length() == 43 && !token.isEmpty()
                && MessageDigest.isEqual(token.getBytes(StandardCharsets.US_ASCII), candidate.getBytes(StandardCharsets.US_ASCII));
        }
        void clear() { token = ""; session = 0; issuedAt = 0; expiresAt = 0; }
    }
}
