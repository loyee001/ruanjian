package com.loyee.dengnilai;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Versioned local PIN verifier. All expensive calls belong on a worker thread. */
final class ParentPin {
    private static final String VERSION = "v1";
    private static final int ITERATIONS = 120000;
    private static final int SALT_BYTES = 16;
    private static final int HASH_BITS = 256;
    private static final int HASH_BYTES = HASH_BITS / 8;
    private static final int MAX_ENCODED_LENGTH = 128;
    private static final SecureRandom RANDOM = new SecureRandom();

    private ParentPin() {}

    static boolean validPin(String pin) {
        if (pin == null || pin.length() != 6) return false;
        for (int i = 0; i < pin.length(); i++) {
            char digit = pin.charAt(i);
            if (digit < '0' || digit > '9') return false;
        }
        return true;
    }

    static String create(String pin) throws GeneralSecurityException {
        if (!validPin(pin)) throw new IllegalArgumentException("PIN must contain six ASCII digits");
        byte[] salt = new byte[SALT_BYTES];
        byte[] hash = null;
        try {
            RANDOM.nextBytes(salt);
            hash = derive(pin, salt);
            Base64.Encoder encoder = Base64.getEncoder();
            return VERSION + "$" + ITERATIONS + "$" + encoder.encodeToString(salt)
                    + "$" + encoder.encodeToString(hash);
        } finally {
            Arrays.fill(salt, (byte) 0);
            if (hash != null) Arrays.fill(hash, (byte) 0);
        }
    }

    static boolean verify(String pin, String encoded) throws GeneralSecurityException {
        if (!validPin(pin) || encoded == null || encoded.length() > MAX_ENCODED_LENGTH) return false;
        String[] fields = encoded.split("\\$", -1);
        // Version 1 has one fixed work factor; malformed metadata cannot raise the cost.
        if (fields.length != 4 || !VERSION.equals(fields[0])
                || !Integer.toString(ITERATIONS).equals(fields[1])
                || fields[2].length() != 24 || fields[3].length() != 44) return false;

        byte[] salt = null;
        byte[] expected = null;
        byte[] actual = null;
        try {
            try {
                Base64.Decoder decoder = Base64.getDecoder();
                salt = decoder.decode(fields[2]);
                expected = decoder.decode(fields[3]);
            } catch (IllegalArgumentException malformed) {
                return false;
            }
            if (salt.length != SALT_BYTES || expected.length != HASH_BYTES) return false;
            Base64.Encoder encoder = Base64.getEncoder();
            if (!encoder.encodeToString(salt).equals(fields[2])
                    || !encoder.encodeToString(expected).equals(fields[3])) return false;
            actual = derive(pin, salt);
            return MessageDigest.isEqual(expected, actual);
        } finally {
            if (salt != null) Arrays.fill(salt, (byte) 0);
            if (expected != null) Arrays.fill(expected, (byte) 0);
            if (actual != null) Arrays.fill(actual, (byte) 0);
        }
    }

    private static byte[] derive(String pin, byte[] salt) throws GeneralSecurityException {
        char[] password = pin.toCharArray();
        PBEKeySpec specification = new PBEKeySpec(password, salt, ITERATIONS, HASH_BITS);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(specification).getEncoded();
        } finally {
            specification.clearPassword();
            Arrays.fill(password, '\0');
        }
    }
}
