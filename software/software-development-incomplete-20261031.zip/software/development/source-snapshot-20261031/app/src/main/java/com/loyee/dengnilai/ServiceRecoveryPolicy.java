package com.loyee.dengnilai;

/** Pure Java decisions shared by persisted session restoration and bounded BLE recovery. */
final class ServiceRecoveryPolicy {
    private ServiceRecoveryPolicy() { }

    static boolean canRestoreSession(boolean active, boolean requested, String token) {
        return active && requested && token != null && token.matches("[0-9a-fA-F]{24}");
    }

    static boolean canReconnectButton(boolean active, boolean requested, String address) {
        return active && requested && address != null
            && address.matches("[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}");
    }
}
