package com.loyee.dengnilai;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Finger/stylus handwriting only; taps and tiny jitter never form a signature. */
final class SignatureView extends View {
    interface Listener { void onSignatureChanged(boolean valid); }

    private final Paint pen = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint decoration = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path ink = new Path();
    private final RectF bounds = new RectF();
    private Path current;
    private Listener listener;
    private float lastX, lastY, strokeLength, totalLength;
    private float minX, minY, maxX, maxY, strokeMinX, strokeMinY, strokeMaxX, strokeMaxY;
    private int segments, strokeSegments;
    private boolean hasInk;

    SignatureView(Context context) {
        super(context);
        setId(android.R.id.custom);
        setSaveEnabled(false);
        setFocusable(true);
        pen.setColor(Color.rgb(39, 58, 45));
        pen.setStyle(Paint.Style.STROKE);
        pen.setStrokeWidth(dp(2.8f));
        pen.setStrokeCap(Paint.Cap.ROUND);
        pen.setStrokeJoin(Paint.Join.ROUND);
        updateDescription();
    }

    void setSignatureListener(Listener listener) {
        this.listener = listener;
        notifyChanged();
    }

    void clearSignature() {
        ink.reset(); current = null;
        totalLength = 0; segments = 0; hasInk = false;
        releaseParent(); notifyChanged(); invalidate();
    }

    boolean hasValidSignature() {
        return current == null && hasInk && AgreementReadPolicy.substantialSignature(
                totalLength / density(), (maxX - minX) / density(), (maxY - minY) / density(), segments);
    }

    Bitmap signatureBitmap() {
        if (!hasValidSignature() || getWidth() <= 0 || getHeight() <= 0) return null;
        float scale = Math.min(1f, 1024f / Math.max(getWidth(), getHeight()));
        int width = Math.max(1, Math.round(getWidth() * scale));
        int height = Math.max(1, Math.round(getHeight() * scale));
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);
        canvas.scale(scale, scale);
        canvas.drawPath(ink, pen);
        return bitmap;
    }

    @Override public void setEnabled(boolean enabled) {
        if (!enabled) { current = null; releaseParent(); }
        super.setEnabled(enabled);
        updateDescription();
        invalidate();
    }

    @Override protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        super.onSizeChanged(width, height, oldWidth, oldHeight);
        if (oldWidth > 0 && oldHeight > 0 && (width != oldWidth || height != oldHeight)) clearSignature();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        bounds.set(dp(1), dp(1), getWidth() - dp(1), getHeight() - dp(1));
        decoration.setStyle(Paint.Style.FILL);
        decoration.setColor(isEnabled() ? Color.WHITE : Color.rgb(239, 240, 232));
        canvas.drawRoundRect(bounds, dp(16), dp(16), decoration);
        decoration.setStyle(Paint.Style.STROKE);
        decoration.setStrokeWidth(dp(1));
        decoration.setColor(isEnabled() ? Color.rgb(162, 184, 160) : Color.rgb(207, 213, 201));
        canvas.drawRoundRect(bounds, dp(16), dp(16), decoration);
        if (!hasInk && current == null) {
            decoration.setStyle(Paint.Style.FILL);
            decoration.setTextSize(dp(16));
            decoration.setTextAlign(Paint.Align.CENTER);
            decoration.setColor(Color.rgb(131, 145, 130));
            canvas.drawText(isEnabled() ? "在这里手写签名" : "阅读完成后即可签名",
                    getWidth() / 2f, getHeight() / 2f, decoration);
        }
        canvas.save();
        canvas.clipRect(dp(7), dp(7), getWidth() - dp(7), getHeight() - dp(7));
        canvas.drawPath(ink, pen);
        if (current != null) canvas.drawPath(current, pen);
        canvas.restore();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled()) return false;
        if (event.getPointerCount() > 1) {
            current = null; releaseParent(); notifyChanged(); invalidate(); return true;
        }
        float x = clamp(event.getX(), dp(9), getWidth() - dp(9));
        float y = clamp(event.getY(), dp(9), getHeight() - dp(9));
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                current = new Path(); current.moveTo(x, y);
                lastX = x; lastY = y; strokeLength = 0; strokeSegments = 0;
                strokeMinX = strokeMaxX = x; strokeMinY = strokeMaxY = y;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                notifyChanged(); invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                if (current == null) return true;
                for (int h = 0; h < event.getHistorySize(); h++) {
                    append(clamp(event.getHistoricalX(h), dp(9), getWidth() - dp(9)),
                            clamp(event.getHistoricalY(h), dp(9), getHeight() - dp(9)));
                }
                append(x, y); invalidate(); return true;
            case MotionEvent.ACTION_UP:
                if (current != null) {
                    append(x, y);
                    if (strokeSegments > 0) {
                        ink.addPath(current);
                        totalLength += strokeLength; segments += strokeSegments;
                        if (!hasInk) { minX = strokeMinX; maxX = strokeMaxX; minY = strokeMinY; maxY = strokeMaxY; }
                        else {
                            minX = Math.min(minX, strokeMinX); maxX = Math.max(maxX, strokeMaxX);
                            minY = Math.min(minY, strokeMinY); maxY = Math.max(maxY, strokeMaxY);
                        }
                        hasInk = true;
                    }
                    current = null;
                }
                releaseParent(); notifyChanged(); invalidate(); performClick(); return true;
            case MotionEvent.ACTION_CANCEL:
                current = null; releaseParent(); notifyChanged(); invalidate(); return true;
            default:
                return true;
        }
    }

    @Override public boolean performClick() {
        // Accessibility clicks preserve click semantics; they never add ink.
        super.performClick(); return true;
    }

    private void append(float x, float y) {
        float length = (float) Math.hypot(x - lastX, y - lastY);
        if (length < dp(.2f)) return;
        current.lineTo(x, y); strokeLength += length; strokeSegments++;
        strokeMinX = Math.min(strokeMinX, x); strokeMaxX = Math.max(strokeMaxX, x);
        strokeMinY = Math.min(strokeMinY, y); strokeMaxY = Math.max(strokeMaxY, y);
        lastX = x; lastY = y;
    }

    private void notifyChanged() {
        updateDescription();
        if (listener != null) listener.onSignatureChanged(hasValidSignature());
    }

    private void updateDescription() {
        setContentDescription(!isEnabled() ? "手写签名画布；阅读满 10 秒后启用"
                : hasValidSignature() ? "手写签名画布；签名有效" : "手写签名画布；请手写签名");
    }

    private void releaseParent() {
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
    }
    private float density() { return getResources().getDisplayMetrics().density; }
    private float dp(float value) { return value * density(); }
    private static float clamp(float value, float min, float max) { return Math.max(min, Math.min(max, value)); }
}
