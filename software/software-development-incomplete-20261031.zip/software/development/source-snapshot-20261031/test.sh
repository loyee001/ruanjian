#!/bin/bash
# Compile and run the project's JVM policy/protocol checks without installing an APK.
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
SDK_DIR="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/Library/Android/sdk}}"
JDK_DIR="${DENG_NI_LAI_JDK:-${JAVA_HOME:-/Library/Java/JavaVirtualMachines/jdk-17.jdk/Contents/Home}}"
PLATFORM_JAR="$SDK_DIR/platforms/android-35/android.jar"
BUILD_DIR="$PROJECT_DIR/build/unit-tests"
mkdir -p "$BUILD_DIR"
SOURCE_DIR="$PROJECT_DIR/app/src/main/java/com/loyee/dengnilai"
"$JDK_DIR/bin/javac" -encoding UTF-8 -cp "$PLATFORM_JAR" -d "$BUILD_DIR" \
  "$SOURCE_DIR/HelpState.java" "$SOURCE_DIR/BleButtonClient.java" \
  "$SOURCE_DIR/ServiceRecoveryPolicy.java" "$SOURCE_DIR/ParentPin.java" \
  "$SOURCE_DIR/ParentGate.java" "$SOURCE_DIR/AgreementReadPolicy.java" \
  "$PROJECT_DIR/tests/HelpStateTest.java" "$PROJECT_DIR/tests/BleProtocolTest.java" \
  "$PROJECT_DIR/tests/ServiceRecoveryPolicyTest.java" "$PROJECT_DIR/tests/ParentPinTest.java" \
  "$PROJECT_DIR/tests/ParentGateTest.java" "$PROJECT_DIR/tests/AgreementReadPolicyTest.java"
for TEST_CLASS in HelpStateTest BleProtocolTest ServiceRecoveryPolicyTest ParentPinTest ParentGateTest AgreementReadPolicyTest; do
  "$JDK_DIR/bin/java" -cp "$BUILD_DIR:$PLATFORM_JAR" "com.loyee.dengnilai.$TEST_CLASS"
done
