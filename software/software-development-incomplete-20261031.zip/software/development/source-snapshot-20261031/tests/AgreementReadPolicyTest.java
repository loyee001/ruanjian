package com.loyee.dengnilai;

/** JVM-only boundaries for the same reading/signature policy used by the UI. */
public final class AgreementReadPolicyTest {
    private static int passed;
    private static void check(boolean value, String description) {
        if (!value) throw new AssertionError(description);
        passed++;
    }

    public static void main(String[] arguments) {
        AgreementReadPolicy policy = new AgreementReadPolicy(0);
        check(policy.readMillis(100000) == 0, "time before foreground is not credited");
        check(!policy.canSign(100000) && !policy.canConfirm(100000), "fresh page is locked");
        policy.resume(1000);
        check(policy.readMillis(1000) == 0, "resume itself gives no credit");
        check(policy.readMillis(5999) == 4999, "foreground time accumulates");
        policy.resume(5000);
        check(policy.readMillis(6000) == 5000, "duplicate resume cannot reset timer");
        policy.pause(6000);
        check(policy.readMillis(1000000) == 5000, "background time gives no credit");
        check(!policy.canSign(1000000), "background wait cannot unlock signing");
        policy.setSignatureValid(true, 1000000);
        check(!policy.canConfirm(1000000), "early signature cannot enable confirmation");
        policy.resume(1000000);
        check(!policy.canSign(1004999), "9999 ms is still locked");
        check(policy.canSign(1005000), "exactly ten seconds unlocks signing");
        check(!policy.canConfirm(1005000), "elapsed time alone is insufficient");
        policy.setSignatureValid(true, 1005000);
        check(policy.canConfirm(1005000), "ten seconds plus valid signature permits confirmation");
        policy.setSignatureValid(false, 1005001);
        check(!policy.canConfirm(1005001), "clearing signature locks confirmation again");
        check(policy.readMillis(Long.MAX_VALUE) == 10000, "elapsed time saturates safely");

        AgreementReadPolicy beforeRotation = new AgreementReadPolicy(0);
        beforeRotation.resume(100);
        long saved = beforeRotation.readMillis(3777);
        AgreementReadPolicy afterRotation = new AgreementReadPolicy(saved);
        check(saved == 3677 && afterRotation.readMillis(100000) == 3677, "rotation restores only credited time");
        afterRotation.resume(100000);
        check(!afterRotation.canSign(106322) && afterRotation.canSign(106323), "remaining time after rotation is exact");
        check(!afterRotation.canConfirm(106323), "rotation does not restore a signature");
        afterRotation.pause(106323);
        afterRotation.pause(200000);
        check(afterRotation.readMillis(300000) == 10000, "repeated pause cannot add time");

        AgreementReadPolicy backwards = new AgreementReadPolicy(2000);
        backwards.resume(10000);
        check(backwards.readMillis(9999) == 2000, "backward clock gives no credit");
        backwards.pause(9999);
        check(backwards.readMillis(99999) == 2000, "backward pause ends the segment safely");
        AgreementReadPolicy invalidRestore = new AgreementReadPolicy(-1);
        invalidRestore.resume(-1);
        check(invalidRestore.readMillis(99999) == 0, "invalid saved/start time cannot unlock");
        check(new AgreementReadPolicy(Long.MAX_VALUE).readMillis(0) == 10000, "restored elapsed value is bounded");

        check(!AgreementReadPolicy.substantialSignature(0, 0, 0, 0), "single point rejected");
        check(!AgreementReadPolicy.substantialSignature(100, 3, 3, 100), "repeated tiny scribble rejected");
        check(!AgreementReadPolicy.substantialSignature(35.999f, 30, 10, 2), "short stroke rejected below length boundary");
        check(!AgreementReadPolicy.substantialSignature(36, 23.999f, 0, 1), "small extent rejected below boundary");
        check(AgreementReadPolicy.substantialSignature(36, 24, 0, 1), "meaningful single continuous stroke accepted");
        check(AgreementReadPolicy.substantialSignature(60, 20, 20, 10), "diagonal handwritten strokes accepted");
        check(!AgreementReadPolicy.substantialSignature(60, 25, 10, 0), "no pen segment rejected");
        check(!AgreementReadPolicy.substantialSignature(Float.NaN, 25, 10, 1), "NaN length rejected");
        check(!AgreementReadPolicy.substantialSignature(Float.POSITIVE_INFINITY, 25, 10, 1), "infinite length rejected");
        check(!AgreementReadPolicy.substantialSignature(60, Float.NaN, 10, 1), "NaN width rejected");
        check(!AgreementReadPolicy.substantialSignature(60, 25, Float.POSITIVE_INFINITY, 1), "infinite height rejected");
        check(!AgreementReadPolicy.substantialSignature(60, -25, 10, 1), "negative bounds rejected");
        System.out.println("AgreementReadPolicyTest: " + passed + " passed");
    }
}
