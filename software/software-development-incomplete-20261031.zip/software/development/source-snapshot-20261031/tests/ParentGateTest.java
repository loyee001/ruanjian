package com.loyee.dengnilai;

/** JVM tests of the same grant and throttling policies used by ParentGate. */
public final class ParentGateTest {
    private static int passed;
    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        passed++;
    }
    public static void main(String[] args) {
        ParentGate.AttemptPolicy attempts = new ParentGate.AttemptPolicy(0, 0, 1000);
        check(attempts.remaining(1000) == 0, "fresh credential is not blocked");
        for (int i = 1; i <= 4; i++) {
            attempts.failure(1000 + i);
            check(attempts.failures() == i && attempts.remaining(1000 + i) == 0, "first four failures remain bounded");
        }
        attempts.failure(1005);
        check(attempts.remaining(1005) == 30000, "fifth failure starts 30 second lock");
        check(attempts.remaining(31004) == 1, "lock remains active just before deadline");
        attempts.failure(2000);
        check(attempts.remaining(2000) == 29005, "attempt during lock cannot extend deadline");
        check(attempts.remaining(31005) == 0 && attempts.failures() == 0, "lock expires exactly at deadline");
        attempts.failure(31006);
        check(attempts.failures() == 1, "attempt after lock gets a fresh budget");
        attempts.success();
        check(attempts.failures() == 0 && attempts.remaining(31006) == 0, "success resets failures");
        ParentGate.AttemptPolicy restored = new ParentGate.AttemptPolicy(4, 0, 0);
        restored.failure(1);
        check(restored.remaining(1) == 30000, "four persisted failures survive process restart");
        ParentGate.AttemptPolicy blocked = new ParentGate.AttemptPolicy(0, 9000000, 10);
        check(blocked.remaining(10) == 30000 && blocked.remaining(30010) == 0, "restored lock is capped to one interval");
        ParentGate.AttemptPolicy expired = new ParentGate.AttemptPolicy(4, 50, 100);
        check(expired.failures() == 0 && expired.remaining(100) == 0, "expired persisted lock clears old failures");

        ParentGate.StopGrants grants = new ParentGate.StopGrants();
        check(!grants.consume(null, 111, 0), "missing authorization cannot stop");
        check(!grants.consume("", 111, 0), "empty authorization cannot stop");
        check(grants.issue(0, 0) == null, "inactive session cannot receive grant");
        String first = grants.issue(111, 1000);
        check(first != null && first.length() == 43, "grant has 256 random bits in URL-safe encoding");
        check(!grants.consume("incorrect", 111, 1001), "forged authorization rejected");
        check(!grants.consume("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 111, 1001), "plausible forged token rejected");
        check(grants.consume(first, 111, 1002), "correct token authorizes matching session");
        check(!grants.consume(first, 111, 1003), "authorization can only be used once");
        String oldSession = grants.issue(111, 2000);
        check(!grants.consume(oldSession, 222, 2001), "old authorization cannot stop a new session");
        check(!grants.consume(oldSession, 111, 2002), "matched but wrong-session grant is consumed");
        String expiring = grants.issue(111, 3000);
        check(!grants.consume(expiring, 111, 33000), "authorization expires after 30 seconds");
        String rollback = grants.issue(111, 4000);
        check(!grants.consume(rollback, 111, 3999), "clock reversal cannot activate a grant");
        String replaced = grants.issue(111, 5000);
        String latest = grants.issue(111, 5001);
        check(!replaced.equals(latest), "new authorization uses fresh randomness");
        check(!grants.consume(replaced, 111, 5002), "new grant invalidates previous authorization");
        check(grants.consume(latest, 111, 5003), "latest grant remains usable after rejected old token");
        String canceled = grants.issue(111, 6000);
        grants.revoke(canceled);
        check(!grants.consume(canceled, 111, 6001), "canceling verification revokes unconsumed authorization");
        String beforeRestart = grants.issue(111, 7000);
        ParentGate.StopGrants newProcess = new ParentGate.StopGrants();
        check(!newProcess.consume(beforeRestart, 111, 7001), "authorization does not survive process restart");
        grants.clear();
        check(!grants.consume(beforeRestart, 111, 7001), "password change can revoke outstanding authorization");
        check(grants.issue(111, Long.MAX_VALUE) == null, "overflow cannot produce a valid deadline");
        System.out.println("ParentGateTest: " + passed + " passed");
    }
}
