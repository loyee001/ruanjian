package com.loyee.dengnilai;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** JVM-only checks for real derivation, random salts, and strict input parsing. */
public final class ParentPinTest {
    private static int passed;

    private static void check(boolean condition, String description) {
        if (!condition) throw new AssertionError(description);
        passed++;
    }

    public static void main(String[] arguments) throws Exception {
        String pin = "074193";
        check(ParentPin.validPin(pin), "leading zero is valid");
        check(ParentPin.validPin("000000"), "all six ASCII digits are valid");
        check(ParentPin.validPin("999999"), "upper digit boundary is valid");
        String[] invalidPins = {null, "", "12345", "1234567", " 123456", "123456 ",
                "12345\n", "12345a", "12345\0", "１２３４５６", "١٢٣٤٥٦", "१२३४५६", "12345😀"};
        for (String invalid : invalidPins) {
            check(!ParentPin.validPin(invalid), "invalid PIN rejected");
            boolean rejected = false;
            try {
                ParentPin.create(invalid);
            } catch (IllegalArgumentException expected) {
                rejected = true;
            }
            check(rejected, "create rejects invalid PIN");
        }

        String encoded = ParentPin.create(pin);
        String second = ParentPin.create(pin);
        check(ParentPin.verify(pin, encoded), "correct PIN verifies");
        check(!ParentPin.verify("074194", encoded), "wrong PIN fails");
        check(!ParentPin.verify("741930", encoded), "another wrong PIN fails");
        check(ParentPin.verify(pin, second), "second random salt still verifies");
        check(!encoded.equals(second), "same PIN receives distinct random salts");
        String[] parts = encoded.split("\\$", -1);
        check(parts.length == 4 && "v1".equals(parts[0]) && "120000".equals(parts[1]),
                "encoding records version and exact work factor");
        check(!parts[2].equals(second.split("\\$", -1)[2]), "salt is generated for each verifier");
        byte[] saltBytes = Base64.getDecoder().decode(parts[2]);
        check(saltBytes.length == 16, "salt has sixteen bytes");
        byte[] hash = Base64.getDecoder().decode(parts[3]);
        check(hash.length == 32, "derived hash has 256 bits");
        check(!parts[2].equals(Base64.getEncoder().encodeToString(pin.getBytes(StandardCharsets.US_ASCII)))
                && !parts[3].equals(Base64.getEncoder().encodeToString(pin.getBytes(StandardCharsets.US_ASCII))),
                "stored fields do not contain raw PIN bytes");

        PBEKeySpec reference = new PBEKeySpec(pin.toCharArray(), saltBytes, 120000, 256);
        try {
            byte[] expected = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(reference).getEncoded();
            check(java.util.Arrays.equals(hash, expected), "independent PBKDF2 derivation agrees");
        } finally {
            reference.clearPassword();
        }
        for (String invalid : invalidPins) check(!ParentPin.verify(invalid, encoded), "verify rejects invalid PIN");

        String zeroSalt = Base64.getEncoder().encodeToString(new byte[16]);
        String zeroHash = Base64.getEncoder().encodeToString(new byte[32]);
        String salt = parts[2];
        String digest = parts[3];
        String[] corrupt = {null, "", "v1", "v1$120000", encoded + "$extra", "$" + encoded,
                encoded + "\n", encoded + " ", encoded.replace("v1$", "v2$"),
                "v1$0$" + salt + "$" + digest,
                "v1$1$" + salt + "$" + digest,
                "v1$-120000$" + salt + "$" + digest,
                "v1$0120000$" + salt + "$" + digest,
                "v1$120001$" + salt + "$" + digest,
                "v1$2147483647$" + salt + "$" + digest,
                "v1$99999999999999999999999999999999$" + salt + "$" + digest,
                "v1$１２0000$" + salt + "$" + digest,
                "v1$120000$$" + digest,
                "v1$120000$" + salt + "$",
                "v1$120000$!" + salt.substring(1) + "$" + digest,
                "v1$120000$" + salt + "$!" + digest.substring(1),
                "v1$120000$" + salt.substring(0, 22) + "$" + digest,
                "v1$120000$" + salt + "$" + digest.substring(0, 43),
                "v1$120000$" + Base64.getEncoder().encodeToString(new byte[17]) + "$" + digest,
                "v1$120000$" + salt + "$" + Base64.getEncoder().encodeToString(new byte[33]),
                "v1$120000$" + zeroSalt.substring(0, 21) + "B==$" + zeroHash,
                "v1$120000$" + zeroSalt + "$" + zeroHash.substring(0, 42) + "B=",
                new String(new char[4096]).replace('\0', 'a')};
        for (String invalid : corrupt) check(!ParentPin.verify(pin, invalid), "corrupt verifier fails safely");

        byte[] changedSalt = Base64.getDecoder().decode(parts[2]);
        changedSalt[0] ^= 1;
        check(!ParentPin.verify(pin, "v1$120000$" + Base64.getEncoder().encodeToString(changedSalt)
                + "$" + digest), "changed salt fails");
        byte[] changedHash = Base64.getDecoder().decode(parts[3]);
        changedHash[0] ^= 1;
        check(!ParentPin.verify(pin, "v1$120000$" + salt + "$"
                + Base64.getEncoder().encodeToString(changedHash)), "changed hash fails");
        System.out.println("ParentPinTest: " + passed + " passed");
    }
}
