package com.loyee.dengnilai;

/** JVM-only checks for the recovery decisions actually used by the service and BLE client. */
public final class ServiceRecoveryPolicyTest {
    private static int passed;
    private static void check(boolean condition, String description) {
        if (!condition) throw new AssertionError(description);
        passed++;
    }
    public static void main(String[] args) {
        String token = "aabbccddeeff001122334455";
        check(ServiceRecoveryPolicy.canRestoreSession(true, true, token), "explicit active session restores");
        check(!ServiceRecoveryPolicy.canRestoreSession(false, true, token), "stopped session does not restore");
        check(!ServiceRecoveryPolicy.canRestoreSession(true, false, token), "missing restore intent stays stopped");
        check(!ServiceRecoveryPolicy.canRestoreSession(true, true, null), "null token does not restore");
        check(!ServiceRecoveryPolicy.canRestoreSession(true, true, ""), "empty token does not restore");
        check(!ServiceRecoveryPolicy.canRestoreSession(true, true, "aabb"), "truncated token does not restore");
        check(!ServiceRecoveryPolicy.canRestoreSession(true, true, "zzbbccddeeff001122334455"), "corrupt token does not restore");

        String address = "AA:BB:CC:DD:EE:FF";
        check(ServiceRecoveryPolicy.canReconnectButton(true, true, address), "chosen device reconnects in active session");
        check(ServiceRecoveryPolicy.canReconnectButton(true, true, address.toLowerCase()), "saved lowercase MAC accepted");
        check(!ServiceRecoveryPolicy.canReconnectButton(false, true, address), "session end prevents reconnect");
        check(!ServiceRecoveryPolicy.canReconnectButton(true, false, address), "manual disconnect prevents reconnect");
        check(!ServiceRecoveryPolicy.canReconnectButton(true, true, null), "missing choice prevents reconnect");
        check(!ServiceRecoveryPolicy.canReconnectButton(true, true, "DengNiLai Button"), "name cannot substitute explicit address");

        BleButtonClient.ReconnectPolicy retry = new BleButtonClient.ReconnectPolicy();
        check(retry.nextDelay(0) == 2000, "first retry waits two seconds");
        check(retry.nextDelay(20000) == 5000, "second retry backs off");
        check(retry.nextDelay(40000) == 15000, "third retry backs off further");
        check(retry.nextDelay(60000) == -1, "fourth retry is forbidden");
        check(retry.nextDelay(3600000) == -1 && retry.attempts() == 3, "elapsed time alone cannot restart a failed loop");
        retry.onSubscribed(3600000);
        check(retry.nextDelay(3659999) == -1, "brief successful subscription cannot reset exhausted budget");
        retry.onSubscribed(4000000);
        check(retry.nextDelay(4060000) == 2000, "stable minute resets outage budget");
        retry.onSubscribed(4070000);
        check(retry.nextDelay(4060000) == 5000, "backward time cannot replenish budget");
        retry.reset();
        check(retry.nextDelay(0) == 2000 && retry.attempts() == 1, "new explicit choice starts a new budget");
        retry.onSubscribed(1);
        check(retry.nextDelay(2) == 5000, "connection flapping consumes existing budget");
        retry.onSubscribed(3);
        check(retry.nextDelay(4) == 15000, "repeated brief connections still consume budget");
        retry.onSubscribed(5);
        check(retry.nextDelay(6) == -1, "flapping cannot reconnect forever");

        HelpState state = new HelpState();
        state.begin(1000);
        state.request(2000, "ble:one");
        String eventId = state.current().id;
        state.begin(3000); // Same path used by an explicit Activity recovery of an active session.
        check(state.sessionStartedAt == 1000 && state.sessionEndedAt == 0, "recovery preserves original session times");
        check(eventId.equals(state.current().id) && state.current().count == 1, "recovery preserves one request and its count");
        check(!state.request(4000, "ble:one"), "recovery preserves request deduplication");
        state.acknowledge(5000);
        state.begin(6000);
        check(HelpState.ACKNOWLEDGED.equals(state.current().status), "recovery does not resurrect acknowledged overlay");
        state.end(7000);
        check(!ServiceRecoveryPolicy.canRestoreSession(state.isSessionActive(), true, token), "actual ended state blocks stale sticky restore");
        System.out.println("ServiceRecoveryPolicyTest: " + passed + " passed");
    }
}
