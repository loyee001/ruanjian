#!/usr/bin/env python3
"""Native V2 parent-PIN/background smoke checks on one explicit Android emulator.

The APK must already be installed by the operator. This script never installs,
clears data, grants permissions, changes appops, force-stops, or touches a phone.
Permission controls use the inherited normal Android Settings/runtime UI helpers.
Test PINs and pairing tokens remain in memory and are redacted from the report.
No unattended fallback taps unknown coordinates and no interactive input is used.
Agreement signing requires --accept-test-agreement and creates only fictional
fixture strokes on the explicitly selected emulator; it never signs for a person.
"""
import argparse
import datetime
import importlib.util
import json
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path


SPEC = importlib.util.spec_from_file_location(
    'v2_original_smoke', Path(__file__).with_name('emulator-smoke.py'))
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
PACKAGE = 'com.loyee.dengnilai'
COMPONENT = PACKAGE + '/.MainActivity'
STOP_INTENT = PACKAGE + '.REQUEST_PARENT_STOP'
FORWARD_PORT = 18746
APP_LABEL = '拍拍小怪兽'
APP_LABEL_ALIASES = (APP_LABEL, '等你来')
OVERLAY_TITLE = APP_LABEL + '求助提醒'
OVERLAY_TITLE_ALIASES = tuple(label + '求助提醒' for label in APP_LABEL_ALIASES)
AGREEMENT_TITLE = '君子协议'
AGREEMENT_TEXT = '使用本APP，请允许其获取所有权限（系统自动禁止的权限除外）'
AGREEMENT_PERMISSION_NOTE = '权限仍需在系统提示中逐项授权。'
AGREEMENT_COMPONENT = PACKAGE + '/.AgreementActivity'
SIGNATURE_DESCRIPTION_PREFIX = '手写签名画布'
SIGNATURE_LOCKED = '手写签名画布；阅读满 10 秒后启用'
SIGNATURE_EMPTY = '手写签名画布；请手写签名'
SIGNATURE_VALID = '手写签名画布；签名有效'
OLD.PACKAGE = PACKAGE
OLD.COMPONENT = COMPONENT
OLD.FORWARD_PORT = FORWARD_PORT
OLD.APP_LABEL_ALIASES = APP_LABEL_ALIASES
OLD.OVERLAY_TITLE_ALIASES = OVERLAY_TITLE_ALIASES

# Fixtures for this dedicated emulator only; never accept a person's real PIN.
PIN_INITIAL = '482691'
PIN_CHANGED = '739426'
PIN_WRONG = '105837'
PIN_BAD_CONFIRMATION = '482692'


class StageUnavailable(RuntimeError):
    """The environment did not provide evidence; this is never a passed test."""


class V2Smoke(OLD.Smoke):
    def __init__(self, serial, *, skip_overlay=False, skip_task_removal=False,
                 skip_pin_change=False, resume_test_pin=None,
                 accept_test_agreement=False, max_seconds=900):
        self.deadline = time.monotonic() + max_seconds
        self.started = time.monotonic()
        self.secrets = {PIN_INITIAL, PIN_CHANGED, PIN_WRONG, PIN_BAD_CONFIRMATION}
        super().__init__(serial, overlay_only=True, visual_ack=False)
        self.output = self.output.with_name(self.output.name + '-v2')
        self.output.mkdir(parents=True, exist_ok=True)
        self.skip_overlay = skip_overlay
        self.skip_task_removal = skip_task_removal
        self.skip_pin_change = skip_pin_change
        self.resume_test_pin = resume_test_pin
        self.accept_test_agreement = accept_test_agreement
        self.current_pin = PIN_CHANGED if resume_test_pin == 'changed' else PIN_INITIAL
        self.report['mode'] = 'v2-native-parent-pin-and-background'
        self.report['expected_brand'] = APP_LABEL
        self.report['brand_aliases_for_cached_settings_and_recents'] = list(APP_LABEL_ALIASES)
        self.report['sections'] = {}
        self.report['core_passed'] = False
        self.report['test_agreement_fixture_authorized'] = bool(accept_test_agreement)
        self.report['status'] = 'running'
        self.report['notification_end_entry_method'] = (
            'Explicit MainActivity REQUEST_PARENT_STOP intent through am start; '
            'the notification action itself is NOT clicked by this script.')
        self.report['limitations'] += [
            'No hardware BLE peripheral, phone/OEM restrictions, force-stop recovery, '
            'system memory reclamation, or reboot recovery is validated here.',
            'Only screenshot/window/UI evidence is collected; no human screenshot '
            'review is claimed by the script.',
            'Ordinary task removal is accepted only after a labelled native Recents '
            'card is dismissed and the same recent task IDs actually disappear.',
            'HTTP is used to trigger/inspect help and for explicit overlay cleanup; '
            'PIN setup, change, validation, cancellation, and session ending use native UI.',
            'Agreement fixture authorization applies only to fictional test strokes on '
            'this emulator. It is not the user\'s signature or acceptance on a physical phone.',
            'The foreground ten-second gate is observed through its native countdown '
            'and enabled states; background-pause timing is not separately validated.',
        ]

    def safe(self, value):
        if isinstance(value, dict):
            hidden = {'token', 'authorization_token', 'authorizationToken', 'pin_record'}
            return {key: self.safe(item) for key, item in value.items() if key not in hidden}
        if isinstance(value, (list, tuple)):
            return [self.safe(item) for item in value]
        if isinstance(value, str):
            for secret in sorted(self.secrets, key=len, reverse=True):
                if secret:
                    value = value.replace(secret, '[REDACTED]')
        return value

    def adb(self, *args, **kwargs):
        # This guard also covers calls inherited from Smoke/settings_switch.
        if not re.fullmatch(r'emulator-[0-9]+', self.serial):
            raise ValueError('Only explicit emulator-* serials are allowed.')
        forbidden = {'install', 'install-multiple', 'install-multi-package',
                     'uninstall', 'appops', 'force-stop'}
        if any(arg in forbidden for arg in args):
            raise ValueError('Forbidden emulator mutation in this smoke tool.')
        if args[:2] == ('shell', 'pm') and len(args) > 2 and args[2] in {
                'clear', 'grant', 'revoke', 'reset-permissions'}:
            raise ValueError('Permission/data shortcuts are forbidden.')
        if args[:3] == ('shell', 'cmd', 'package') and any(
                arg in {'clear', 'grant', 'revoke', 'install', 'uninstall'} for arg in args[3:]):
            raise ValueError('Permission/data shortcuts are forbidden.')
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('V2 smoke run reached its bounded time limit.')
        kwargs['timeout'] = max(.2, min(kwargs.get('timeout', 25), remaining))
        try:
            return super().adb(*args, **kwargs)
        except subprocess.TimeoutExpired as error:
            # TimeoutExpired.__str__ contains the entire command, possibly a test PIN.
            raise TimeoutError('An emulator command exceeded its bounded timeout.') from None

    def check(self, name, condition, evidence=None):
        return super().check(name, condition, self.safe(evidence))

    def preferences(self):
        try:
            return super().preferences()
        except RuntimeError as error:
            if 'No such file or directory' in str(error):
                return {'session_active': False, 'events': []}
            raise

    def pin_record(self):
        try:
            xml = self.shell('run-as', PACKAGE, 'cat', 'shared_prefs/parent_gate_v1.xml')
        except RuntimeError as error:
            if 'No such file or directory' in str(error):
                return ''
            raise
        root = ET.fromstring(xml)
        return next((node.text or '' for node in root if node.get('name') == 'pin_record'), '')

    def agreement_metadata(self):
        """Expose only acceptance metadata; do not retain hashes or load the PNG."""
        try:
            xml = self.shell('run-as', PACKAGE, 'cat',
                             'shared_prefs/deng_ni_lai_agreement.xml')
        except RuntimeError as error:
            if 'No such file or directory' in str(error):
                return {}
            raise
        values = {}
        for node in ET.fromstring(xml):
            key = node.get('name', '')
            if key in ('version', 'signed_at', 'read_millis'):
                try:
                    values[key] = int(node.get('value', node.text or '0'))
                except ValueError:
                    values[key] = 0
            elif key == 'agreement_text':
                values['exact_text_saved'] = (node.text or '') == AGREEMENT_TEXT
        return values

    def agreement_controls(self, tree=None):
        nodes = self.nodes(tree or self.ui())
        canvas = next((node for node in nodes
                       if node.get('resource-id') == 'android:id/custom'
                       and node.get('content-desc', '').startswith(SIGNATURE_DESCRIPTION_PREFIX)), None)
        confirm = next((node for node in nodes
                        if node.get('resource-id') == 'android:id/button1'
                        and node.get('text') == '签名并同意'), None)
        countdown = next((node.get('text', '') for node in nodes
                          if node.get('text', '').startswith('请先阅读，还需 ')), '')
        ready = any(node.get('text') == '已阅读 10 秒，可以签名' for node in nodes)
        return {'canvas': canvas, 'confirm': confirm, 'countdown': countdown, 'ready': ready}

    def draw_test_agreement_fixture(self):
        """Two fictional lines only, with explicit opt-in and live canvas identity."""
        if not self.accept_test_agreement:
            raise PermissionError('Test agreement strokes require --accept-test-agreement.')
        if not re.fullmatch(r'emulator-[0-9]+', self.serial) or PACKAGE != 'com.loyee.dengnilai':
            raise PermissionError('Agreement fixture signing is restricted to the fixed emulator test app.')
        component = self.resumed_component()
        if '.AgreementActivity' not in component or PACKAGE not in component:
            raise AssertionError('Refusing fixture strokes outside the actual AgreementActivity.')
        # The protocol page may scroll. Find the labelled custom canvas, then
        # use only its current visible bounds; never tap a prechosen screen point.
        controls = self.agreement_controls()
        width, height = self.screen_size()
        for _ in range(7):
            canvas = controls['canvas']
            bounds = self.bounds(canvas) if canvas is not None else None
            if bounds and bounds[2] - bounds[0] >= 100 and bounds[3] - bounds[1] >= 90:
                break
            self.shell('input', 'swipe', str(width // 2), str(int(height * .78)),
                       str(width // 2), str(int(height * .30)), '220')
            controls = self.agreement_controls()
        else:
            raise AssertionError('The labelled agreement signature canvas has no usable visible bounds.')
        canvas = controls['canvas']
        if (canvas.get('enabled') != 'true'
                or canvas.get('content-desc') != SIGNATURE_EMPTY):
            raise AssertionError('Refusing test strokes before the native signature canvas is enabled and empty.')
        x0, y0, x1, y1 = bounds
        if not (0 <= x0 < x1 <= width and 0 <= y0 < y1 <= height):
            raise AssertionError('Signature canvas bounds are outside the current measured display.')
        w, h = x1 - x0, y1 - y0
        strokes = [(.22, .43, .60, .63), (.36, .65, .75, .37)]
        for ax, ay, bx, by in strokes:
            self.shell('input', 'swipe', str(x0 + int(w * ax)), str(y0 + int(h * ay)),
                       str(x0 + int(w * bx)), str(y0 + int(h * by)), '360')
        self.report['agreement_fixture_input'] = {
            'type': 'two fictional straight test strokes; not a personal signature',
            'surface': 'live android:id/custom with hand-signature content description',
            'canvas_bounds': bounds, 'stroke_count': 2,
            'authorized_for': 'explicit emulator test run only',
        }

    def agreement_stage(self):
        launched_at = time.monotonic()
        # Do not call top()/scroll before the first countdown observation: doing
        # so could spend the complete ten-second reading period in test setup.
        self.shell('am', 'start', '-W', '--activity-clear-top', '--activity-single-top',
                   '-n', COMPONENT)
        tree = self.ui()
        labels = self.labels(tree)
        metadata = self.agreement_metadata()
        if AGREEMENT_TITLE not in labels:
            accepted = (metadata.get('version') == 1 and metadata.get('signed_at', 0) > 0
                        and metadata.get('read_millis', 0) >= 10000
                        and metadata.get('exact_text_saved') is True)
            self.check('a missing first-run agreement is backed by existing acceptance metadata', accepted)
            self.report['sections']['first_run_agreement'] = {
                'status': 'skipped', 'reason': 'Existing acceptance retained; no first-run agreement was signed or retested.'}
            return True
        nodes = self.nodes(tree)
        body = next((node.get('text', '') for node in nodes
                     if node.get('resource-id') == 'android:id/message'), None)
        self.check('first-run agreement shows the exact requested original text', body == AGREEMENT_TEXT)
        self.check('agreement explains system permissions still require individual authorization',
                   AGREEMENT_PERMISSION_NOTE in labels)
        self.check('agreement is shown before the PIN setup form',
                   not any(node.get('class') == 'android.widget.EditText' for node in nodes))
        controls = self.agreement_controls(tree)
        self.check('agreement exposes the labelled native signature canvas and confirm control',
                   controls['canvas'] is not None and controls['confirm'] is not None)
        countdown_match = re.fullmatch(r'请先阅读，还需 ([0-9]+) 秒', controls['countdown'])
        early_seconds = int(countdown_match.group(1)) if countdown_match else 0
        early_observed = 1 <= early_seconds <= 10
        early_at = time.monotonic()
        if early_observed:
            self.check('before ten foreground seconds both signing and confirmation are disabled',
                       controls['canvas'].get('enabled') == 'false'
                       and controls['canvas'].get('content-desc') == SIGNATURE_LOCKED
                       and controls['confirm'].get('enabled') == 'false',
                       {'countdown': controls['countdown'],
                        'observed_after_launch_s': round(time.monotonic() - launched_at, 3)})
        else:
            self.report['limitations'].append(
                'The initial disabled countdown was not observed; the app may already have '
                'accumulated foreground reading time. No fresh ten-second claim is made.')
        self.screenshot('agreement-original-text-and-reading-gate')

        def ready_controls():
            current = self.agreement_controls()
            canvas = current['canvas']
            return current if (current['ready'] and canvas is not None
                               and canvas.get('enabled') == 'true') else None

        controls = self.wait('ten-second native reading gate', ready_controls, timeout=22)
        ready_at = time.monotonic()
        if early_observed:
            self.check('the observed remaining foreground countdown does not unlock prematurely',
                       ready_at - early_at >= max(0, early_seconds - 1),
                       {'initial_remaining_seconds': early_seconds,
                        'observed_wait_seconds': round(ready_at - early_at, 3),
                        'reading_ready_after_launch_seconds': round(ready_at - launched_at, 3)})
        self.check('reading completion enables an empty signature canvas but cannot confirm yet',
                   controls['canvas'].get('content-desc') == SIGNATURE_EMPTY
                   and controls['confirm'] is not None
                   and controls['confirm'].get('enabled') == 'false')
        if not self.accept_test_agreement:
            self.report['sections']['first_run_agreement'] = {
                'status': 'unverified',
                'reason': 'No --accept-test-agreement authorization: no strokes or acceptance were submitted.',
                'early_disabled_gate_observed': early_observed}
            self.report['status'] = 'partial'
            return False
        self.draw_test_agreement_fixture()

        def valid_controls():
            current = self.agreement_controls()
            return current if (current['canvas'] is not None
                               and current['canvas'].get('content-desc') == SIGNATURE_VALID
                               and current['confirm'] is not None
                               and current['confirm'].get('enabled') == 'true') else None

        controls = self.wait('valid fictional fixture signature', valid_controls, timeout=10)
        self.check('two real UI fixture strokes produce the accessible valid-signature state', True)
        self.screenshot('agreement-fictional-test-strokes-valid')
        self.tap_node(controls['confirm'])
        self.wait('agreement confirms into the MainActivity',
                  lambda: '.MainActivity' in self.resumed_component()
                  and AGREEMENT_TITLE not in self.labels(), timeout=15)
        saved = self.agreement_metadata()
        self.check('test agreement acceptance durably records the exact text and ten read seconds',
                   saved.get('version') == 1 and saved.get('signed_at', 0) > 0
                   and saved.get('read_millis', 0) >= 10000
                   and saved.get('exact_text_saved') is True)
        self.report['sections']['first_run_agreement'] = {
            'status': 'passed' if early_observed else 'unverified',
            'early_disabled_gate_observed': early_observed,
            'fixture_accepted_on_explicit_test_emulator': True,
            'reason': 'Native first-run sequence observed.' if early_observed else
                      'Acceptance observed, but initial disabled countdown was not captured.'}
        return True

    def screenshot(self, name):
        # Even masked PIN input is omitted from artifacts. Empty hints are safe.
        hints = {'输入 6 位数字密码', '再次输入密码', '旧密码', '新密码（6 位数字）',
                 '再次输入新密码', '家长密码'}
        fields = [node for node in self.nodes(self.raw_ui())
                  if node.get('class') == 'android.widget.EditText']
        if any(node.get('text', '') and node.get('text', '') not in hints for node in fields):
            self.report['notes'].append('Screenshot omitted while a PIN field contained input: ' + name)
            return None
        return super().screenshot(name)

    def http(self, path, method='GET', payload=None, authenticated=True):
        headers = {'Content-Type': 'application/json'}
        if authenticated:
            headers['Authorization'] = 'Bearer ' + self.token
        body = None if method == 'GET' else json.dumps(payload or {}).encode('utf-8')
        request = urllib.request.Request(
            'http://127.0.0.1:' + str(FORWARD_PORT) + path,
            data=body, method=method, headers=headers)
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('V2 smoke run reached its bounded time limit.')
        try:
            with urllib.request.urlopen(request, timeout=min(2.5, remaining)) as response:
                return response.status, json.load(response)
        except urllib.error.HTTPError as error:
            return error.code, json.loads(error.read().decode('utf-8'))

    def wait(self, label, condition, timeout=12):
        end = min(self.deadline, time.monotonic() + timeout)
        while time.monotonic() < end:
            value = condition()
            if value:
                return value
            time.sleep(.2)
        raise AssertionError(label + ' did not become observable within its timeout.')

    def labels(self, tree=None):
        return [node.get('text', '') for node in self.nodes(tree or self.ui())]

    def has_text(self, value):
        return value in self.labels()

    def dialog_fields(self):
        return [node for node in self.nodes(self.ui())
                if node.get('class') == 'android.widget.EditText']

    def await_dialog(self, title):
        def visible():
            nodes = self.nodes(self.ui())
            return (any(node.get('class') == 'android.widget.EditText' for node in nodes)
                    and any(node.get('text') == title
                            and node.get('resource-id', '').endswith('/alertTitle') for node in nodes))
        self.wait('Native PIN dialog ' + title, visible)
        self.check('native PIN dialog shown: ' + title, True)

    def navigate(self, label):
        if self.tap_text(label, scroll='up', attempts=4):
            return
        if self.tap_text(label, scroll='down', attempts=10):
            return
        raise AssertionError('Native control unavailable: ' + label)

    def top(self):
        self.launch_app()
        # Scrolling uses measured screen dimensions, never a guessed control tap.
        width, height = self.screen_size()
        for _ in range(4):
            self.shell('input', 'swipe', str(width // 2), str(int(height * .27)),
                       str(width // 2), str(int(height * .80)), '160')

    def fill_and_submit(self, values, positive):
        fields = self.dialog_fields()
        self.check('PIN form has expected number of native inputs', len(fields) == len(values))
        fields.sort(key=lambda node: int(re.findall(r'\d+', node.get('bounds', ''))[1]))
        for node, value in zip(fields, values):
            # Fields are new or cleared by the app before each attempt.
            # Never log the command/value or take screenshots during entry.
            self.tap_node(node)
            self.shell('input', 'text', value)
        ime = self.shell('dumpsys', 'input_method')
        if re.search(r'(?:mInputShown|mIsInputViewShown)\s*=\s*true', ime):
            self.shell('input', 'keyevent', 'KEYCODE_BACK')
        self.check('native PIN submit control exists', self.tap_text(positive, attempts=2))

    def wait_pin_error(self, marker='密码错误'):
        return self.wait('PIN rejection message', lambda: next(
            # The Stop-dialog explanation itself mentions "密码错误". Only
            # the application's dedicated error message starts with it.
            (text for text in self.labels() if text.startswith(marker)), None), timeout=20)

    def cancel_dialog(self):
        self.check('native PIN Cancel control exists', self.tap_text('取消', attempts=2))
        self.wait('PIN dialog dismissal', lambda: not self.dialog_fields())

    def active_receiving(self):
        prefs = self.preferences()
        code, state = self.http('/state')
        return bool(prefs.get('session_active') and code == 200
                    and state.get('session_active') and state.get('receiver_running'))

    def connect_http(self):
        prefs = self.wait_preferences(True)
        self.token = prefs.get('token', '')
        self.secrets.add(self.token)
        self.check('active session has a valid pairing credential',
                   bool(re.fullmatch(r'[0-9a-f]{24}', self.token)))
        if not self.forwarded:
            self.adb('forward', 'tcp:' + str(FORWARD_PORT), 'tcp:8742')
            self.forwarded = True
        self.wait_http_ready()

    def allow_start_prompt(self, require_prompt):
        end = min(self.deadline, time.monotonic() + 22)
        seen = False
        while time.monotonic() < end:
            tree = self.ui()
            allow = next((node for node in self.nodes(tree)
                          if node.get('resource-id', '').endswith((
                              'permission_allow_button', 'permission_allow_foreground_only_button'))), None)
            if allow is not None:
                self.screenshot('normal-notification-permission-prompt')
                self.tap_node(allow)
                seen = True
                break
            if self.preferences().get('session_active'):
                break
            time.sleep(.2)
        if require_prompt:
            self.check('fresh API33 start shows normal notification runtime permission dialog', seen)
        elif not seen:
            self.report['limitations'].append(
                'Existing emulator permission history was preserved; the fresh notification prompt was not retested.')
        self.connect_http()
        self.check('notification permission is enabled after the native start flow',
                   self.state().get('notifications_enabled') is True)

    def start_existing(self):
        self.top()
        if not self.preferences().get('session_active'):
            self.navigate('开始作业陪伴')
            self.allow_start_prompt(require_prompt=False)
        else:
            self.connect_http()

    def setup_initial_pin(self):
        self.top()
        if self.pin_record():
            if not self.resume_test_pin:
                raise AssertionError(
                    'A parent credential already exists. Use a dedicated clean emulator '
                    'or explicitly --resume-test-pin for this script fixture; no reset was performed.')
            self.report['sections']['fresh_setup'] = {
                'status': 'skipped', 'reason': 'Explicit fixture resume; fresh setup is not claimed.'}
            self.start_existing()
            return
        self.check('clean emulator has no active learning session',
                   self.preferences().get('session_active') is False)
        self.current_pin = PIN_INITIAL
        self.navigate('开始作业陪伴')
        self.await_dialog('设置家长密码')
        self.check('initial Start waits for a self-chosen parent PIN',
                   not self.preferences().get('session_active') and not self.pin_record())
        self.screenshot('first-start-requires-parent-pin')
        self.fill_and_submit([PIN_INITIAL, PIN_BAD_CONFIRMATION], '保存密码')
        self.wait_pin_error('两次密码不一致')
        self.check('mismatched PIN confirmation neither saves a PIN nor starts reception',
                   not self.pin_record() and not self.preferences().get('session_active'))
        self.screenshot('mismatched-confirmation-rejected')
        self.fill_and_submit([PIN_INITIAL, PIN_INITIAL], '保存密码')
        self.allow_start_prompt(require_prompt=True)
        self.check('confirmed self-chosen PIN is durably configured', bool(self.pin_record()))
        self.report['sections']['fresh_setup'] = {'status': 'passed'}
        self.top(); self.screenshot('native-session-started')

    def open_stop(self):
        self.top(); self.navigate('结束本次陪伴')
        self.await_dialog('结束本次陪伴')

    def reject_and_cancel_stop(self, pin):
        self.open_stop()
        self.fill_and_submit([pin], '验证并结束')
        self.wait_pin_error()
        self.check('incorrect PIN leaves the active receiving service running', self.active_receiving())
        self.screenshot('wrong-stop-pin-rejected')
        self.cancel_dialog()
        self.check('cancelling the rejected PIN dialog keeps reception active', self.active_receiving())
        self.open_stop(); self.cancel_dialog()
        self.check('cancelling a fresh End dialog also keeps reception active', self.active_receiving())

    def notification_intent_entry(self):
        # This deliberately tests only the same Activity action, not the actual notification click.
        self.shell('am', 'start', '-W', '--activity-clear-top', '--activity-single-top',
                   '-a', STOP_INTENT, '-n', COMPONENT)
        self.await_dialog('结束本次陪伴')
        self.check('notification End Activity intent requires validation and does not stop directly',
                   self.active_receiving(), {'trigger': 'explicit Activity action intent; notification not clicked'})
        self.screenshot('notification-action-intent-requires-pin')
        self.cancel_dialog()
        self.check('cancelling notification-action validation keeps reception active', self.active_receiving())

    def wait_listener_closed(self, timeout=8):
        end = min(self.deadline, time.monotonic() + timeout)
        while time.monotonic() < end:
            try:
                self.http('/state')
            except (OSError, urllib.error.URLError):
                return True
            time.sleep(.2)
        return False

    def stop_using_ui(self):
        if not self.preferences().get('session_active'):
            return
        self.open_stop()
        self.fill_and_submit([self.current_pin], '验证并结束')
        self.wait_preferences(False, timeout=20)
        self.check('correct parent PIN ends the active learning session',
                   self.preferences().get('session_active') is False)
        if self.forwarded:
            self.check('correctly ending the session closes the HTTP listener', self.wait_listener_closed())
        self.top(); self.screenshot('session-ended-with-parent-pin')

    def change_pin(self):
        self.top(); self.navigate('修改家长密码')
        self.await_dialog('修改家长密码')
        previous = self.pin_record()
        target = PIN_CHANGED if self.current_pin == PIN_INITIAL else PIN_INITIAL
        self.fill_and_submit([PIN_WRONG, target, target], '确认修改')
        self.wait_pin_error()
        self.check('wrong old PIN cannot change the stored credential', self.pin_record() == previous)
        self.fill_and_submit([self.current_pin, target, target], '确认修改')
        self.wait('changed PIN durably stored', lambda: self.pin_record() != previous, timeout=25)
        old_pin = self.current_pin
        self.current_pin = target
        self.wait('successful change dismisses its PIN dialog', lambda: not self.dialog_fields(), timeout=15)
        self.check('correct old PIN permits a durable credential change', bool(self.pin_record()))
        self.top(); self.screenshot('parent-pin-changed')
        self.start_existing()
        self.reject_and_cancel_stop(old_pin)
        self.report['sections']['pin_change'] = {'status': 'passed'}

    def cleanup_help(self):
        if not self.token or not self.forwarded:
            return
        code, state = self.http('/state')
        event = state.get('current') if code == 200 else None
        if event and event.get('status') in ('waiting', 'acknowledged'):
            self.http('/ack', 'POST')
            self.http('/complete', 'POST')

    def overlay_stage(self):
        self.start_existing()
        self.cleanup_help()
        self.settings_switch('overlay', True)
        self.check('normal Settings UI enabled native overlay permission',
                   self.state().get('overlay_permission') is True)
        self.shell('input', 'keyevent', 'KEYCODE_HOME')
        resumed = self.resumed_component()
        self.check('Home launcher is actually resumed before background help',
                   'launcher' in resumed.lower(), {'resumed_activity': resumed})
        event_id = None
        for level in (1, 2, 3):
            state = self.post('/help', 'v2-background-' + str(time.monotonic_ns()))
            current = state['current']
            event_id = event_id or current['id']
            self.check('background press ' + str(level) + ' advances one existing event',
                       current['id'] == event_id and current['count'] == level
                       and current['level'] == level and state['last_delivery'] == 'overlay_requested')
            time.sleep(.4)
            self.overlay_evidence(level)
            self.check('background level ' + str(level) + ' uses the current branded reminder window',
                       OVERLAY_TITLE in self.shell('dumpsys', 'window', 'windows'))
        clicked = self.tap_text('收到，我来了', attempts=1)
        if clicked:
            self.check('available native overlay ACK records a response',
                       self.state()['current']['status'] == 'acknowledged')
        else:
            self.report['notes'].append(
                'Overlay ACK omitted by UIAutomator: no unknown coordinates were tapped; '
                'HTTP ACK is used only for cleanup and is not claimed as UI acceptance.')
        self.cleanup_help()
        windows = self.shell('dumpsys', 'window', 'windows')
        self.check('overlay cleanup removes the native reminder window',
                   not any(title in windows for title in OVERLAY_TITLE_ALIASES))

    def recent_app_tasks(self):
        dump = self.shell('dumpsys', 'activity', 'recents')
        blocks = re.split(r'(?m)^\s*\* Recent #\d+:', dump)[1:]
        found = []
        for block in blocks:
            header = block.splitlines()[0] if block.splitlines() else ''
            belongs = (re.search(r'\bA=(?:\d+:)?' + re.escape(PACKAGE) + r'(?:\s|\})', header)
                       or re.search(r'\brealActivity=' + re.escape(PACKAGE) + r'/', block))
            match = re.search(r'Task\{[^\n}]*?#(\d+)\b', header)
            if belongs and match:
                found.append({'task_id': int(match.group(1)), 'header': re.sub(r'\s+', ' ', header).strip()})
        return found

    @staticmethod
    def bounds(node):
        values = [int(value) for value in re.findall(r'\d+', node.get('bounds', ''))]
        return values if len(values) == 4 else None

    def dismiss_identified_recent_card(self):
        tree = self.ui()
        nodes = self.nodes(tree)
        width, height = self.screen_size()
        # Prefer an explicit accessibility dismiss action bearing this app's label.
        for node in nodes:
            label = node.get('content-desc', '') + ' ' + node.get('text', '')
            if any(brand in label for brand in APP_LABEL_ALIASES) and re.search(r'dismiss|close|remove|关闭|移除', label, re.I):
                self.tap_node(node)
                return {'method': 'labelled native Recents dismiss control',
                        'label': label, 'bounds': self.bounds(node)}
        # A normal overview swipe is allowed only within an app-labelled card,
        # discovered from the current accessibility tree and measured bounds.
        parents = {child: node for node in tree.iter() for child in node}
        candidates = []
        for node in nodes:
            label = node.get('content-desc', '') + ' ' + node.get('text', '')
            if not any(brand in label for brand in APP_LABEL_ALIASES):
                continue
            current = node
            while current is not None:
                bounds = self.bounds(current)
                if bounds:
                    x0, y0, x1, y1 = bounds
                    area = max(0, x1 - x0) * max(0, y1 - y0)
                    if width * height * .12 <= area <= width * height * .85 and x1 - x0 >= width * .35:
                        candidates.append((area, bounds, label, current.get('resource-id', '')))
                        break
                current = parents.get(current)
        if not candidates:
            raise StageUnavailable('No app-labelled Recents card/dismiss control was exposed; task removal is unverified.')
        _, bounds, label, resource = min(candidates, key=lambda item: item[0])
        x0, y0, x1, y1 = bounds
        x = (x0 + x1) // 2
        start_y = y0 + int((y1 - y0) * .68)
        end_y = max(20, y0 - int((y1 - y0) * .55))
        self.shell('input', 'swipe', str(x), str(start_y), str(x), str(end_y), '340')
        return {'method': 'normal upward swipe within the currently labelled native Recents card',
                'label': label, 'resource_id': resource, 'card_bounds': bounds}

    def task_removal_stage(self):
        self.start_existing(); self.cleanup_help(); self.top()
        before = self.recent_app_tasks()
        if not before:
            raise StageUnavailable('No recent task belonging to the fixed app was found before dismissal.')
        previous = self.preferences()
        self.shell('input', 'keyevent', 'KEYCODE_APP_SWITCH')
        time.sleep(.6)
        component = self.resumed_component()
        if not any(marker in component.lower() for marker in ('launcher', 'recents')):
            raise StageUnavailable('The actual native overview surface could not be confirmed.')
        self.screenshot('ordinary-task-before-recents-removal')
        action = self.dismiss_identified_recent_card()
        previous_ids = {task['task_id'] for task in before}
        end = min(self.deadline, time.monotonic() + 8)
        after = self.recent_app_tasks()
        while previous_ids & {task['task_id'] for task in after} and time.monotonic() < end:
            time.sleep(.3); after = self.recent_app_tasks()
        removed = not (previous_ids & {task['task_id'] for task in after})
        self.check('normal Recents dismissal actually removes the original app task IDs', removed,
                   {'before': before, 'after': after, 'ui_action': action})
        self.screenshot('ordinary-task-after-recents-removal')
        # Deliberately do not reopen the Activity before verifying reception.
        self.shell('input', 'keyevent', 'KEYCODE_HOME')
        self.check('ordinary task removal preserves the same active receiving session',
                   self.active_receiving()
                   and self.preferences().get('session_started_at') == previous.get('session_started_at')
                   and self.preferences().get('token') == previous.get('token'))
        state = self.post('/help', 'v2-after-task-removal-' + str(time.monotonic_ns()))
        self.check('a new help request is accepted while its Activity task remains removed',
                   state.get('accepted') is True and state['current']['status'] == 'waiting'
                   and not self.recent_app_tasks())
        self.screenshot('help-after-ordinary-task-removal')
        self.cleanup_help()

    def optional(self, name, skip, operation):
        if skip:
            self.report['sections'][name] = {'status': 'skipped', 'reason': 'Explicit command-line skip.'}
            return
        try:
            operation()
            self.report['sections'][name] = {'status': 'passed'}
        except Exception as error:
            status = 'unverified' if isinstance(error, StageUnavailable) else 'failed'
            self.report['sections'][name] = {'status': status, 'error': self.safe(type(error).__name__ + ': ' + str(error))}
            print('PARTIAL ' + name + ': ' + self.report['sections'][name]['error'], flush=True)
            try:
                self.screenshot(name + '-incomplete')
            except Exception:
                pass
            try:
                self.cleanup_help()
            except Exception:
                pass

    def run(self):
        self.check('fixed debug package is installed', 'package:' in self.shell('pm', 'path', PACKAGE))
        self.check('dedicated API33 emulator is used', self.api == 33)
        if not self.agreement_stage():
            return
        self.top()
        self.check('native V2 main screen displays the current brand', APP_LABEL in self.labels())
        self.setup_initial_pin()
        self.reject_and_cancel_stop(PIN_WRONG)
        self.notification_intent_entry()
        self.stop_using_ui()
        self.report['sections']['parent_stop_gate'] = {'status': 'passed'}
        self.report['core_passed'] = True
        if self.skip_pin_change:
            self.report['sections']['pin_change'] = {'status': 'skipped', 'reason': 'Explicit command-line skip.'}
        else:
            # Credential modification is a core security check: do not hide its failure
            # as an emulator overlay/environment skip.
            self.change_pin()
        self.start_existing()
        self.optional('background_overlays', self.skip_overlay, self.overlay_stage)
        self.optional('ordinary_task_removal', self.skip_task_removal, self.task_removal_stage)
        self.cleanup_help()
        self.stop_using_ui()
        statuses = [section['status'] for section in self.report['sections'].values()]
        self.report['passed'] = bool(statuses) and all(status == 'passed' for status in statuses)
        self.report['status'] = 'passed' if self.report['passed'] else 'partial'

    def finish(self):
        # Give bounded cleanup/report collection its own small allowance after a run timeout.
        self.deadline = time.monotonic() + 65
        if self.report.get('status') == 'running':
            self.report['status'] = 'failed'
        if not self.report['passed']:
            try:
                self.screenshot('v2-incomplete-screen')
            except Exception:
                pass
        try:
            # A cancelled/failed test must not leave an opaque overlay blocking inspection.
            self.cleanup_help()
        except Exception as error:
            self.report['notes'].append(self.safe('HTTP cleanup unavailable: ' + type(error).__name__))
        try:
            if self.preferences().get('session_active'):
                self.launch_app()
                if self.dialog_fields():
                    self.cancel_dialog()
                self.stop_using_ui()
            self.report['cleanup_session_stopped'] = not self.preferences().get('session_active')
        except Exception as error:
            self.report['cleanup_session_stopped'] = False
            self.report['notes'].append(self.safe('Native PIN cleanup incomplete: ' + type(error).__name__ + ': ' + str(error)))
        if self.forwarded:
            try:
                self.adb('forward', '--remove', 'tcp:' + str(FORWARD_PORT), check=False)
            except Exception:
                self.report['notes'].append('The emulator-only forwarding rule could not be removed.')
        self.report['elapsed_seconds'] = round(time.monotonic() - self.started, 2)
        result = self.output / 'result.json'
        result.write_text(json.dumps(self.safe(self.report), ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print('REPORT ' + str(result), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--serial', required=True, help='Explicit emulator-* serial; real phones are rejected')
    parser.add_argument('--skip-overlay', action='store_true', help='Mark cross-app overlay acceptance skipped')
    parser.add_argument('--skip-task-removal', action='store_true', help='Mark ordinary Recents task removal skipped')
    parser.add_argument('--skip-pin-change', action='store_true', help='Mark PIN modification acceptance skipped')
    parser.add_argument('--resume-test-pin', choices=('initial', 'changed'),
                        help='Explicitly resume this script fixture; does not claim fresh setup acceptance')
    parser.add_argument('--accept-test-agreement', action='store_true',
                        help='Authorize two fictional fixture strokes and agreement acceptance only on this explicit emulator run')
    parser.add_argument('--max-seconds', type=int, default=900, help='Bound the run to 60–1800 seconds, plus bounded cleanup')
    args = parser.parse_args()
    if not re.fullmatch(r'emulator-[0-9]+', args.serial):
        parser.error('--serial must be emulator-*; no physical-device operation is permitted')
    if not 60 <= args.max_seconds <= 1800:
        parser.error('--max-seconds must be between 60 and 1800')
    smoke = None
    try:
        smoke = V2Smoke(args.serial, skip_overlay=args.skip_overlay,
                        skip_task_removal=args.skip_task_removal, skip_pin_change=args.skip_pin_change,
                        resume_test_pin=args.resume_test_pin,
                        accept_test_agreement=args.accept_test_agreement, max_seconds=args.max_seconds)
        smoke.run()
    except Exception as error:
        message = type(error).__name__ + ': ' + str(error)
        if smoke is not None:
            message = smoke.safe(message)
            smoke.report['error'] = message
            smoke.report['status'] = 'failed'
        else:
            # Constructor errors must not expose a full subprocess command either.
            message = type(error).__name__ + ': emulator initialization did not complete'
        print('FAIL ' + message, file=sys.stderr, flush=True)
    finally:
        if smoke is not None:
            smoke.finish()
    if smoke is None or smoke.report['status'] == 'failed':
        return 1
    return 0 if smoke.report['passed'] else 2


if __name__ == '__main__':
    sys.exit(main())
