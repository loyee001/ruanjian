# 等你来 · Android 软件

桌面按钮通过 ESP32 BLE 向 Android 手机发起求助。手机把同一件未完成求助逐级提醒，记录回应和完成时间。支持真实蓝牙按钮及独立模拟演示。

## 下载已有调试安装包

| 安装包 | 包名 | 版本 |
| --- | --- | --- |
| [蓝牙原版](releases/0.2.1/deng-ni-lai-0.2.1-bluetooth.apk) | `com.loyee.dengnilai` | `0.2.1-bluetooth`，versionCode 3 |
| [独立模拟版](releases/0.2.1/deng-ni-lai-0.2.1-simulation.apk) | `com.loyee.dengnilai.simulation` | `0.2.1-simulation`，versionCode 3 |

最低 Android 8（API 26），目标 Android 15（API 35）。两个包均已检查包名、版本及 APK 签名；原版与模拟版可以分别安装和保存记录。

本目录主源码恢复自上述 0.2.1 构建的暂存副本。全部 10 个 `app/src/main/` 文件的 SHA-256 均与当时记录相符；记录的原版 APK 哈希也与下载包一致。见 [源码恢复校验](verification/stable-source-recovery.json)。主版和模拟版已在导出副本中重新编译、签名验证；对照结果见 [构建校验](verification/stable-build.json)。这不是另一次真机验收。

今晚正在开发的“拍拍小怪兽”密码/协议等改动单独保存在 [development/source-snapshot-20261031](development/source-snapshot-20261031/README.md)。该开发快照尚缺 `AgreementActivity`，不能直接完整编译，也不包含在这里的 0.2.1 安装包中。

## 使用

1. 安装对应 APK，开始作业陪伴；按系统提示允许通知、附近设备和悬浮提醒。
2. 搜索并选择 `DengNiLai Button`；成功订阅蓝牙通知后，再按实体按钮。
3. 连续按键会把同一件求助逐级放大。点“收到，我来了”记为回应，实际处理后再点完成。
4. 独立模拟版另有“5 秒后按一次”“5 秒后连续按 3 次”，可以先切到其他 APP 再看提醒。

悬浮窗受 Android 系统和其他应用限制，不能保证所有应用、系统页面、方向和手机均能显示。系统强制停止应用会结束接收，需要重新打开并开始陪伴。本次上传整理没有操作手机，也没有新增蓝牙或跨应用实测结论。

## 构建与测试

项目使用原生 Java / Android View。需要自行安装 **JDK 17、Android SDK Platform 35、Build Tools 35.0.0**。也提供 Android Gradle Plugin 8.6.0 项目配置；没有附带 Gradle wrapper、SDK、缓存或第三方依赖。

```sh
# 改成自己的工具安装路径。
export ANDROID_SDK_ROOT="$HOME/Library/Android/sdk"
export DENG_NI_LAI_JDK="/path/to/jdk-17"
bash test.sh
bash manual-build.sh
bash build-simulation.sh
```

`test.sh` 运行 19 条状态/去重检查和 30 条 BLE 协议检查。`manual-build.sh` 输出 `build/manual/deng-ni-lai-debug.apk`；独立模拟构建从暂存副本生成 `build/simulation/deng-ni-lai-simulation.apk`，不改原版源码。所有构建产物位于被 Git 忽略的 `build/`。

构建时会在自己的电脑生成调试签名密钥。本仓库未发布原开发者的密钥，所以自行构建的 APK 通常不能直接覆盖本目录已有签名的 APK；请自行管理安装方式和数据。

| 路径 | 内容 |
| --- | --- |
| `app/src/main/` | 0.2.1 原生界面、BLE、前台服务、悬浮提醒、状态与资源 |
| `tests/` | 对应稳定版本的 JVM 检查 |
| `simulation/` | 稳定版本的独立模拟构建补丁 |
| `tools/` | 可选模拟器和手机验收脚本；先阅读脚本说明，再明确指定测试设备 |
| `releases/0.2.1/` | 已有调试 APK |
| `verification/` | 本次整理的脱敏文件/编译校验结论 |
| `development/` | 最新未完成改动的独立源码快照 |
| `manifest.json` | 本目录发布文件大小和 SHA-256，清单不包含自身 |

## 硬件与接口

BLE 广播名 `DengNiLai Button`。BLE 不要求手机和按钮连接同一 Wi-Fi。ESP32 固件及实际接线见 [硬件仓库 loyee001/yingjian](https://github.com/loyee001/yingjian)。本软件目录不包含硬件编译工具链。

另外保留家庭局域网调试接口：开始陪伴后原版监听 TCP 8742，独立模拟版监听 8743；需要每次会话的配对令牌。`GET /state`、`POST /help`、`POST /ack`、`POST /complete` 对应观察、求助、回应、完成。HTTP 未加密，仅在可信家庭网络使用，不要将端口暴露到公网或上传实际配对令牌。

## 发布范围

未包含本机调试签名密钥、私钥、SDK、缓存、构建中间产物、手机截图、调试日志、实际设备标识、配对码、家长密码或使用记录。测试内的固定数字密码/MAC 地址是样例，不是使用者凭证。JVM 检查、编译和签名检查不能替代真实手机权限、蓝牙及界面验证。
