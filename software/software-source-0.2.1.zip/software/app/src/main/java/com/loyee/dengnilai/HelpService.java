package com.loyee.dengnilai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.content.Context;
import android.content.res.Configuration;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.RejectedExecutionException;
import org.json.JSONException;
import org.json.JSONObject;

public final class HelpService extends Service {
    public static final String START = "com.loyee.dengnilai.START";
    public static final String STOP = "com.loyee.dengnilai.STOP";
    public static final String HELP = "com.loyee.dengnilai.HELP";
    public static final String ACK = "com.loyee.dengnilai.ACK";
    public static final String COMPLETE = "com.loyee.dengnilai.COMPLETE";
    public static final String CHANGED = "com.loyee.dengnilai.CHANGED";
    public static final String BLE_SCAN = "com.loyee.dengnilai.BLE_SCAN";
    public static final String BLE_CONNECT = "com.loyee.dengnilai.BLE_CONNECT";
    public static final String BLE_DISCONNECT = "com.loyee.dengnilai.BLE_DISCONNECT";
    public static final String BLE_STOP_SCAN = "com.loyee.dengnilai.BLE_STOP_SCAN";
    public static final int PORT = 8742;
    private static final int SESSION_NOTIFICATION = 101, HELP_NOTIFICATION = 102;
    private static final String SESSION_CHANNEL = "companion_session_v1", HELP_CHANNEL = "child_help_v1";
    static boolean running;
    private final Handler main = new Handler(Looper.getMainLooper());
    private SessionStore store;
    private OverlayController overlay;
    private NotificationManager notifications;
    private BleButtonClient bluetooth;
    private volatile ServerSocket server;
    private final Object serverLock = new Object();
    private volatile boolean accepting;
    private volatile long serverEpoch;
    private ExecutorService connections;

    @Override public void onCreate() {
        super.onCreate();
        store = SessionStore.get(this);
        overlay = new OverlayController(this, () -> acknowledge());
        notifications = getSystemService(NotificationManager.class);
        bluetooth = new BleButtonClient(this, new BleButtonClient.Listener() {
            @Override public void onStateChanged() { changed(); }
            @Override public void onPress(String requestId) {
                if (store.state.isSessionActive()) request(requestId);
            }
        });
        NotificationChannel session = new NotificationChannel(SESSION_CHANNEL, "作业陪伴", NotificationManager.IMPORTANCE_LOW);
        session.setDescription("仅在你开始陪伴后保持桌面设备连接");
        NotificationChannel help = new NotificationChannel(HELP_CHANNEL, "孩子的求助", NotificationManager.IMPORTANCE_HIGH);
        help.setDescription("孩子按键时提醒，重复按键更新同一条求助");
        help.enableVibration(true);
        notifications.createNotificationChannel(session);
        notifications.createNotificationChannel(help);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "" : intent.getAction();
        if (START.equals(action)) {
            try {
                if (Build.VERSION.SDK_INT >= 29) startForeground(SESSION_NOTIFICATION, sessionNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
                else startForeground(SESSION_NOTIFICATION, sessionNotification());
                running = true;
                store.begin();
                startServer();
            } catch (RuntimeException error) {
                Log.e("DengNiLai", "Unable to start foreground companionship session", error);
                store.connectionError = "陪伴未能开始，请重新打开应用后再试";
                store.state.end(System.currentTimeMillis()); store.save();
                stopSelf();
            }
            changed();
        } else if (STOP.equals(action)) {
            endSession();
        } else if (store.state.isSessionActive()) {
            if (HELP.equals(action)) request(intent.getStringExtra("request_id"));
            else if (ACK.equals(action)) acknowledge();
            else if (COMPLETE.equals(action)) complete();
            else if (BLE_SCAN.equals(action)) bluetooth.scan();
            else if (BLE_CONNECT.equals(action)) bluetooth.connect(intent.getStringExtra("device_address"));
            else if (BLE_DISCONNECT.equals(action)) bluetooth.disconnect();
            else if (BLE_STOP_SCAN.equals(action)) bluetooth.pauseScan();
        } else {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private PendingIntent openApp() {
        return PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private PendingIntent action(String value, int code) {
        return PendingIntent.getService(this, code, new Intent(this, HelpService.class).setAction(value), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private Notification sessionNotification() {
        return new Notification.Builder(this, SESSION_CHANNEL).setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("等你来 · 作业陪伴中").setContentText("正在接收桌面设备的求助")
            .setContentIntent(openApp()).setOngoing(true).setCategory(Notification.CATEGORY_SERVICE)
            .addAction(new Notification.Action.Builder(null, "结束陪伴", action(STOP, 1)).build()).build();
    }
    private void helpNotification() {
        HelpState.Event event = store.state.current();
        if (event == null) return;
        boolean acknowledged = HelpState.ACKNOWLEDGED.equals(event.status);
        Notification.Builder builder = new Notification.Builder(this, acknowledged ? SESSION_CHANNEL : HELP_CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher).setContentTitle("孩子需要你 · 第 " + event.count + " 次提醒")
            .setContentText(HelpState.ACKNOWLEDGED.equals(event.status) ? "你已回应，等到桌边处理后点完成" : "有一个学习卡点，等你来一起解决")
            .setContentIntent(openApp()).setOnlyAlertOnce(false).setAutoCancel(false)
            .setCategory(Notification.CATEGORY_REMINDER).setVisibility(Notification.VISIBILITY_PRIVATE);
        if (HelpState.WAITING.equals(event.status)) builder.addAction(new Notification.Action.Builder(null, "收到，我来了", action(ACK, 2)).build());
        else builder.setOnlyAlertOnce(true).addAction(new Notification.Action.Builder(null, "已处理完成", action(COMPLETE, 3)).build());
        notifications.notify(HELP_NOTIFICATION, builder.build());
    }

    private boolean request(String requestId) {
        boolean accepted = store.state.request(System.currentTimeMillis(), requestId);
        if (accepted) {
            boolean displayed = Settings.canDrawOverlays(this) && overlay.show(store.state.current());
            store.state.lastDelivery = displayed ? "overlay_requested" : helpNotificationsEnabled(this) ? "notification" : "app_only";
            helpNotification(); store.save(); changed();
        }
        return accepted;
    }
    private void acknowledge() {
        if (store.state.acknowledge(System.currentTimeMillis())) {
            overlay.hide(); store.state.lastDelivery = "acknowledged";
            helpNotification(); store.save(); changed();
        }
    }
    private void complete() {
        if (store.state.complete(System.currentTimeMillis())) {
            overlay.hide(); notifications.cancel(HELP_NOTIFICATION);
            store.state.lastDelivery = "completed"; store.save(); changed();
        }
    }
    private void endSession() {
        bluetooth.close();
        overlay.hide(); closeServer();
        store.state.end(System.currentTimeMillis()); store.save();
        notifications.cancel(HELP_NOTIFICATION); stopForeground(STOP_FOREGROUND_REMOVE);
        running = false; changed(); stopSelf();
    }
    private void changed() { sendBroadcast(new Intent(CHANGED).setPackage(getPackageName())); }

    static boolean helpNotificationsEnabled(Context context) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        NotificationChannel channel = manager.getNotificationChannel(HELP_CHANNEL);
        return manager.areNotificationsEnabled() && (channel == null || channel.getImportance() != NotificationManager.IMPORTANCE_NONE);
    }

    static List<String> localAddresses() {
        List<String> addresses = new ArrayList<>();
        try {
            for (NetworkInterface face : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!face.isUp() || face.isLoopback()) continue;
                for (InetAddress address : Collections.list(face.getInetAddresses())) {
                    if (address instanceof Inet4Address && address.isSiteLocalAddress()) addresses.add("http://" + address.getHostAddress() + ":" + PORT);
                }
            }
        } catch (Exception ignored) { }
        return addresses;
    }

    private void startServer() {
        if (accepting) return;
        accepting = true;
        final long epoch = ++serverEpoch;
        final ExecutorService pool = new ThreadPoolExecutor(2, 2, 0L, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<Runnable>(8));
        connections = pool;
        new Thread(() -> {
            try {
                ServerSocket listener = new ServerSocket(PORT);
                listener.setReuseAddress(true);
                synchronized (serverLock) {
                    if (!accepting || epoch != serverEpoch) { listener.close(); return; }
                    server = listener;
                }
                while (accepting && epoch == serverEpoch) {
                    Socket socket = listener.accept();
                    try { pool.execute(() -> serve(socket)); }
                    catch (RejectedExecutionException busy) { socket.close(); }
                }
            } catch (IOException | RuntimeException error) {
                if (accepting && epoch == serverEpoch) main.post(() -> {
                    if (accepting && epoch == serverEpoch) {
                        store.connectionError = "设备连接暂未就绪，请结束后重新开始陪伴";
                        changed();
                    }
                });
            }
        }, "desk-button-http").start();
    }
    private void closeServer() {
        ServerSocket listener;
        synchronized (serverLock) {
            accepting = false;
            serverEpoch++;
            listener = server; server = null;
        }
        if (listener != null) try { listener.close(); } catch (IOException ignored) { }
        if (connections != null) connections.shutdownNow();
    }

    private static String readLine(BufferedInputStream input) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int value;
        while ((value = input.read()) != -1) {
            if (value == '\n') break;
            if (value != '\r') buffer.write(value);
            if (buffer.size() > 8192) throw new IOException("Header too long");
        }
        if (value == -1 && buffer.size() == 0) return null;
        return new String(buffer.toByteArray(), StandardCharsets.US_ASCII);
    }
    private void serve(Socket socket) {
        try (Socket connection = socket) {
            connection.setSoTimeout(5000);
            BufferedInputStream input = new BufferedInputStream(connection.getInputStream());
            String requestLine = readLine(input);
            if (requestLine == null) return;
            String[] request = requestLine.split(" ");
            if (request.length != 3) { respond(connection, 400, "{\"error\":\"bad_request\"}"); return; }
            Map<String, String> headers = new HashMap<>();
            String line; int headerBytes = 0;
            while ((line = readLine(input)) != null && !line.isEmpty()) {
                headerBytes += line.length();
                if (headerBytes > 16384) throw new IOException("Headers too long");
                int colon = line.indexOf(':');
                if (colon > 0) headers.put(line.substring(0, colon).trim().toLowerCase(Locale.US), line.substring(colon + 1).trim());
            }
            String auth = headers.get("authorization");
            String token = auth != null && auth.startsWith("Bearer ") ? auth.substring(7) : headers.get("x-pairing-token");
            String expectedToken = store.token;
            if (token == null || expectedToken.isEmpty() || !MessageDigest.isEqual(token.getBytes(StandardCharsets.UTF_8), expectedToken.getBytes(StandardCharsets.UTF_8))) {
                respond(connection, 401, "{\"error\":\"pairing_required\"}"); return;
            }
            int length;
            try { length = Integer.parseInt(headers.getOrDefault("content-length", "0")); }
            catch (NumberFormatException error) { respond(connection, 400, "{\"error\":\"bad_length\"}"); return; }
            if (length < 0 || length > 4096) { respond(connection, 413, "{\"error\":\"body_too_large\"}"); return; }
            byte[] body = new byte[length]; int read = 0;
            while (read < length) { int n = input.read(body, read, length - read); if (n < 0) throw new IOException("Incomplete body"); read += n; }
            JSONObject payload;
            try { payload = length == 0 ? new JSONObject() : new JSONObject(new String(body, StandardCharsets.UTF_8)); }
            catch (JSONException error) { respond(connection, 400, "{\"error\":\"invalid_json\"}"); return; }
            String method = request[0], path = request[1].split("\\?", 2)[0];
            if (!("GET".equals(method) && "/state".equals(path)) && !("POST".equals(method) && ("/help".equals(path) || "/ack".equals(path) || "/complete".equals(path)))) {
                respond(connection, 404, "{\"error\":\"not_found\"}"); return;
            }
            String requestId = payload.optString("request_id", headers.getOrDefault("x-request-id", ""));
            if (requestId.length() > 128) { respond(connection, 400, "{\"error\":\"request_id_too_long\"}"); return; }
            FutureTask<String> task = new FutureTask<>(() -> {
                if (!store.state.isSessionActive()) return "{\"error\":\"session_inactive\"}";
                if (!expectedToken.equals(store.token)) return "{\"error\":\"session_inactive\"}";
                boolean accepted = true;
                if ("POST".equals(method)) {
                    if ("/help".equals(path)) accepted = request(requestId);
                    else if ("/ack".equals(path)) acknowledge();
                    else complete();
                }
                return store.snapshot().put("accepted", accepted).toString();
            });
            main.post(task);
            String result = task.get(5, TimeUnit.SECONDS);
            respond(connection, result.contains("\"session_inactive\"") ? 409 : 200, result);
        } catch (Exception ignored) { /* Invalid/disconnected clients cannot crash the receiving service. */ }
    }
    private static void respond(Socket connection, int status, String json) throws IOException {
        byte[] body = json.getBytes(StandardCharsets.UTF_8);
        String reason = status == 200 ? "OK" : status == 401 ? "Unauthorized" : status == 404 ? "Not Found" : status == 409 ? "Conflict" : "Bad Request";
        OutputStream output = connection.getOutputStream();
        output.write(("HTTP/1.1 " + status + " " + reason + "\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: " + body.length + "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
        output.write(body); output.flush();
    }

    @Override public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (overlay != null) overlay.refreshIfShowing();
    }

    @Override public void onDestroy() {
        bluetooth.close();
        overlay.hide(); closeServer(); running = false;
        notifications.cancel(HELP_NOTIFICATION);
        if (store.state.isSessionActive()) { store.state.end(System.currentTimeMillis()); store.save(); }
        changed(); super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
