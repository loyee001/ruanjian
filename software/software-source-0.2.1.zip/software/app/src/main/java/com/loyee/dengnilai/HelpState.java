package com.loyee.dengnilai;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.UUID;

/** Pure Java state machine. One unresolved request survives repeated presses. */
public final class HelpState {
    public static final String WAITING = "waiting";
    public static final String ACKNOWLEDGED = "acknowledged";
    public static final String COMPLETED = "completed";
    public static final String SESSION_ENDED = "session_ended";

    public static final class Event {
        public String id;
        public long startedAt;
        public final List<Long> reminderTimes = new ArrayList<>();
        public final List<Long> responseTimes = new ArrayList<>();
        public long completedAt;
        public long closedAt;
        public String status = WAITING;
        public int count;
        public int level;
        public boolean unresolved() { return WAITING.equals(status) || ACKNOWLEDGED.equals(status); }
    }

    boolean sessionActive;
    long sessionStartedAt;
    long sessionEndedAt;
    final List<Event> events = new ArrayList<>();
    final LinkedHashSet<String> seenRequestIds = new LinkedHashSet<>();
    String lastDelivery = "none";

    public boolean isSessionActive() { return sessionActive; }
    public Event current() { return events.isEmpty() ? null : events.get(events.size() - 1); }
    public List<Event> events() { return events; }

    public void begin(long now) {
        if (sessionActive) return;
        sessionActive = true;
        sessionStartedAt = now;
        sessionEndedAt = 0;
        seenRequestIds.clear();
        lastDelivery = "none";
    }

    /** False means a retry with the same nonempty request ID, not another press. */
    public boolean request(long now, String requestId) {
        if (!sessionActive) throw new IllegalStateException("请先开始作业陪伴");
        if (requestId != null && !requestId.isEmpty()) {
            if (seenRequestIds.contains(requestId)) return false;
            seenRequestIds.add(requestId);
            while (seenRequestIds.size() > 512) seenRequestIds.remove(seenRequestIds.iterator().next());
        }
        Event event = current();
        if (event == null || !event.unresolved()) {
            event = new Event();
            event.id = UUID.randomUUID().toString();
            event.startedAt = now;
            events.add(event);
            while (events.size() > 100) events.remove(0);
        }
        event.count++;
        event.level = Math.min(3, event.count);
        event.reminderTimes.add(now);
        event.status = WAITING;
        return true;
    }

    public boolean acknowledge(long now) {
        Event event = current();
        if (!sessionActive || event == null || !WAITING.equals(event.status)) return false;
        event.status = ACKNOWLEDGED;
        event.responseTimes.add(now);
        return true;
    }

    public boolean complete(long now) {
        Event event = current();
        if (!sessionActive || event == null || !event.unresolved()) return false;
        event.status = COMPLETED;
        event.completedAt = now;
        event.closedAt = now;
        return true;
    }

    public void end(long now) {
        if (!sessionActive) return;
        sessionActive = false;
        sessionEndedAt = now;
        Event event = current();
        if (event != null && event.unresolved()) {
            event.status = SESSION_ENDED;
            event.closedAt = now;
        }
        lastDelivery = "none";
    }
}
