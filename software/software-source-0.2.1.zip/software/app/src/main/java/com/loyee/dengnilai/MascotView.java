package com.loyee.dengnilai;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Small native drawing of the desktop button; no external image dependency. */
final class MascotView extends View {
    private final Paint paint = new Paint(3);
    MascotView(Context context) { super(context); setContentDescription("头顶绿色按钮的桌面求助器"); }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.save(); canvas.scale(getWidth() / 100f, getHeight() / 100f);
        paint.setColor(Color.rgb(226, 221, 207)); canvas.drawOval(new RectF(12, 87, 90, 96), paint);
        paint.setColor(Color.rgb(237, 224, 191)); canvas.drawRoundRect(new RectF(16, 25, 86, 91), 22, 22, paint);
        canvas.drawOval(new RectF(8, 53, 27, 75), paint); canvas.drawOval(new RectF(77, 53, 96, 75), paint);
        paint.setColor(Color.rgb(123, 155, 127)); canvas.drawRoundRect(new RectF(30, 10, 73, 31), 9, 9, paint);
        paint.setColor(Color.rgb(160, 187, 157)); canvas.drawOval(new RectF(30, 8, 73, 21), paint);
        paint.setColor(Color.rgb(54, 68, 49)); canvas.drawCircle(36, 48, 4, paint); canvas.drawCircle(67, 48, 4, paint);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(3); paint.setStrokeCap(Paint.Cap.ROUND);
        canvas.drawArc(new RectF(39, 54, 64, 69), 15, 150, false, paint); paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(220, 174, 146)); canvas.drawOval(new RectF(23, 56, 35, 62), paint); canvas.drawOval(new RectF(68, 56, 80, 62), paint);
        canvas.restore();
    }
}
