package com.loyee.dengnilai;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** One application-overlay window. It remains subject to system and target-app restrictions. */
final class OverlayController {
    private static final String TAG = "DengNiLaiOverlay";
    private final Context context;
    private final WindowManager windows;
    private final Runnable onAcknowledge;
    private View current;
    private HelpState.Event displayedEvent;

    OverlayController(Context context, Runnable onAcknowledge) {
        this.context = windowContext(context);
        this.onAcknowledge = onAcknowledge;
        windows = this.context.getSystemService(WindowManager.class);
    }

    private static Context windowContext(Context serviceContext) {
        if (Build.VERSION.SDK_INT >= 30) {
            DisplayManager displays = serviceContext.getSystemService(DisplayManager.class);
            Display display = displays == null ? null : displays.getDisplay(Display.DEFAULT_DISPLAY);
            if (display != null) {
                Context displayContext = serviceContext.createDisplayContext(display);
                try {
                    return displayContext.createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null);
                } catch (RuntimeException unavailable) {
                    Log.w(TAG, "Unable to create overlay window context; using display context", unavailable);
                    return displayContext;
                }
            }
        }
        return serviceContext;
    }

    private int dp(int value) { return Math.round(value * context.getResources().getDisplayMetrics().density); }
    private TextView text(String value, int size, boolean bold) {
        TextView view = new TextView(context); view.setText(value); view.setTextSize(size);
        view.setTextColor(Color.rgb(40, 59, 47)); view.setGravity(Gravity.CENTER);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }
    @SuppressWarnings("deprecation")
    private Rect availableBounds() {
        if (Build.VERSION.SDK_INT >= 30) return new Rect(windows.getCurrentWindowMetrics().getBounds());
        DisplayMetrics metrics = new DisplayMetrics();
        windows.getDefaultDisplay().getMetrics(metrics);
        return new Rect(0, 0, metrics.widthPixels, metrics.heightPixels);
    }

    private Rect safeInsets() {
        if (Build.VERSION.SDK_INT >= 30) {
            Insets safe = windows.getCurrentWindowMetrics().getWindowInsets().getInsetsIgnoringVisibility(
                WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            return new Rect(safe.left, safe.top, safe.right, safe.bottom);
        }
        return new Rect();
    }

    @SuppressWarnings("deprecation")
    private void applySafeInsets(View root, WindowInsets insets, int padding) {
        int left, top, right, bottom;
        if (Build.VERSION.SDK_INT >= 30) {
            Insets safe = insets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            left = safe.left; top = safe.top; right = safe.right; bottom = safe.bottom;
        } else {
            left = insets.getSystemWindowInsetLeft(); top = insets.getSystemWindowInsetTop();
            right = insets.getSystemWindowInsetRight(); bottom = insets.getSystemWindowInsetBottom();
            if (Build.VERSION.SDK_INT >= 28) {
                DisplayCutout cutout = insets.getDisplayCutout();
                if (cutout != null) {
                    left = Math.max(left, cutout.getSafeInsetLeft()); top = Math.max(top, cutout.getSafeInsetTop());
                    right = Math.max(right, cutout.getSafeInsetRight()); bottom = Math.max(bottom, cutout.getSafeInsetBottom());
                }
            }
        }
        root.setPadding(padding + left, padding + top, padding + right, padding + bottom);
    }

    boolean show(HelpState.Event event) {
        hide();
        final boolean fullscreen = event.level == 3;
        Rect bounds = availableBounds();
        Rect safe = safeInsets();
        int availableWidth = Math.max(1, bounds.width() - safe.left - safe.right);
        int availableHeight = Math.max(1, bounds.height() - safe.top - safe.bottom);
        final int padding = dp(availableHeight < dp(360) ? 12 : 24);
        int width = fullscreen ? WindowManager.LayoutParams.MATCH_PARENT
            : Math.max(1, event.level == 1 ? Math.min(dp(310), availableWidth - dp(24)) : availableWidth - dp(24));

        FrameLayout root = new FrameLayout(context);
        // A touchable, opaque background covers the app area without intercepting system keys.
        root.setClickable(true);
        GradientDrawable background = new GradientDrawable(); background.setColor(Color.rgb(249, 245, 235));
        background.setCornerRadius(fullscreen ? 0 : dp(24));
        if (!fullscreen) background.setStroke(dp(2), Color.rgb(112, 144, 119));
        root.setBackground(background);
        root.setPadding(padding, padding, padding, padding);
        if (fullscreen) {
            root.setPadding(padding + safe.left, padding + safe.top, padding + safe.right, padding + safe.bottom);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                applySafeInsets(view, insets, padding);
                return insets;
            });
        }

        LinearLayout panel = new LinearLayout(context); panel.setOrientation(LinearLayout.VERTICAL);
        root.addView(panel, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        ScrollView scroll = new ScrollView(context); scroll.setFillViewport(true);
        panel.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        LinearLayout body = new LinearLayout(context); body.setOrientation(LinearLayout.VERTICAL); body.setGravity(Gravity.CENTER);
        scroll.addView(body, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        body.addView(new MascotView(context), new LinearLayout.LayoutParams(dp(fullscreen ? 116 : 70), dp(fullscreen ? 116 : 70)));
        body.addView(text("孩子需要你", fullscreen ? 32 : 23, true));
        TextView detail = text("同一条求助 · 第 " + event.count + " 次提醒", 15, false);
        detail.setPadding(0, dp(12), 0, dp(8)); body.addView(detail);
        TextView message = text(fullscreen ? "有个学习卡点\n等你来一起解决" : "先回应一声，再一起解决", fullscreen ? 23 : 17, false);
        message.setPadding(0, dp(8), 0, dp(20)); body.addView(message);

        // Keep acknowledgement outside the scrollable body, including in landscape.
        Button acknowledge = new Button(context); acknowledge.setText("收到，我来了"); acknowledge.setTextSize(18);
        acknowledge.setAllCaps(false); acknowledge.setTextColor(Color.WHITE);
        GradientDrawable button = new GradientDrawable(); button.setColor(Color.rgb(79, 118, 91)); button.setCornerRadius(dp(16));
        acknowledge.setBackground(button); acknowledge.setOnClickListener(view -> onAcknowledge.run());
        panel.addView(acknowledge, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(58)));
        if (fullscreen) {
            TextView note = text("回应后，提醒就会收起", 13, false); note.setPadding(0, dp(12), 0, 0); panel.addView(note);
        }

        int height = WindowManager.LayoutParams.MATCH_PARENT;
        if (!fullscreen) {
            int bodyWidth = Math.max(1, width - padding * 2);
            body.measure(View.MeasureSpec.makeMeasureSpec(bodyWidth, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            int desiredHeight = padding * 2 + body.getMeasuredHeight() + dp(58);
            int maxHeight = Math.max(1, availableHeight - dp(event.level == 1 ? 84 : 24));
            height = Math.min(desiredHeight, maxHeight);
        }
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (fullscreen) flags |= WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        params.gravity = event.level == 1 ? Gravity.TOP | Gravity.CENTER_HORIZONTAL : Gravity.CENTER;
        if (event.level == 1) params.y = dp(72);
        if (fullscreen && Build.VERSION.SDK_INT >= 30) {
            params.setFitInsetsTypes(0);
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (fullscreen && Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        params.setTitle("等你来求助提醒");
        try {
            windows.addView(root, params);
            current = root; displayedEvent = event;
            root.requestApplyInsets();
            return true;
        } catch (RuntimeException denied) {
            current = null; displayedEvent = null;
            Log.w(TAG, "Unable to add level " + event.level + " overlay window", denied);
            return false;
        }
    }

    void refreshIfShowing() {
        // ACK, completion and session stop call hide(); configuration changes must not revive them.
        if (current != null && displayedEvent != null) show(displayedEvent);
    }

    void hide() {
        View previous = current;
        current = null; displayedEvent = null;
        if (previous != null) {
            try { windows.removeViewImmediate(previous); }
            catch (RuntimeException alreadyRemoved) { Log.w(TAG, "Unable to remove overlay window", alreadyRemoved); }
        }
    }
}
