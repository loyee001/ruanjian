package com.loyee.dengnilai;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.app.NotificationManager;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.security.SecureRandom;

/** Main-thread owner of local records; no account or child identity is collected. */
final class SessionStore {
    private static SessionStore instance;
    final HelpState state = new HelpState();
    final SharedPreferences preferences;
    private final Context context;
    String token = "";
    String connectionError = "";

    static synchronized SessionStore get(Context context) {
        if (instance == null) instance = new SessionStore(context.getApplicationContext());
        return instance;
    }

    private SessionStore(Context context) {
        this.context = context;
        preferences = context.getSharedPreferences("local_help_records", Context.MODE_PRIVATE);
        restore();
        // A killed process cannot honestly claim it is still receiving hardware.
        if (state.isSessionActive()) { state.end(System.currentTimeMillis()); save(); }
    }

    void begin() {
        if (!state.isSessionActive()) {
            byte[] bytes = new byte[12];
            new SecureRandom().nextBytes(bytes);
            StringBuilder value = new StringBuilder();
            for (byte b : bytes) value.append(String.format("%02x", b & 255));
            token = value.toString();
            state.begin(System.currentTimeMillis());
            connectionError = "";
            save();
        }
    }

    static JSONObject eventJson(HelpState.Event event) throws JSONException {
        JSONObject json = new JSONObject();
        json.put("id", event.id).put("status", event.status).put("started_at", event.startedAt)
            .put("count", event.count).put("level", event.level)
            .put("completed_at", event.completedAt).put("closed_at", event.closedAt);
        JSONArray reminders = new JSONArray(), responses = new JSONArray();
        for (long value : event.reminderTimes) reminders.put(value);
        for (long value : event.responseTimes) responses.put(value);
        return json.put("reminder_times", reminders).put("response_times", responses);
    }

    JSONObject snapshot() throws JSONException {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        JSONObject json = new JSONObject();
        json.put("session_active", state.isSessionActive())
            .put("session_started_at", state.sessionStartedAt).put("session_ended_at", state.sessionEndedAt)
            .put("overlay_permission", Settings.canDrawOverlays(context))
            .put("notifications_enabled", HelpService.helpNotificationsEnabled(context))
            .put("last_delivery", state.lastDelivery).put("http_port", HelpService.PORT)
            .put("connection_error", connectionError);
        json.put("bluetooth_connected", BleButtonClient.isConnected())
            .put("bluetooth_status", BleButtonClient.status());
        HelpState.Event current = state.current();
        json.put("current", current == null ? JSONObject.NULL : eventJson(current));
        JSONArray events = new JSONArray();
        for (HelpState.Event event : state.events()) events.put(eventJson(event));
        return json.put("records", events);
    }

    void save() {
        try {
            JSONObject json = new JSONObject().put("session_active", state.isSessionActive())
                .put("session_started_at", state.sessionStartedAt).put("session_ended_at", state.sessionEndedAt)
                .put("token", token).put("last_delivery", state.lastDelivery);
            JSONArray events = new JSONArray(), requestIds = new JSONArray();
            for (HelpState.Event event : state.events()) events.put(eventJson(event));
            for (String id : state.seenRequestIds) requestIds.put(id);
            json.put("events", events).put("seen_request_ids", requestIds);
            preferences.edit().putString("state", json.toString()).apply();
        } catch (JSONException ignored) { }
    }

    private void restore() {
        try {
            JSONObject json = new JSONObject(preferences.getString("state", "{}"));
            state.sessionActive = json.optBoolean("session_active");
            state.sessionStartedAt = json.optLong("session_started_at");
            state.sessionEndedAt = json.optLong("session_ended_at");
            state.lastDelivery = json.optString("last_delivery", "none");
            token = json.optString("token", "");
            JSONArray events = json.optJSONArray("events");
            if (events != null) for (int i = 0; i < events.length(); i++) {
                JSONObject item = events.getJSONObject(i);
                HelpState.Event event = new HelpState.Event();
                event.id = item.getString("id"); event.status = item.getString("status");
                event.startedAt = item.getLong("started_at"); event.count = item.getInt("count");
                event.level = Math.min(3, item.getInt("level"));
                event.completedAt = item.optLong("completed_at"); event.closedAt = item.optLong("closed_at");
                JSONArray reminders = item.optJSONArray("reminder_times"), responses = item.optJSONArray("response_times");
                if (reminders != null) for (int n = 0; n < reminders.length(); n++) event.reminderTimes.add(reminders.getLong(n));
                if (responses != null) for (int n = 0; n < responses.length(); n++) event.responseTimes.add(responses.getLong(n));
                state.events.add(event);
            }
            JSONArray ids = json.optJSONArray("seen_request_ids");
            if (ids != null) for (int i = 0; i < ids.length(); i++) state.seenRequestIds.add(ids.getString(i));
        } catch (JSONException ignored) {
            state.events.clear(); state.sessionActive = false;
        }
    }
}
