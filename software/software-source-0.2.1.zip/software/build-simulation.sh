#!/bin/bash
# Build a side-by-side demonstration variant from private staged copies only.
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
SDK_DIR="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/Library/Android/sdk}}"
JDK_DIR="${DENG_NI_LAI_JDK:-${JAVA_HOME:-/Library/Java/JavaVirtualMachines/jdk-17.jdk/Contents/Home}}"
PYTHON_BIN="${DENG_NI_LAI_PYTHON:-python3}"
export JAVA_HOME="$JDK_DIR"
export PATH="$JDK_DIR/bin:$PATH"
TOOLS_DIR="$SDK_DIR/build-tools/35.0.0"
PLATFORM_JAR="$SDK_DIR/platforms/android-35/android.jar"
BUILD_DIR="$PROJECT_DIR/build/simulation"
ORIGINAL_APK="${DENG_NI_LAI_ORIGINAL_APK:-$PROJECT_DIR/build/manual/deng-ni-lai-debug.apk}"
NAMESPACE="com.loyee.dengnilai"
APP_ID="com.loyee.dengnilai.simulation"
mkdir -p "$BUILD_DIR"
WORK_DIR="$(mktemp -d "$BUILD_DIR/work.XXXXXX")"
mkdir -p "$WORK_DIR/generated" "$WORK_DIR/classes" "$WORK_DIR/dex"

"$PYTHON_BIN" - "$PROJECT_DIR" "$WORK_DIR" "$ORIGINAL_APK" <<'PY'
import hashlib
import json
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET

project, work, original = map(Path, sys.argv[1:])
source = project / 'app/src/main'
staged = work / 'main'
shutil.copytree(source, staged)
namespace = 'com.loyee.dengnilai'
app_id = namespace + '.simulation'
label = '等你来(模拟)'
android = '{http://schemas.android.com/apk/res/android}'
ET.register_namespace('android', 'http://schemas.android.com/apk/res/android')
manifest = ET.parse(staged / 'AndroidManifest.xml')
manifest.getroot().set('package', app_id)
application = manifest.getroot().find('application')
application.set(android + 'label', label)
for tag, name in [('activity', 'MainActivity'), ('service', 'HelpService')]:
    application.find(tag).set(android + 'name', namespace + '.' + name)
manifest.write(staged / 'AndroidManifest.xml', encoding='utf-8', xml_declaration=True)

java = staged / 'java/com/loyee/dengnilai'
changes = {
    'MainActivity.java': [('"等你来"', '"等你来(模拟)"')],
    'HelpService.java': [
        ('public static final int PORT = 8742;', 'public static final int PORT = 8743;'),
        ('"等你来 · 作业陪伴中"', '"等你来(模拟) · 作业陪伴中"'),
    ],
    'OverlayController.java': [('"等你来求助提醒"', '"等你来(模拟)求助提醒"')],
}
for name, replacements in changes.items():
    path = java / name
    text = path.read_text()
    for old, new in replacements:
        if text.count(old) != 1:
            raise SystemExit(f'Expected one original marker in {name}: {old!r}')
        text = text.replace(old, new)
    path.write_text(text)
strings = staged / 'res/values/strings.xml'
strings.write_text(strings.read_text().replace('>等你来<', '>' + label + '<'))
source_fingerprints = {
    str(path.relative_to(project)): hashlib.sha256(path.read_bytes()).hexdigest()
    for path in sorted(source.rglob('*')) if path.is_file()
}
metadata = {
    'application_id': app_id, 'namespace': namespace, 'label': label,
    'version_name': '0.2.1-simulation', 'version_code': 3, 'http_port': 8743,
    'original_apk': str(original),
    'original_apk_sha256_before': hashlib.sha256(original.read_bytes()).hexdigest() if original.is_file() else None,
    'original_source_sha256_before': source_fingerprints,
    'staging_directory': str(work),
    'scope': 'Independent demonstration build with BLE connection and service-owned 5s delayed one/three press controls. Same help state machine as the Bluetooth app.',
}
(work / 'prebuild-metadata.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
PY

"$PYTHON_BIN" "$PROJECT_DIR/simulation/prepare-delay.py" "$WORK_DIR"

"$TOOLS_DIR/aapt2" compile --dir "$WORK_DIR/main/res" -o "$WORK_DIR/compiled-res.zip"
"$TOOLS_DIR/aapt2" link -o "$WORK_DIR/resources.apk" -I "$PLATFORM_JAR" --manifest "$WORK_DIR/main/AndroidManifest.xml" --java "$WORK_DIR/generated" --custom-package "$NAMESPACE" --debug-mode --min-sdk-version 26 --target-sdk-version 35 --version-code 3 --version-name 0.2.1-simulation "$WORK_DIR/compiled-res.zip"
find "$WORK_DIR/main/java" "$WORK_DIR/generated" -name '*.java' > "$WORK_DIR/sources.list"
"$JDK_DIR/bin/javac" -encoding UTF-8 -source 8 -target 8 -bootclasspath "$PLATFORM_JAR:$TOOLS_DIR/core-lambda-stubs.jar" -d "$WORK_DIR/classes" @"$WORK_DIR/sources.list"
"$JDK_DIR/bin/jar" cf "$WORK_DIR/classes.jar" -C "$WORK_DIR/classes" .
"$TOOLS_DIR/d8" --lib "$PLATFORM_JAR" --min-api 26 --output "$WORK_DIR/dex" "$WORK_DIR/classes.jar"
cp "$WORK_DIR/resources.apk" "$WORK_DIR/unsigned.apk"
(cd "$WORK_DIR/dex" && /usr/bin/zip -q "$WORK_DIR/unsigned.apk" classes.dex)
"$TOOLS_DIR/zipalign" -f 4 "$WORK_DIR/unsigned.apk" "$WORK_DIR/aligned.apk"
SIGNING_KEY="$PROJECT_DIR/build/manual/debug.keystore"
if [ ! -f "$SIGNING_KEY" ]; then
  SIGNING_KEY="$BUILD_DIR/debug.keystore"
  if [ ! -f "$SIGNING_KEY" ]; then
    "$JDK_DIR/bin/keytool" -genkeypair -keystore "$SIGNING_KEY" -alias androiddebugkey -storepass android -keypass android -dname 'CN=Android Simulation Debug,O=Loyee,C=CN' -keyalg RSA -keysize 2048 -validity 10000 -noprompt
  fi
fi
"$TOOLS_DIR/apksigner" sign --ks "$SIGNING_KEY" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out "$WORK_DIR/deng-ni-lai-simulation.apk" "$WORK_DIR/aligned.apk"
"$TOOLS_DIR/apksigner" verify --verbose --print-certs "$WORK_DIR/deng-ni-lai-simulation.apk" > "$BUILD_DIR/signature-verification.txt"
"$TOOLS_DIR/aapt2" dump badging "$WORK_DIR/deng-ni-lai-simulation.apk" > "$BUILD_DIR/aapt2-badging.txt"

"$PYTHON_BIN" - "$PROJECT_DIR" "$WORK_DIR" "$BUILD_DIR" "$SIGNING_KEY" <<'PY'
import hashlib
import json
from pathlib import Path
import shutil
import sys
project, work, build, key = map(Path, sys.argv[1:])
metadata = json.loads((work / 'prebuild-metadata.json').read_text())
badging = (build / 'aapt2-badging.txt').read_text()
required = [
    "package: name='com.loyee.dengnilai.simulation'",
    "versionName='0.2.1-simulation'", "versionCode='3'",
    "application-label:'等你来(模拟)'",
    "launchable-activity: name='com.loyee.dengnilai.MainActivity'",
    "minSdkVersion:'26'", "targetSdkVersion:'35'", 'application-debuggable',
]
for expected in required:
    if expected not in badging:
        raise SystemExit('APK metadata check failed: ' + expected)
original = Path(metadata['original_apk'])
after = hashlib.sha256(original.read_bytes()).hexdigest() if original.is_file() else None
before = metadata['original_apk_sha256_before']
metadata['original_apk_sha256_after'] = after
metadata['original_apk_unchanged'] = before == after if before is not None else None
if before is not None and before != after:
    raise SystemExit('Original APK unexpectedly changed; simulation output not published.')
for relative, before_hash in metadata.pop('original_source_sha256_before').items():
    if hashlib.sha256((project / relative).read_bytes()).hexdigest() != before_hash:
        raise SystemExit('Original source unexpectedly changed: ' + relative)
metadata['original_source_unchanged'] = True
metadata['signing_key'] = str(key)
metadata['signing_key_sha256'] = hashlib.sha256(key.read_bytes()).hexdigest()
metadata['apk_sha256'] = hashlib.sha256((work / 'deng-ni-lai-simulation.apk').read_bytes()).hexdigest()
metadata['metadata_verified'] = required
metadata['signature_verified'] = True
metadata['device_validation'] = 'Not performed by this build script; side-by-side install and launch remain to be checked.'
if before is None:
    metadata['original_apk_note'] = 'Original APK was not present at the configured path; no before/after APK comparison was possible. Set DENG_NI_LAI_ORIGINAL_APK to its current path.'
output = build / 'deng-ni-lai-simulation.apk'
shutil.copyfile(work / 'deng-ni-lai-simulation.apk', output)
shutil.copyfile(output, build / '等你来(模拟).apk')
(build / 'build-verification.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
print('APK: ' + str(output))
print('SHA256: ' + metadata['apk_sha256'])
print('Original source unchanged: true')
print('Original APK unchanged: ' + str(metadata['original_apk_unchanged']))
PY
