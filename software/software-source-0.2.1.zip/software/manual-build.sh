#!/bin/bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
SDK_DIR="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/Library/Android/sdk}}"
JDK_DIR="${DENG_NI_LAI_JDK:-${JAVA_HOME:-/Library/Java/JavaVirtualMachines/jdk-17.jdk/Contents/Home}}"
export JAVA_HOME="$JDK_DIR"
export PATH="$JDK_DIR/bin:$PATH"
TOOLS_DIR="$SDK_DIR/build-tools/35.0.0"
PLATFORM_JAR="$SDK_DIR/platforms/android-35/android.jar"
BUILD_DIR="$PROJECT_DIR/build/manual"
mkdir -p "$BUILD_DIR/generated" "$BUILD_DIR/classes" "$BUILD_DIR/dex" "$BUILD_DIR/tests"
"$JDK_DIR/bin/javac" -encoding UTF-8 -cp "$PLATFORM_JAR" -d "$BUILD_DIR/tests" "$PROJECT_DIR/app/src/main/java/com/loyee/dengnilai/HelpState.java" "$PROJECT_DIR/app/src/main/java/com/loyee/dengnilai/BleButtonClient.java" "$PROJECT_DIR/tests/HelpStateTest.java" "$PROJECT_DIR/tests/BleProtocolTest.java"
"$JDK_DIR/bin/java" -cp "$BUILD_DIR/tests" com.loyee.dengnilai.HelpStateTest
"$JDK_DIR/bin/java" -cp "$BUILD_DIR/tests:$PLATFORM_JAR" com.loyee.dengnilai.BleProtocolTest
"$TOOLS_DIR/aapt2" compile --dir "$PROJECT_DIR/app/src/main/res" -o "$BUILD_DIR/compiled-res.zip"
sed 's/<manifest xmlns:android=/<manifest package="com.loyee.dengnilai" xmlns:android=/' "$PROJECT_DIR/app/src/main/AndroidManifest.xml" > "$BUILD_DIR/AndroidManifest.xml"
"$TOOLS_DIR/aapt2" link -o "$BUILD_DIR/resources.apk" -I "$PLATFORM_JAR" --manifest "$BUILD_DIR/AndroidManifest.xml" --java "$BUILD_DIR/generated" --debug-mode --min-sdk-version 26 --target-sdk-version 35 --version-code 3 --version-name 0.2.1-bluetooth "$BUILD_DIR/compiled-res.zip"
find "$PROJECT_DIR/app/src/main/java" "$BUILD_DIR/generated" -name '*.java' > "$BUILD_DIR/sources.list"
"$JDK_DIR/bin/javac" -encoding UTF-8 -source 8 -target 8 -bootclasspath "$PLATFORM_JAR:$TOOLS_DIR/core-lambda-stubs.jar" -d "$BUILD_DIR/classes" @"$BUILD_DIR/sources.list"
"$JDK_DIR/bin/jar" cf "$BUILD_DIR/classes.jar" -C "$BUILD_DIR/classes" .
"$TOOLS_DIR/d8" --lib "$PLATFORM_JAR" --min-api 26 --output "$BUILD_DIR/dex" "$BUILD_DIR/classes.jar"
cp "$BUILD_DIR/resources.apk" "$BUILD_DIR/unsigned.apk"
(cd "$BUILD_DIR/dex" && /usr/bin/zip -q "$BUILD_DIR/unsigned.apk" classes.dex)
"$TOOLS_DIR/zipalign" -f 4 "$BUILD_DIR/unsigned.apk" "$BUILD_DIR/aligned.apk"
if [ ! -f "$BUILD_DIR/debug.keystore" ]; then
  "$JDK_DIR/bin/keytool" -genkeypair -keystore "$BUILD_DIR/debug.keystore" -alias androiddebugkey -storepass android -keypass android -dname 'CN=Android Debug,O=Loyee,C=CN' -keyalg RSA -keysize 2048 -validity 10000 -noprompt
fi
export JAVA_HOME="$JDK_DIR"
"$TOOLS_DIR/apksigner" sign --ks "$BUILD_DIR/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out "$BUILD_DIR/deng-ni-lai-debug.apk" "$BUILD_DIR/aligned.apk"
"$TOOLS_DIR/apksigner" verify "$BUILD_DIR/deng-ni-lai-debug.apk"
printf 'APK: %s\n' "$BUILD_DIR/deng-ni-lai-debug.apk"
