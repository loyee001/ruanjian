#!/usr/bin/env python3
"""Add service-owned delayed controls only to the private simulation build."""
from pathlib import Path
import sys

java = Path(sys.argv[1]) / "main/java/com/loyee/dengnilai"

def replace_once(path, before, after):
    text = path.read_text()
    if text.count(before) != 1:
        raise SystemExit(f"Expected one simulation patch anchor in {path.name}: {before[:90]!r}")
    path.write_text(text.replace(before, after))

activity = java / "MainActivity.java"
replace_once(activity, "        LinearLayout permissions = card();", """
        LinearLayout delayed = card();
        delayed.addView(text("切到其他 APP 再提醒", 20, INK, true));
        delayed.addView(text("先选一项，再马上切到其他 APP。5 秒后开始模拟按键。", 14, MUTED, false));
        Button delayedOne = button("5 秒后按一次", true, () -> act(HelpService.SIMULATE_ONE));
        Button delayedThree = button("5 秒后连续按 3 次", false, () -> act(HelpService.SIMULATE_THREE));
        delayedOne.setEnabled(active); delayedThree.setEnabled(active);
        delayedOne.setAlpha(active ? 1 : 0.45f); delayedThree.setAlpha(active ? 1 : 0.45f);
        delayed.addView(delayedOne); delayed.addView(delayedThree);
        space(delayed, 10); delayed.addView(text(HelpService.simulationStatus(), 14, GREEN, true));
        if (HelpService.simulationPending()) delayed.addView(button("取消本次倒计时", false, () -> act(HelpService.CANCEL_SIMULATION)));
        delayed.addView(text("三连拍每隔 1 秒一次。已有求助会继续升级；再次演示前可先标记「已经处理完成」。", 12, MUTED, false));

        LinearLayout permissions = card();""")

service = java / "HelpService.java"
replace_once(service, '    public static final int PORT = 8743;', '''    public static final String SIMULATE_ONE = "com.loyee.dengnilai.simulation.DELAY_ONE";
    public static final String SIMULATE_THREE = "com.loyee.dengnilai.simulation.DELAY_THREE";
    public static final String CANCEL_SIMULATION = "com.loyee.dengnilai.simulation.CANCEL_DELAY";
    public static final int PORT = 8743;''')
replace_once(service, "    private ExecutorService connections;", '''    private ExecutorService connections;
    private static boolean delayedPending;
    private static long delayedFirstAt;
    private static int delayedTotal, delayedSent;
    private static String delayedMessage = "开始陪伴后，选择延迟模拟。";
    static boolean simulationPending() { return delayedPending; }
    static String simulationStatus() {
        if (!delayedPending) return delayedMessage;
        if (delayedSent == 0) {
            long seconds = Math.max(0, (delayedFirstAt - android.os.SystemClock.elapsedRealtime() + 999) / 1000);
            return "还有 " + seconds + " 秒，快切到其他 APP · 将模拟 " + delayedTotal + " 次";
        }
        return "已模拟 " + delayedSent + "/" + delayedTotal + " 次，正在继续…";
    }
    private final Runnable delayedTick = new Runnable() {
        @Override public void run() {
            if (!delayedPending || !store.state.isSessionActive()) return;
            updateSimulation(); main.postDelayed(this, 1000);
        }
    };
    private final Runnable delayedPress = new Runnable() {
        @Override public void run() {
            if (!delayedPending || !store.state.isSessionActive()) return;
            delayedSent++;
            request(null);
            if (delayedSent < delayedTotal) main.postDelayed(this, 1000);
            else {
                delayedPending = false;
                main.removeCallbacks(delayedTick);
                delayedMessage = "已模拟 " + delayedSent + " 次。点「收到，我来了」收起提醒。";
            }
            updateSimulation();
        }
    };
    private void scheduleSimulation(int count) {
        cancelSimulation(false);
        delayedTotal = count; delayedSent = 0;
        delayedFirstAt = android.os.SystemClock.elapsedRealtime() + 5000;
        delayedPending = true;
        main.postDelayed(delayedPress, 5000);
        main.postDelayed(delayedTick, 1000);
        updateSimulation();
    }
    private void cancelSimulation(boolean refresh) {
        boolean hadPlan = delayedPending;
        delayedPending = false; delayedFirstAt = 0;
        main.removeCallbacks(delayedPress); main.removeCallbacks(delayedTick);
        if (hadPlan) delayedMessage = "已取消本次延迟模拟。";
        if (refresh) updateSimulation();
    }
    private void updateSimulation() {
        if (running && store.state.isSessionActive()) notifications.notify(SESSION_NOTIFICATION, sessionNotification());
        changed();
    }''')
replace_once(service, '            if (HELP.equals(action)) request(intent.getStringExtra("request_id"));', '''            if (SIMULATE_ONE.equals(action)) scheduleSimulation(1);
            else if (SIMULATE_THREE.equals(action)) scheduleSimulation(3);
            else if (CANCEL_SIMULATION.equals(action)) cancelSimulation(true);
            else if (HELP.equals(action)) request(intent.getStringExtra("request_id"));''')
replace_once(service, '''        return new Notification.Builder(this, SESSION_CHANNEL).setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("等你来(模拟) · 作业陪伴中").setContentText("正在接收桌面设备的求助")
            .setContentIntent(openApp()).setOngoing(true).setCategory(Notification.CATEGORY_SERVICE)
            .addAction(new Notification.Action.Builder(null, "结束陪伴", action(STOP, 1)).build()).build();''', '''        Notification.Builder builder = new Notification.Builder(this, SESSION_CHANNEL).setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("等你来(模拟) · 作业陪伴中")
            .setContentText(delayedPending ? simulationStatus() : "正在接收桌面设备的求助")
            .setContentIntent(openApp()).setOngoing(true).setCategory(Notification.CATEGORY_SERVICE)
            .addAction(new Notification.Action.Builder(null, "结束陪伴", action(STOP, 1)).build());
        if (delayedPending) builder.addAction(new Notification.Action.Builder(null, "取消倒计时", action(CANCEL_SIMULATION, 4)).build());
        return builder.build();''')
replace_once(service, '    private void acknowledge() {', '''    private void acknowledge() {
        cancelSimulation(true);''')
replace_once(service, '    private void complete() {', '''    private void complete() {
        cancelSimulation(true);''')
replace_once(service, '    private void endSession() {', '''    private void endSession() {
        cancelSimulation(false);
        delayedMessage = "开始陪伴后，选择延迟模拟。";''')
replace_once(service, '    @Override public void onDestroy() {', '''    @Override public void onDestroy() {
        cancelSimulation(false);''')
print("Simulation-only delayed controls staged: 5s one / 5s three / cancel")
