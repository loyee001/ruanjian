#!/bin/bash
# Compile and run the project's JVM policy/protocol checks without installing an APK.
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
SDK_DIR="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/Library/Android/sdk}}"
JDK_DIR="${DENG_NI_LAI_JDK:-${JAVA_HOME:-/Library/Java/JavaVirtualMachines/jdk-17.jdk/Contents/Home}}"
PLATFORM_JAR="$SDK_DIR/platforms/android-35/android.jar"
BUILD_DIR="$PROJECT_DIR/build/unit-tests"
mkdir -p "$BUILD_DIR"
SOURCE_DIR="$PROJECT_DIR/app/src/main/java/com/loyee/dengnilai"
"$JDK_DIR/bin/javac" -encoding UTF-8 -cp "$PLATFORM_JAR" -d "$BUILD_DIR" \
  "$SOURCE_DIR/HelpState.java" "$SOURCE_DIR/BleButtonClient.java" \
  "$PROJECT_DIR/tests/HelpStateTest.java" "$PROJECT_DIR/tests/BleProtocolTest.java"
"$JDK_DIR/bin/java" -cp "$BUILD_DIR:$PLATFORM_JAR" com.loyee.dengnilai.HelpStateTest
"$JDK_DIR/bin/java" -cp "$BUILD_DIR:$PLATFORM_JAR" com.loyee.dengnilai.BleProtocolTest
