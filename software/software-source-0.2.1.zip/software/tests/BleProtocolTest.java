package com.loyee.dengnilai;

import java.nio.charset.StandardCharsets;

/** Run against android.jar plus compiled BleButtonClient; no Android instance is constructed. */
public final class BleProtocolTest {
    private static int checks;
    private static void check(boolean value, String label) {
        checks++;
        if (!value) throw new AssertionError(label);
    }
    private static String parse(String address, String value) {
        return BleButtonClient.Protocol.requestIdFromPayload(address, value == null ? null : value.getBytes(StandardCharsets.UTF_8));
    }
    public static void main(String[] arguments) {
        String address = "AA:BB:CC:DD:EE:FF";
        check("ble:aabbccddeeff:abcd1234:1".equals(parse(address, "PRESS:ABCD1234:1")), "canonical identity");
        check(parse(address, "PRESS:ffffffff:99999") != null, "20-byte notification maximum");
        check(parse(address, "PRESS:00000000:1") != null, "zero-valued boot ID is valid");
        check(!parse(address, "PRESS:00000000:1").equals(parse(address, "PRESS:00000000:2")), "successive presses distinct");
        check(!parse(address, "PRESS:00000000:1").equals(parse(address, "PRESS:00000001:1")), "new boot distinct");
        check(!parse(address, "PRESS:00000000:1").equals(parse("AA:BB:CC:DD:EE:00", "PRESS:00000000:1")), "devices distinct");
        String[] invalid = {"", "1", "PRESS", "press:abcd1234:1", "PRESS:abcd123:1", "PRESS:gggggggg:1",
            "PRESS:abcd1234:0", "PRESS:abcd1234:01", "PRESS:abcd1234:-1", "PRESS:abcd1234:100000",
            "PRESS:abcd1234:1\n", " PRESS:abcd1234:1", "PRESS:abcd1234:1:1", "PRESS:abcd1234:1\u0000", "PRESS:abcd1234:１"};
        for (String value : invalid) check(parse(address, value) == null, "invalid payload rejected: " + value);
        check(parse(address, null) == null, "null payload rejected");
        check(parse(null, "PRESS:abcd1234:1") == null, "null device rejected");
        check(parse("not-a-device", "PRESS:abcd1234:1") == null, "invalid address rejected");
        BleButtonClient.SeenPresses seen = new BleButtonClient.SeenPresses();
        check(seen.accept("one"), "first press accepted");
        check(!seen.accept("one"), "duplicate press ignored");
        check(seen.accept("two"), "next press accepted");
        for (int i = 0; i < 127; i++) seen.accept("extra-" + i);
        check(seen.accept("one"), "bounded dedup evicts oldest");
        check(!seen.accept("extra-126"), "recent duplicate remains blocked");
        seen.clear();
        check(seen.accept("extra-126"), "new session may accept IDs again");
        System.out.println("BLE protocol: " + checks + " checks passed");
    }
}
