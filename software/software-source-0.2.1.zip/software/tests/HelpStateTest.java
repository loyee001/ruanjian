package com.loyee.dengnilai;

public final class HelpStateTest {
    private static int assertions;
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
        assertions++;
    }
    public static void main(String[] args) {
        HelpState state = new HelpState();
        boolean rejected = false;
        try { state.request(1, "early"); } catch (IllegalStateException expected) { rejected = true; }
        check(rejected, "Must not receive before the parent starts a session");
        state.begin(100);
        check(state.request(110, "press-1"), "First physical press accepted");
        String id = state.current().id;
        state.begin(112);
        check(state.sessionStartedAt == 100 && id.equals(state.current().id), "Repeated start must preserve the current session and request");
        check(!state.request(111, "press-1"), "Network retry must be deduplicated");
        check(state.current().count == 1, "Retry cannot escalate a reminder");
        for (int i = 2; i <= 7; i++) state.request(100 + i * 10, "press-" + i);
        check(state.events().size() == 1 && id.equals(state.current().id), "Repeated presses share one unresolved event");
        check(state.current().count == 7 && state.current().level == 3, "Keep actual press count but cap display at level three");
        check(state.current().reminderTimes.size() == 7, "Preserve every accepted press time");
        check(state.acknowledge(200), "Parent can respond");
        check(HelpState.ACKNOWLEDGED.equals(state.current().status) && state.current().completedAt == 0, "Acknowledgement is not completion");
        check(!state.acknowledge(201) && state.current().responseTimes.size() == 1, "Duplicate acknowledgement is idempotent");
        state.request(210, "press-8");
        check(id.equals(state.current().id) && HelpState.WAITING.equals(state.current().status), "A repeat after response reopens the same unresolved request");
        check(state.current().responseTimes.get(0) == 200, "Keep earlier response evidence");
        state.acknowledge(220);
        check(state.complete(230) && state.current().completedAt == 230, "Completion records its own time");
        check(!state.complete(231), "Repeated completion is idempotent");
        state.request(240, "press-9");
        check(state.events().size() == 2 && !id.equals(state.current().id) && state.current().level == 1, "A completed event permits a new request");
        state.end(250);
        check(!state.isSessionActive() && HelpState.SESSION_ENDED.equals(state.current().status), "Ending session closes unresolved request without pretending completed");
        check(state.current().closedAt == 250 && state.current().completedAt == 0, "Unfinished closure and completion stay distinct");
        state.begin(300); state.request(310, "press-1");
        check(state.current().count == 1, "A new session resets transport retry identifiers");
        System.out.println("PASS: " + assertions + " state-transition, deduplication, reminder-limit and timestamp assertions");
    }
}
