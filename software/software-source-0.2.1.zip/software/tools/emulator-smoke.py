#!/usr/bin/env python3
"""End-to-end checks restricted to a named Android emulator and this debug app.

No permission grants/appops, data clearing, installation, or real-phone commands.
Permissions are changed only by clicking normal Android Settings controls.
"""
import argparse
import os
import datetime
import json
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
ADB = Path(os.environ.get('ANDROID_SDK_ROOT', os.environ.get('ANDROID_HOME', str(Path.home() / 'Library/Android/sdk')))) / 'platform-tools/adb'
PACKAGE = 'com.loyee.dengnilai'
COMPONENT = PACKAGE + '/.MainActivity'
FORWARD_PORT = 18742
# Keep historic names valid for old APK checks and existing log consumers.
# The package identity and normal Settings page guards remain unchanged.
APP_LABEL_ALIASES = ('等你来', '拍拍小怪兽')
OVERLAY_TITLE_ALIASES = tuple(label + '求助提醒' for label in APP_LABEL_ALIASES)


class Smoke:
    def __init__(self, serial, overlay_only=False, visual_ack=False):
        if not re.fullmatch(r'emulator-[0-9]+', serial):
            raise ValueError('Only explicit emulator-* serials are allowed; real phones are rejected.')
        self.serial = serial
        self.overlay_only = overlay_only
        self.visual_ack = visual_ack
        self.token = ''
        self.forwarded = False
        self.api = int(self.shell('getprop', 'ro.build.version.sdk').strip())
        stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
        self.output = PROJECT / 'build' / 'verification' / (serial + '-api' + str(self.api) + '-' + stamp)
        self.output.mkdir(parents=True, exist_ok=True)
        self.report = {
            'serial': serial, 'api': self.api, 'package': PACKAGE, 'passed': False,
            'mode': 'overlay-only' if overlay_only else 'full',
            'checks': [], 'screenshots': [], 'notes': [],
            'permission_method': 'Normal Android runtime dialog / Settings UI clicks only',
            'limitations': [
                'Emulator evidence does not establish behaviour on the connected physical phone or its OEM background restrictions.',
                'Screenshots require human visual review; UI/window evidence is also recorded.',
                'Android Home launcher is the cross-application background; Settings is used only for normal permission changes because protected Settings pages may suppress overlays.',
                'No physical desktop button or Wi-Fi hardware is tested; HTTP is forwarded over emulator ADB.',
            ],
        }
        if self.api < 33:
            self.report['limitations'].append('API below 33 has no POST_NOTIFICATIONS runtime prompt; only normal notification Settings fallback is tested.')
        if overlay_only:
            self.report['limitations'].append('This run intentionally skips notification revocation/fallback permutations to verify the real overlay path independently.')

    def adb(self, *args, binary=False, timeout=25, check=True):
        result = subprocess.run([str(ADB), '-s', self.serial] + list(args), capture_output=True, timeout=timeout)
        if check and result.returncode:
            raise RuntimeError('ADB command failed: ' + ' '.join(args[:3]) + ': ' + result.stderr.decode('utf-8', 'replace')[:600])
        return result.stdout if binary else result.stdout.decode('utf-8', 'replace')

    def shell(self, *args, **kwargs):
        return self.adb('shell', *args, **kwargs)

    def raw_ui(self):
        remote = '/sdcard/deng-ni-lai-smoke-ui.xml'
        self.shell('uiautomator', 'dump', remote)
        xml = self.adb('exec-out', 'cat', remote)
        first = xml.find('<?xml')
        if first < 0:
            first = xml.find('<hierarchy')
        return ET.fromstring(xml[first:])

    @staticmethod
    def nodes(tree):
        return list(tree.iter('node'))

    def ui(self):
        for _ in range(4):
            tree = self.raw_ui()
            nodes = self.nodes(tree)
            joined = ' '.join(node.get('text', '') for node in nodes)
            if 'Bluetooth' in joined or '蓝牙' in joined:
                close = next((node for node in nodes if node.get('resource-id') == 'android:id/aerr_close' or node.get('text') in ('Close app', '关闭应用')), None)
                if close is not None:
                    self.tap_node(close)
                    self.report['notes'].append('Dismissed the emulator Bluetooth-process crash dialog with its normal Close app button.')
                    time.sleep(0.3)
                    continue
            if ('keeps stopping' in joined or '屡次停止运行' in joined) and any(label in joined for label in APP_LABEL_ALIASES):
                raise AssertionError('The tested application has a crash dialog: ' + joined[:500])
            return tree
        raise RuntimeError('Repeated emulator Bluetooth crash dialogs prevented UI inspection.')

    def tap_node(self, node):
        bounds = [int(value) for value in re.findall(r'\d+', node.get('bounds', ''))]
        if len(bounds) != 4 or bounds[2] <= bounds[0] or bounds[3] <= bounds[1]:
            raise RuntimeError('Node has no usable bounds: ' + str(node.attrib))
        self.shell('input', 'tap', str((bounds[0] + bounds[2]) // 2), str((bounds[1] + bounds[3]) // 2))
        time.sleep(0.35)

    def screen_size(self):
        sizes = re.findall(r'(\d+)x(\d+)', self.shell('wm', 'size'))
        if not sizes:
            raise RuntimeError('Cannot determine emulator display size.')
        return tuple(map(int, sizes[-1]))

    def tap_text(self, labels, scroll=None, attempts=6):
        if isinstance(labels, str):
            labels = (labels,)
        for _ in range(attempts):
            tree = self.ui()
            candidates = [node for node in self.nodes(tree) if node.get('text') in labels or node.get('content-desc') in labels]
            if candidates:
                self.tap_node(candidates[0])
                return True
            if scroll:
                width, height = self.screen_size()
                y1, y2 = (int(height * .75), int(height * .30)) if scroll == 'down' else (int(height * .30), int(height * .75))
                self.shell('input', 'swipe', str(width // 2), str(y1), str(width // 2), str(y2), '260')
            time.sleep(.25)
        return False

    def screenshot(self, name):
        path = self.output / (name + '.png')
        png = self.adb('exec-out', 'screencap', '-p', binary=True)
        if not png.startswith(b'\x89PNG\r\n\x1a\n'):
            raise RuntimeError('screencap did not produce PNG data.')
        path.write_bytes(png)
        self.report['screenshots'].append(str(path))
        return path

    def check(self, name, condition, evidence=None):
        record = {'name': name, 'passed': bool(condition)}
        if evidence is not None:
            record['evidence'] = evidence
        self.report['checks'].append(record)
        print(('PASS ' if condition else 'FAIL ') + name, flush=True)
        if not condition:
            raise AssertionError(name)

    def launch_app(self):
        # Pop any Settings activity previously launched by our Activity so
        # bringing its task forward cannot leave an old Settings page on top.
        self.shell('am', 'start', '-W', '--activity-clear-top', '--activity-single-top', '-n', COMPONENT)
        time.sleep(.6)
        self.ui()

    def preferences(self):
        xml = self.shell('run-as', PACKAGE, 'cat', 'shared_prefs/local_help_records.xml')
        root = ET.fromstring(xml)
        value = next((node.text for node in root if node.get('name') == 'state'), '{}')
        return json.loads(value or '{}')

    def wait_preferences(self, active, timeout=8):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            try:
                state = self.preferences()
                if state.get('session_active') == active:
                    return state
            except (RuntimeError, ET.ParseError, json.JSONDecodeError):
                pass
            time.sleep(.2)
        raise AssertionError('Session preference did not become active=' + str(active))

    def wait_http_ready(self, timeout=10):
        deadline = time.monotonic() + timeout
        last_error = 'not yet connected'
        while time.monotonic() < deadline:
            try:
                code, state = self.http('/state')
                if code == 200 and state.get('session_active'):
                    return state
                last_error = 'HTTP ' + str(code)
            except (OSError, urllib.error.URLError) as error:
                last_error = type(error).__name__
            time.sleep(.2)
        raise AssertionError('Receiving service did not become ready: ' + last_error)

    def ensure_session_after_permission_change(self, reason):
        if not self.forwarded or not self.token:
            return
        self.launch_app()
        preferences = self.preferences()
        restarted = not preferences.get('session_active', False)
        previous_token = self.token
        if restarted:
            self.report['notes'].append('Permission-change restart observed after ' + reason + ': native app reported no active session; restarting via its normal Start button.')
            if not self.tap_text('开始作业陪伴', scroll='up'):
                raise AssertionError('Permission change ended the session, but the native Start button could not be found.')
            self.permission_prompt(allow=False)
            preferences = self.wait_preferences(True)
        self.token = preferences.get('token', '')
        if not re.fullmatch(r'[0-9a-f]{24}', self.token):
            raise AssertionError('No valid current pairing token after permission change.')
        self.wait_http_ready()
        if restarted or self.token != previous_token:
            self.report['notes'].append('Receiving resumed after ' + reason + '; pairing token refreshed=' + str(self.token != previous_token) + '. No previous HTTP-session credentials reused.')

    def permission_prompt(self, allow=False):
        tree = self.ui()
        suffixes = ('permission_allow_button', 'permission_allow_foreground_only_button') if allow else ('permission_deny_button',)
        node = next((n for n in self.nodes(tree) if any(n.get('resource-id', '').endswith(suffix) for suffix in suffixes)), None)
        if node is None:
            return False
        self.tap_node(node)
        self.report['notes'].append('Clicked the normal runtime notification permission dialog: ' + ('allow' if allow else 'deny'))
        return True

    def resumed_component(self):
        activity = self.shell('dumpsys', 'activity', 'activities')
        lines = [line.strip() for line in activity.splitlines()
                 if 'topResumedActivity' in line or 'mResumedActivity' in line]
        return ' | '.join(lines[:4])

    @staticmethod
    def settings_page_matches(kind, component, tree):
        text = re.sub(r'\s+', ' ', '\n'.join(
            node.get('text', '') + ' ' + node.get('content-desc', '')
            for node in tree.iter('node'))).lower()
        if 'com.android.settings' not in component:
            return False
        if kind == 'overlay':
            # Both component identity and overlay-specific visible text must
            # match. A leftover notification page must never pass this guard.
            title_matches = any(marker in text for marker in (
                'display over other apps', 'draw over other apps',
                '显示在其他应用', '在其他应用上层', '显示在其它应用', '悬浮窗'))
            component_matches = ('drawoverlay' in component.lower() or
                                 'overlaysettings' in component.lower() or
                                 'overlaydetails' in component.lower() or
                                 'subsettings' in component.lower())
            return title_matches and component_matches and 'notification' not in component.lower()
        return ('notification' in component.lower() or 'subsettings' in component.lower()) and ('notification' in text or '通知' in text)

    def native_overlay_state(self):
        if self.token and self.forwarded:
            try:
                return bool(self.state()['overlay_permission'])
            except (OSError, urllib.error.URLError, KeyError, AssertionError):
                pass
        app_text = '\n'.join(node.get('text', '') for node in self.nodes(self.ui()))
        return (False if '悬浮提醒尚未允许' in app_text else
                True if '悬浮提醒已允许' in app_text else None)

    def settings_switch(self, kind, enabled):
        if kind == 'overlay':
            # These labels come directly from Settings.canDrawOverlays in the
            # native app. A known matching state needs no Settings mutation.
            self.launch_app()
            current = self.native_overlay_state()
            if current is not None and current == enabled:
                self.report['notes'].append('Overlay already ' + str(enabled) + ', verified from the app native permission state; no setting changed.')
                self.screenshot('overlay-already-' + ('allowed' if enabled else 'disabled'))
                return
        if kind == 'overlay':
            # Enter from the Activity button, just like the parent. Launching
            # an implicit Settings intent from adb can reuse the wrong task.
            opened = self.tap_text('允许悬浮提醒', scroll='up', attempts=3)
            if not opened:
                opened = self.tap_text('允许悬浮提醒', scroll='down', attempts=6)
            if not opened:
                if enabled:
                    raise AssertionError('Cannot find the native Allow overlay button; no Settings switch will be touched.')
                # An already-enabled app hides its Allow button. To reset a
                # repeat emulator run, open the dedicated AOSP screen by its
                # explicit component, then still require the strict UI guard.
                component = 'com.android.settings/.Settings$DrawOverlaySettingsActivity'
                self.shell('am', 'start', '-W', '-n', "'" + component + "'")
                self.report['notes'].append('Resetting a pre-existing overlay permission through the explicit AOSP overlay Settings page; switch still requires title/component validation.')
        else:
            self.shell('am', 'start', '-a', 'android.settings.APP_NOTIFICATION_SETTINGS', '--es', 'android.provider.extra.APP_PACKAGE', PACKAGE)
        time.sleep(.7)
        previous_list = None
        unchanged_scrolls = 0
        waiting_for_title = 0
        for attempt in range(16):
            tree = self.ui()
            component = self.resumed_component()
            if not self.settings_page_matches(kind, component, tree):
                expected_loading_component = ('overlay' in component.lower() and kind == 'overlay' and 'notification' not in component.lower()) or ('notification' in component.lower() and kind == 'notifications')
                if expected_loading_component and waiting_for_title < 5:
                    waiting_for_title += 1
                    time.sleep(.7)
                    continue
                self.report['notes'].append('Rejected unexpected ' + kind + ' Settings page: ' + component)
                page_labels = [{'text': n.get('text', ''), 'description': n.get('content-desc', '')}
                               for n in self.nodes(tree) if n.get('text') or n.get('content-desc')]
                self.report['notes'].append('Rejected Settings page labels: ' + json.dumps(page_labels, ensure_ascii=False))
                self.screenshot(kind + '-unexpected-settings-page')
                raise AssertionError('Refusing to click a switch: ' + kind + ' page title/component do not match. Current: ' + component)
            switches = [n for n in self.nodes(tree) if n.get('class') in ('android.widget.Switch', 'android.widget.CompoundButton') or n.get('resource-id', '').endswith(('switch_widget', '/switch'))]
            # The first/topmost switch is the app-wide control on AOSP 27/33.
            switches.sort(key=lambda n: int(re.findall(r'\d+', n.get('bounds', '[0,0][0,0]'))[1]))
            if switches:
                switch = switches[0]
                if (switch.get('checked') == 'true') != enabled:
                    self.tap_node(switch)
                    time.sleep(.4)
                    continue
                self.report['notes'].append('Verified Settings page before switch: ' + component)
                self.screenshot(kind + ('-allowed' if enabled else '-disabled'))
                self.launch_app()
                self.ensure_session_after_permission_change(kind + '=' + str(enabled))
                if kind == 'overlay':
                    actual = self.native_overlay_state()
                    if actual != enabled:
                        raise AssertionError('Overlay switch UI did not change Settings.canDrawOverlays to ' + str(enabled) + '; actual=' + str(actual))
                self.report['notes'].append('Normal Settings UI verified: ' + kind + '=' + str(enabled))
                return
            app_row = next((n for n in self.nodes(tree) if n.get('text') in APP_LABEL_ALIASES), None)
            if app_row is not None:
                self.tap_node(app_row)
                previous_list = None
                unchanged_scrolls = 0
            else:
                # Android 11+ may ignore package: and open the all-apps list.
                # The Chinese application label sorts near the bottom on an
                # English emulator, so actively search that list with a bound.
                signature = tuple((node.get('text', ''), node.get('bounds', ''))
                                  for node in self.nodes(tree)
                                  if node.get('text'))
                unchanged_scrolls = unchanged_scrolls + 1 if signature == previous_list else 0
                previous_list = signature
                if unchanged_scrolls >= 2:
                    break
                width, height = self.screen_size()
                self.shell('input', 'swipe', str(width // 2), str(int(height * .78)),
                           str(width // 2), str(int(height * .27)), '320')
                print('Settings ' + kind + ': scrolling app list (' + str(attempt + 1) + '/16)', flush=True)
                time.sleep(.3)
        raise AssertionError('Could not reach or verify the normal ' + kind + ' Settings switch; no adb grant/appops fallback is used.')

    def http(self, path, method='GET', payload=None, authenticated=True):
        headers = {'Content-Type': 'application/json'}
        if authenticated:
            headers['Authorization'] = 'Bearer ' + self.token
        body = None if method == 'GET' else json.dumps(payload or {}).encode('utf-8')
        request = urllib.request.Request('http://127.0.0.1:' + str(FORWARD_PORT) + path, data=body, method=method, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=8) as response:
                return response.status, json.load(response)
        except urllib.error.HTTPError as error:
            return error.code, json.loads(error.read().decode('utf-8'))

    def state(self):
        code, value = self.http('/state')
        if code != 200:
            raise AssertionError('GET /state returned ' + str(code))
        return value

    def post(self, path, request_id=None):
        code, value = self.http(path, 'POST', {'request_id': request_id} if request_id is not None else {})
        self.check(path + ' returns HTTP 200', code == 200, {'status': code})
        return value

    def overlay_evidence(self, level):
        tree = self.ui()
        visible_text = any(n.get('text') == '孩子需要你' for n in self.nodes(tree))
        windows = self.shell('dumpsys', 'window', 'windows')
        blocks = []
        matched_titles = []
        for title in OVERLAY_TITLE_ALIASES:
            matches = list(re.finditer(r'Window #[^\n]*' + re.escape(title), windows))
            if matches:
                blocks.extend(windows[match.start():match.start() + 5000] for match in matches)
                matched_titles.append(title)
            else:
                # Some platform builds use a different Window header numbering.
                pos = windows.find(title)
                if pos >= 0:
                    blocks.append(windows[max(0, pos - 150):pos + 5000])
                    matched_titles.append(title)
        has_surface = any('mHasSurface=true' in block for block in blocks)
        activity = self.shell('dumpsys', 'activity', 'activities')
        resumed = [line.strip() for line in activity.splitlines() if 'mResumedActivity' in line or 'topResumedActivity' in line]
        evidence = {'level': level, 'visible_help_text_in_ui_tree': visible_text,
                    'overlay_window_blocks': len(blocks), 'overlay_surface': has_surface,
                    'resumed_activity': resumed[:4], 'matched_window_titles': matched_titles}
        self.screenshot('overlay-level-' + str(level) + '-over-launcher')
        if not visible_text:
            self.report['notes'].append('Level ' + str(level) + ': UIAutomator omits this non-focusable overlay; screenshot visual review is required and must not be replaced by addView success.')
        self.check('level ' + str(level) + ' owns a native overlay surface; screenshot requires visual review', len(blocks) == 1 and has_surface, evidence)

    def stop_using_ui(self):
        self.launch_app()
        if not self.tap_text('结束本次陪伴', scroll='up'):
            raise AssertionError('Cannot find the app End companionship button.')
        self.wait_preferences(False)

    def run(self):
        self.check('fixed debug package is installed', 'package:' in self.shell('pm', 'path', PACKAGE))
        self.launch_app()
        # A prior smoke session is closed through the app before this run.
        try:
            if self.preferences().get('session_active'):
                self.stop_using_ui()
        except (RuntimeError, ET.ParseError):
            pass
        if not self.overlay_only:
            self.settings_switch('overlay', False)
        self.check('native Start button exists', self.tap_text('开始作业陪伴', scroll='up'))
        prompt_denied = self.permission_prompt(allow=False)
        if self.api >= 33 and not prompt_denied:
            self.report['limitations'].append('A fresh runtime notification denial dialog was not present; existing permission history was preserved.' + (' This overlay-only run does not retest notification denial.' if self.overlay_only else ' Denial is tested through normal notification Settings instead.'))
        prefs = self.wait_preferences(True)
        self.token = prefs.get('token', '')
        self.check('session generated a 96-bit pairing token', bool(re.fullmatch(r'[0-9a-f]{24}', self.token)))
        self.adb('forward', 'tcp:' + str(FORWARD_PORT), 'tcp:8742')
        self.forwarded = True
        self.wait_http_ready()
        code, _ = self.http('/state', authenticated=False)
        self.check('unauthenticated HTTP is rejected', code == 401)
        if not self.overlay_only:
            initial = self.post('/help', 'fallback-first')
            self.check('overlay denied is reported honestly', initial['overlay_permission'] is False and initial['last_delivery'] in ('notification', 'app_only'), {'last_delivery': initial['last_delivery']})
            duplicate = self.post('/help', 'fallback-first')
            self.check('same request ID is deduplicated', duplicate.get('accepted') is False and duplicate['current']['count'] == initial['current']['count'])
            self.screenshot('initial-permission-fallback')
            if self.api >= 33:
                self.settings_switch('notifications', False)
                denied = self.post('/help', 'fallback-denied')
                self.check('both permissions denied falls back to app-only', denied['last_delivery'] == 'app_only')
                self.screenshot('notification-denied-app-only')
            self.settings_switch('notifications', True)
            notified = self.post('/help', 'fallback-notification')
            self.check('notification fallback is used before overlay approval', notified['last_delivery'] == 'notification' and not notified['overlay_permission'])
            self.screenshot('notification-fallback')
            self.post('/ack'); self.post('/complete')
        self.settings_switch('overlay', True)
        self.check('normal Settings enabled overlay permission', self.state()['overlay_permission'] is True)
        self.shell('input', 'keyevent', 'KEYCODE_HOME')
        self.report['notes'].append('Cross-app verification uses the emulator Home launcher; protected Settings windows are not assumed to permit overlays.')
        time.sleep(.6)
        current_id = None
        for press in range(1, 5):
            result = self.post('/help', 'overlay-press-' + str(press))
            current = result['current']
            if current_id is None:
                current_id = current['id']
            self.check('press ' + str(press) + ' reuses the same event and caps level', current['id'] == current_id and current['count'] == press and current['level'] == min(press, 3))
            self.check('press ' + str(press) + ' requested a native overlay', result['last_delivery'] == 'overlay_requested')
            if press == 1:
                duplicate = self.post('/help', 'overlay-press-1')
                self.check('overlay transport retry is deduplicated', duplicate.get('accepted') is False and duplicate['current']['count'] == 1)
            time.sleep(.5)
            if press <= 3:
                self.overlay_evidence(press)
        clicked = self.tap_text('收到，我来了', attempts=1)
        if not clicked and self.visual_ack:
            image = self.screenshot('level-3-before-image-reviewed-ack')
            print('VISUAL_ACK_REQUIRED ' + str(image), flush=True)
            point = input('After reviewing this screenshot, enter actual button centre in device pixels as X Y: ').strip()
            if not re.fullmatch(r'\d+\s+\d+', point):
                raise AssertionError('Image-reviewed acknowledgement requires two integer pixel coordinates.')
            x, y = map(int, point.split())
            width, height = self.screen_size()
            if not (0 < x < width and 0 < y < height):
                raise AssertionError('Acknowledgement point is outside the emulator screen.')
            self.shell('input', 'tap', str(x), str(y))
            time.sleep(.5)
            self.report['notes'].append('Actual level-three overlay acknowledgement clicked at screenshot-reviewed device pixel (' + str(x) + ', ' + str(y) + '); HTTP state change is verified next.')
            clicked = True
        self.check('actual overlay Acknowledge button can be clicked', clicked)
        ack = self.state()['current']
        self.check('UI acknowledgement records response without completion', ack['status'] == 'acknowledged' and ack['completed_at'] == 0 and len(ack['response_times']) == 1)
        windows = self.shell('dumpsys', 'window', 'windows')
        self.check('acknowledgement removes the overlay', not any(title in windows for title in OVERLAY_TITLE_ALIASES))
        self.screenshot('acknowledged-overlay-dismissed')
        completed = self.post('/complete')['current']
        self.check('completion records its own completion time', completed['status'] == 'completed' and completed['completed_at'] > 0)
        self.launch_app(); self.screenshot('completed-in-native-app')
        next_event = self.post('/help', 'new-after-completion')['current']
        self.check('completed event permits a new level-one request', next_event['id'] != current_id and next_event['count'] == 1 and next_event['level'] == 1)
        self.post('/ack')
        self.stop_using_ui()
        closed = False
        for _ in range(15):
            try:
                self.http('/state')
            except (OSError, urllib.error.URLError):
                closed = True
                break
            time.sleep(.2)
        self.check('ending companionship closes the HTTP listener', closed)
        self.check('ending companionship clears local active state', self.preferences().get('session_active') is False)
        windows = self.shell('dumpsys', 'window', 'windows')
        self.check('no overlay remains after session end', not any(title in windows for title in OVERLAY_TITLE_ALIASES))
        self.screenshot('session-ended')
        self.report['passed'] = True

    def finish(self):
        if not self.report['passed']:
            try:
                self.screenshot('failure-screen')
            except Exception as error:
                self.report['notes'].append('Failure screenshot unavailable: ' + str(error))
            try:
                if self.token and self.forwarded:
                    self.http('/ack', 'POST')
            except Exception as error:
                self.report['notes'].append('Cleanup HTTP acknowledgement unavailable: ' + str(error))
            # Still try the native UI even when HTTP has already disconnected.
            try:
                self.launch_app()
                if self.preferences().get('session_active'):
                    self.stop_using_ui()
            except Exception as error:
                self.report['notes'].append('Cleanup native UI could not fully finish; inspect emulator: ' + str(error))
        if self.forwarded:
            self.adb('forward', '--remove', 'tcp:' + str(FORWARD_PORT), check=False)
        report_path = self.output / 'result.json'
        report_path.write_text(json.dumps(self.report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print('REPORT ' + str(report_path), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--serial', required=True, help='Explicit emulator-* serial; real phones are rejected')
    parser.add_argument('--overlay-only', action='store_true', help='Verify native overlays without repeating notification revocation/fallback permutations')
    parser.add_argument('--visual-ack', action='store_true', help='If UIAutomator omits the overlay, pause for screenshot-reviewed actual button X Y pixels on stdin')
    args = parser.parse_args()
    if not re.fullmatch(r'emulator-[0-9]+', args.serial):
        parser.error('--serial must be emulator-*; no real-device operation is permitted')
    smoke = Smoke(args.serial, overlay_only=args.overlay_only, visual_ack=args.visual_ack)
    try:
        smoke.run()
    except Exception as error:
        smoke.report['error'] = type(error).__name__ + ': ' + str(error)
        print('FAIL ' + smoke.report['error'], file=sys.stderr, flush=True)
    finally:
        smoke.finish()
    return 0 if smoke.report['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
