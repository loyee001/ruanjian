#!/usr/bin/env python3
"""Observe this app over Douyin; optional explicit three-press debug injection.

Uses the app's authenticated development endpoint, not permission grants or
input injection. No session token is printed or saved. Does not acknowledge,
finish, clear records, change permissions, or force-stop any app.
"""
import argparse
import os
import datetime
import json
from pathlib import Path
import re
import subprocess
import time
import urllib.request
import xml.etree.ElementTree as ET

ADB = str(Path(os.environ.get('ANDROID_SDK_ROOT', os.environ.get('ANDROID_HOME', str(Path.home() / 'Library/Android/sdk')))) / 'platform-tools/adb')
PACKAGE = 'com.loyee.dengnilai'
TARGET = 'com.ss.android.ugc.aweme'
TITLE = '等你来求助提醒'

parser = argparse.ArgumentParser()
parser.add_argument('--serial', required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--inject-three', action='store_true')
parser.add_argument('--prepare-switch', action='store_true', help='Read app credentials while foreground, then open Douyin normally')
parser.add_argument('--observe-physical', action='store_true', help='Only observe three physical presses; never POST a debug press')
parser.add_argument('--seconds', type=int, default=300)
args = parser.parse_args()
if args.inject_three and args.observe_physical:
    parser.error('Choose debug injection or physical observation, not both')
if not 1 <= args.seconds <= 600:
    parser.error('--seconds must be between 1 and 600')
args.output.mkdir(parents=True, exist_ok=True)

def adb(*arguments, binary=False):
    report['last_adb_operation'] = ' '.join(arguments)
    result = subprocess.run([ADB, '-s', args.serial, *arguments],
                            capture_output=True, check=True, timeout=25)
    return result.stdout if binary else result.stdout.decode(errors='replace')

def foreground():
    activities = adb('shell', 'dumpsys', 'activity', 'activities')
    return next((line.strip() for line in activities.splitlines()
                 if 'topResumedActivity=' in line or 'mResumedActivity:' in line), '')

def own_overlay_windows():
    dump = adb('shell', 'dumpsys', 'window', 'windows')
    blocks = re.split(r'(?=  Window #\d+)', dump)
    own = [block for block in blocks if TITLE in block.split('\n', 1)[0]]
    return {'count': len(own), 'blocks': own}

def safe_state(state):
    return {key: state.get(key) for key in [
        'session_active', 'overlay_permission', 'notifications_enabled',
        'last_delivery', 'bluetooth_connected', 'bluetooth_status', 'current']}

report = {'timestamp_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'package': PACKAGE, 'target_package': TARGET,
          'injection_requested': args.inject_three,
          'permission_changes': False, 'physical_observation': args.observe_physical, 'samples': []}
try:
    if args.prepare_switch:
        adb('shell', 'am', 'start', '-n', PACKAGE + '/.MainActivity')
        time.sleep(.6)
    xml = ET.fromstring(adb('shell', 'run-as', PACKAGE, 'cat',
                           'shared_prefs/local_help_records.xml'))
    saved = json.loads(next((node.text for node in xml if node.get('name') == 'state'), '{}'))
    token = saved.get('token', '')
    adb('forward', 'tcp:18742', 'tcp:8742')

    def api(path, payload=None):
        headers = {'Authorization': 'Bearer ' + token}
        data = None
        if payload is not None:
            headers['Content-Type'] = 'application/json'
            data = json.dumps(payload).encode()
        request = urllib.request.Request('http://127.0.0.1:18742' + path,
                                         data=data, headers=headers)
        with urllib.request.urlopen(request, timeout=10) as response:
            return json.load(response)

    state = api('/state')
    report['baseline'] = safe_state(state)
    if args.prepare_switch:
        adb('shell', 'am', 'start', '-n', TARGET + '/.splash.SplashActivity')
        deadline = time.monotonic() + 8
        while True:
            report['foreground_before'] = foreground()
            if TARGET in report['foreground_before'] or time.monotonic() >= deadline:
                break
            time.sleep(.5)
    else:
        report['foreground_before'] = foreground()
    if args.inject_three or args.observe_physical:
        if TARGET not in report['foreground_before']:
            raise RuntimeError('Douyin is not the resumed app; no debug presses sent')
        if not state.get('session_active'):
            raise RuntimeError('Companionship session is not active; no debug presses sent')
        if not state.get('overlay_permission'):
            raise RuntimeError('Overlay permission is not enabled; no debug presses sent')
        current = state.get('current')
        report['continues_existing_request'] = bool(current and current.get('status') in ('waiting', 'acknowledged'))
    if args.observe_physical:
        baseline = state.get('current') or {}
        last_delta = 0
        deadline = time.monotonic() + args.seconds
        print('PHYSICAL_OBSERVER_READY: no HTTP press requests will be sent', flush=True)
        while time.monotonic() < deadline:
            state = api('/state')
            current = state.get('current') or {}
            previous_count = baseline.get('count', 0) if baseline.get('id') == current.get('id') else 0
            delta = current.get('count', 0) - previous_count
            if delta > last_delta:
                sample = {'physical_count_delta': delta, 'state': safe_state(state),
                          'windows': own_overlay_windows(), 'foreground': foreground()}
                report['samples'].append(sample)
                last_delta = delta
                (args.output / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
                print(json.dumps({'observed_count_delta': delta, 'level': current.get('level'),
                                  'delivery': state.get('last_delivery'),
                                  'overlay_window_count': sample['windows']['count']}, ensure_ascii=False), flush=True)
                if delta >= 3:
                    image = args.output / 'physical-level-3-over-douyin.png'
                    try:
                        image.write_bytes(adb('exec-out', 'screencap', '-p', binary=True))
                        sample['screenshot'] = str(image)
                    except subprocess.TimeoutExpired:
                        sample['screenshot_error'] = 'Screenshot timed out; require separate visual confirmation'
                    report['physical_count_delta'] = delta
                    break
            time.sleep(.4)
        if last_delta < 3:
            raise RuntimeError('Observation ended before three new physical presses reached the app')
    elif args.inject_three:
        run_id = 'cross-app-debug-' + str(time.time_ns())
        for index in range(1, 4):
            api('/help', {'request_id': run_id + '-' + str(index)})
            time.sleep(.4)
            state = api('/state')
            windows = own_overlay_windows()
            image = args.output / ('level-' + str(index) + '-over-douyin.png')
            sample = {'index': index, 'state': safe_state(state),
                      'windows': windows, 'foreground': foreground()}
            report['samples'].append(sample)
            (args.output / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
            try:
                image.write_bytes(adb('exec-out', 'screencap', '-p', binary=True))
                sample['screenshot'] = str(image)
            except subprocess.TimeoutExpired:
                sample['screenshot_error'] = 'ADB screenshot timed out; window state does not prove visual coverage'
            print(json.dumps({'index': index, 'level': (state.get('current') or {}).get('level'),
                              'delivery': state.get('last_delivery'),
                              'overlay_window_count': windows['count'],
                              'screenshot': sample.get('screenshot'),
                              'screenshot_error': sample.get('screenshot_error')}, ensure_ascii=False), flush=True)
            time.sleep(.5)
    else:
        report['windows'] = own_overlay_windows()
        print(json.dumps({'state': safe_state(state), 'foreground': report['foreground_before'],
                          'overlay_window_count': report['windows']['count']}, ensure_ascii=False, indent=2))
    report['completed'] = True
except Exception as error:
    report['completed'] = False
    report['error_type'] = type(error).__name__
    # Do not print URL/request headers or preferences containing the token.
    if isinstance(error, RuntimeError):
        report['reason'] = str(error)
    elif isinstance(error, subprocess.CalledProcessError):
        report['reason'] = error.stderr.decode(errors='replace')[:400]
    elif isinstance(error, subprocess.TimeoutExpired):
        report['reason'] = 'ADB command timed out: ' + ' '.join(error.cmd[3:])[:300]
    print(json.dumps({key: report[key] for key in ['completed', 'error_type', 'reason'] if key in report}, ensure_ascii=False), flush=True)
finally:
    (args.output / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    try:
        adb('forward', '--remove', 'tcp:18742')
    except Exception:
        pass

raise SystemExit(0 if report.get('completed') else 1)
