#!/usr/bin/env python3
"""Exercise delayed simulation through actual UI on a named emulator only.

Runtime/overlay permissions use normal Android dialogs and Settings switches.
No grants, appops, data clearing, or physical-device commands are allowed.
"""
import argparse
import importlib.util
import json
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

SPEC = importlib.util.spec_from_file_location('original_smoke', Path(__file__).with_name('emulator-smoke.py'))
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
OLD.PACKAGE = 'com.loyee.dengnilai.simulation'
OLD.COMPONENT = OLD.PACKAGE + '/com.loyee.dengnilai.MainActivity'
OLD.FORWARD_PORT = 18743
TITLE = '等你来(模拟)求助提醒'
PROJECT = Path(__file__).resolve().parents[1]
FIXTURE = PROJECT / 'build/verification/delay-upgrade-fixture'


class DelayedSmoke(OLD.Smoke):
    def __init__(self, serial):
        super().__init__(serial, overlay_only=True, visual_ack=True)
        self.report['mode'] = 'delayed-simulation-upgrade-and-cross-app'
        self.report['limitations'] += [
            'No BLE peripheral is paired in the emulator; scan/permission UI is not physical BLE acceptance.',
            'The simulation is driven only by the app buttons; HTTP is used read-only to sample state, except to complete a previously acknowledged test event.',
        ]
        self.report['timeline_samples'] = []

    def tap_node(self, node):
        self.last_tapped_at = time.monotonic()
        return super().tap_node(node)

    def ui(self):
        for _ in range(4):
            tree = self.raw_ui()
            nodes = self.nodes(tree)
            joined = ' '.join(n.get('text', '') for n in nodes)
            crashed = any(x in joined.lower() for x in ('keeps stopping', 'has stopped', '屡次停止运行', '已停止运行'))
            if crashed and '等你来' in joined:
                raise AssertionError('Tested app crashed: ' + joined[:800])
            if crashed and ('Bluetooth' in joined or '蓝牙' in joined):
                close = next((n for n in nodes if n.get('resource-id') == 'android:id/aerr_close' or n.get('text') in ('Close app', '关闭应用')), None)
                if close is not None:
                    self.tap_node(close)
                    self.report['notes'].append('Dismissed separate Android emulator Bluetooth system-process crash via its normal Close app control; tested app was not the crashing process.')
                    continue
            return tree
        raise RuntimeError('Emulator Bluetooth crash dialog kept returning.')

    def top(self):
        self.launch_app()
        for _ in range(5):
            self.shell('input', 'swipe', '500', '550', '500', '1800', '100')
        time.sleep(.3)

    def preferences(self):
        # A clean first launch has no preferences file until the native Start
        # flow saves state. This is an empty state, not an app failure.
        try:
            return super().preferences()
        except RuntimeError as error:
            if 'No such file or directory' in str(error) and 'local_help_records.xml' in str(error):
                return {'session_active': False, 'events': []}
            raise

    def start_and_forward(self):
        self.top()
        prefs = self.preferences()
        if not prefs.get('session_active'):
            self.check('native Start tapped', self.tap_text('开始作业陪伴', scroll='up'))
            self.permission_prompt(allow=True)
        prefs = self.wait_preferences(True)
        self.token = prefs.get('token', '')
        self.check('session owns pairing token', bool(re.fullmatch('[0-9a-f]{24}', self.token)))
        self.adb('forward', 'tcp:18743', 'tcp:8743')
        self.forwarded = True
        self.wait_http_ready()

    def overlay_permission_ui(self):
        self.top()
        if self.state()['overlay_permission']:
            self.check('normal native permission state already allows overlays', True)
            return
        self.check('open overlay Settings from app', self.tap_text('允许悬浮提醒', scroll='down'))
        for attempt in range(18):
            tree = self.ui()
            component = self.resumed_component()
            if not self.settings_page_matches('overlay', component, tree):
                time.sleep(.6)
                continue
            switches = [n for n in self.nodes(tree) if n.get('class') in ('android.widget.Switch', 'android.widget.CompoundButton') or n.get('resource-id', '').endswith(('switch_widget', '/switch'))]
            if switches:
                switch = switches[0]
                if switch.get('checked') != 'true':
                    self.tap_node(switch)
                    continue
                self.screenshot('overlay-allowed-via-normal-settings')
                self.start_and_forward()
                self.check('actual Settings.canDrawOverlays true', self.state()['overlay_permission'])
                return
            app = next((n for n in self.nodes(tree) if n.get('text') == '等你来(模拟)'), None)
            if app is not None:
                self.tap_node(app)
            else:
                width, height = self.screen_size()
                self.shell('input', 'swipe', str(width // 2), str(int(height * .8)), str(width // 2), str(int(height * .25)), '200')
        raise AssertionError('Could not verify normal overlay Settings switch. No grant/appops fallback is allowed.')

    def window_info(self):
        windows = self.shell('dumpsys', 'window', 'windows')
        blocks = []
        for match in re.finditer(r'Window #[^\n]*' + re.escape(TITLE), windows):
            blocks.append(windows[match.start():match.start() + 6000])
        if not blocks and TITLE in windows:
            start = windows.index(TITLE)
            blocks = [windows[max(0, start - 150):start + 6000]]
        return {'window_count': len(blocks), 'has_surface': any('mHasSurface=true' in b for b in blocks), 'blocks': blocks}

    def actual_ack(self, name):
        clicked = self.tap_text('收到，我来了', attempts=1)
        if not clicked:
            path = self.screenshot(name + '-before-visual-ack')
            print('VISUAL_ACK_REQUIRED ' + str(path), flush=True)
            point = input('Screenshot-reviewed ACK centre X Y (device pixels): ').strip()
            if not re.fullmatch(r'\d+\s+\d+', point):
                raise AssertionError('Need screenshot-reviewed actual ACK coordinates.')
            x, y = map(int, point.split())
            width, height = self.screen_size()
            self.check('visual ACK coordinates are on screen', 0 < x < width and 0 < y < height)
            self.shell('input', 'tap', str(x), str(y))
            self.report['notes'].append('ACK clicked at human-reviewed screenshot coordinates: ' + point)
        time.sleep(.4)
        current = self.state()['current']
        self.check(name + ' UI ACK recorded', current['status'] == 'acknowledged' and current['response_times'])
        self.check(name + ' ACK removes actual window', self.window_info()['window_count'] == 0)
        self.screenshot(name + '-acknowledged')

    def complete_current(self):
        current = self.state().get('current')
        if current and current['status'] != 'completed':
            self.top()
            self.check('normal Complete button tapped', self.tap_text('已经处理完成', scroll='down', attempts=12))
            self.check('event completed', self.state()['current']['status'] == 'completed')

    def capture_baseline(self):
        state = self.state()
        return {'records': len(state['records']), 'current': state['current']}

    def schedule_and_sample(self, count, button_label):
        self.top()
        self.check('native delayed button exists ' + button_label, self.tap_text(button_label, scroll='down', attempts=14))
        started = self.last_tapped_at
        self.shell('input', 'keyevent', 'KEYCODE_HOME')
        resumed = self.resumed_component()
        self.check('switched away to Launcher before delivery', 'launcher' in resumed.lower() or 'nexuslauncher' in resumed.lower(), resumed)
        timeline = []
        seen = set()
        last_state = None
        deadline = started + (9 if count == 3 else 7)
        while time.monotonic() < deadline:
            state = self.state()
            elapsed = time.monotonic() - started
            event = state.get('current')
            waiting = event and event.get('status') == 'waiting'
            sample = {'elapsed_s': round(elapsed, 3), 'current': event, 'last_delivery': state.get('last_delivery')}
            timeline.append(sample)
            if waiting and event['level'] not in seen:
                level = event['level']
                seen.add(level)
                with ThreadPoolExecutor(max_workers=2) as pool:
                    png_future = pool.submit(self.screenshot, 'delay-' + str(count) + '-level-' + str(level))
                    info_future = pool.submit(self.window_info)
                    png, info = png_future.result(), info_future.result()
                (self.output / ('delay-' + str(count) + '-level-' + str(level) + '-windows.json')).write_text(json.dumps(info, ensure_ascii=False, indent=2))
                self.check(str(count) + '-press delayed level ' + str(level) + ' has actual window surface', info['window_count'] == 1 and info['has_surface'], {'elapsed_s': elapsed, 'screenshot': str(png)})
            last_state = state
            final_observed = waiting and event['count'] >= count
            if final_observed and elapsed >= (7.5 if count == 3 else 5.7):
                break
            time.sleep(.07)
        self.report['timeline_samples'].append({'planned_count': count, 'click_to_home_s': 0, 'samples': timeline})
        early = [s for s in timeline if s['elapsed_s'] < 4.1]
        self.check(str(count) + '-press no premature reminder during first 4 seconds', bool(early) and all(not s['current'] or s['current']['status'] != 'waiting' for s in early))
        current = last_state['current']
        self.check(str(count) + '-press correct final count and level', current['count'] == count and current['level'] == min(count, 3), current)
        self.check(str(count) + '-press each actual overlay level observed', seen == set(range(1, min(count, 3) + 1)), sorted(seen))
        reminders = current['reminder_times']
        if count == 3:
            gaps = [reminders[i + 1] - reminders[i] for i in range(2)]
            self.check('three scheduled presses occur about one second apart', all(750 <= gap <= 1800 for gap in gaps), gaps)
        self.actual_ack('delay-' + str(count))
        self.complete_current()

    def run_fixture(self, apk):
        self.check('API33 emulator is used', self.api == 33)
        existing = self.shell('pm', 'path', OLD.PACKAGE, check=False)
        if 'package:' not in existing:
            self.adb('install', '-r', str(apk), timeout=120)
        self.check('old fixture starts at versionCode 1', bool(re.search(r'versionCode=1\b', self.shell('dumpsys', 'package', OLD.PACKAGE))))
        self.start_and_forward()
        self.check('old APK native simulation tapped', self.tap_text('模拟按一下', scroll='down', attempts=10))
        time.sleep(.4)
        self.top()
        self.check('old APK native acknowledgment', self.tap_text('收到，我来了', scroll='down', attempts=10))
        self.complete_current()
        self.top()
        self.check('old APK session ended normally', self.tap_text('结束本次陪伴', scroll='up'))
        old = self.preferences()
        self.check('old APK fixture has stored record', bool(old.get('events')))
        fixture = {'preferences': old, 'package_dump': self.shell('dumpsys', 'package', OLD.PACKAGE), 'apk': str(apk)}
        FIXTURE.mkdir(parents=True, exist_ok=True)
        (FIXTURE / 'fixture-state.json').write_text(json.dumps(fixture, ensure_ascii=False, indent=2))
        self.screenshot('old-version-record-fixture')
        self.report['passed'] = True

    def run_updated(self, apk):
        self.check('API33 emulator is used', self.api == 33)
        fixture = json.loads((FIXTURE / 'fixture-state.json').read_text())
        old_events = fixture['preferences']['events']
        installed = self.adb('install', '-r', str(apk), timeout=120)
        self.check('cover install succeeds with same package and signing identity', 'Success' in installed, installed.strip())
        self.launch_app()
        new_events = self.preferences()['events']
        self.check('cover install preserves exact stored records', new_events == old_events)
        dump = self.shell('dumpsys', 'package', OLD.PACKAGE)
        old_version = int(re.search(r'versionCode=(\d+)', fixture['package_dump']).group(1))
        new_version = int(re.search(r'versionCode=(\d+)', dump).group(1))
        self.check('versionCode increased', new_version > old_version, {'old': old_version, 'new': new_version})
        self.start_and_forward()
        self.overlay_permission_ui()
        self.complete_current()
        self.schedule_and_sample(1, '5 秒后按一次')
        self.schedule_and_sample(3, '5 秒后连续按 3 次')
        self.top()
        self.check('schedule cancellation test', self.tap_text('5 秒后连续按 3 次', scroll='down', attempts=12))
        self.check('cancel delayed simulation via app button', self.tap_text('取消本次倒计时', attempts=2))
        baseline = self.capture_baseline()
        self.shell('input', 'keyevent', 'KEYCODE_HOME')
        time.sleep(7.5)
        self.check('cancel prevents all delayed help events', self.capture_baseline() == baseline)
        self.check('cancel leaves no overlay window', self.window_info()['window_count'] == 0)
        self.top()
        self.check('schedule session-end cancellation test', self.tap_text('5 秒后连续按 3 次', scroll='down', attempts=12))
        self.check('end session via app UI during countdown', self.tap_text('结束本次陪伴', scroll='up'))
        old = self.preferences()
        self.shell('input', 'keyevent', 'KEYCODE_HOME')
        time.sleep(7.5)
        after = self.preferences()
        self.check('ending session prevents delayed presses', not after['session_active'] and after['events'] == old['events'])
        self.check('session end removes all reminder windows', self.window_info()['window_count'] == 0)
        self.start_and_forward()
        self.check('BLE connection button can be tapped', self.tap_text('搜索蓝牙按钮', scroll='down', attempts=14))
        self.permission_prompt(allow=False)
        time.sleep(.8)
        self.screenshot('ble-permission-or-unavailable-state')
        self.ui()
        self.check('app survives BLE permission/unavailable path', bool(self.shell('pidof', OLD.PACKAGE).strip()))
        self.report['notes'].append('BLE unavailable/permission state requires screenshot review; no connected BLE peripheral exists in this test.')
        self.top()
        self.tap_text('结束本次陪伴', scroll='up')
        self.report['passed'] = True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--serial', required=True)
    parser.add_argument('--apk', required=True, type=Path)
    parser.add_argument('--prepare-old', action='store_true')
    args = parser.parse_args()
    smoke = DelayedSmoke(args.serial)
    try:
        (smoke.run_fixture if args.prepare_old else smoke.run_updated)(args.apk.resolve())
    except Exception as error:
        smoke.report['error'] = type(error).__name__ + ': ' + str(error)
        print('FAIL ' + smoke.report['error'], file=sys.stderr, flush=True)
    finally:
        smoke.finish()
    return 0 if smoke.report['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
